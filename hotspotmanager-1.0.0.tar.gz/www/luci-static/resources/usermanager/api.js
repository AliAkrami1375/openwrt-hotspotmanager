'use strict';
'require baseclass';
'require rpc';

var callStatus = rpc.declare({ object: 'luci.usermanager', method: 'status', expect: {} });
var callSessions = rpc.declare({ object: 'luci.usermanager', method: 'sessions', expect: { sessions: [] } });
var callUsers = rpc.declare({ object: 'luci.usermanager', method: 'users', expect: { users: {} } });
var callNeighbors = rpc.declare({ object: 'luci.usermanager', method: 'neighbors', expect: { neighbors: [] } });
var callKick = rpc.declare({ object: 'luci.usermanager', method: 'kick', params: [ 'ip' ], expect: {} });
var callKickUser = rpc.declare({ object: 'luci.usermanager', method: 'kick_user', params: [ 'username' ], expect: {} });
var callResetUsage = rpc.declare({ object: 'luci.usermanager', method: 'reset_usage', params: [ 'username' ], expect: {} });
var callForgetUser = rpc.declare({ object: 'luci.usermanager', method: 'forget_user', params: [ 'username' ], expect: {} });
var callGenerateVouchers = rpc.declare({ object: 'luci.usermanager', method: 'generate_vouchers', params: [ 'count', 'length', 'prefix', 'profile', 'comment', 'charset' ], expect: {} });
var callLog = rpc.declare({ object: 'luci.usermanager', method: 'log', params: [ 'lines' ], expect: { log: '' } });
var callService = rpc.declare({ object: 'luci.usermanager', method: 'service', params: [ 'action' ], expect: {} });
var callCategories = rpc.declare({ object: 'luci.usermanager', method: 'categories', expect: { categories: {} } });
var callForwards = rpc.declare({ object: 'luci.usermanager', method: 'forwards', expect: { forwards: {} } });
var callUserDetail = rpc.declare({ object: 'luci.usermanager', method: 'user_detail', params: [ 'username' ], expect: {} });

return baseclass.extend({
	status: callStatus,
	sessions: callSessions,
	users: callUsers,
	neighbors: callNeighbors,
	kick: callKick,
	kickUser: callKickUser,
	resetUsage: callResetUsage,
	forgetUser: callForgetUser,
	generateVouchers: callGenerateVouchers,
	log: callLog,
	service: callService,
	categories: callCategories,
	forwards: callForwards,
	userDetail: callUserDetail,

	fmtBytes: function(b) {
		b = +b || 0;
		var units = [ 'B', 'KB', 'MB', 'GB', 'TB' ], i = 0, v = b;
		while (v >= 1024 && i < units.length - 1) {
			v /= 1024;
			i++;
		}
		return (i == 0) ? '%d B'.format(b) : '%.2f %s'.format(v, units[i]);
	},

	fmtDuration: function(sec) {
		sec = Math.max(0, Math.floor(+sec || 0));
		var d = Math.floor(sec / 86400),
		    h = Math.floor((sec % 86400) / 3600),
		    m = Math.floor((sec % 3600) / 60),
		    s = sec % 60,
		    out = [];
		if (d) out.push(d + 'd');
		if (h) out.push(h + 'h');
		if (m) out.push(m + 'm');
		if (!d && !h) out.push(s + 's');
		return out.join(' ');
	},

	fmtDate: function(ts) {
		if (!ts)
			return '-';
		var d = new Date(ts * 1000);
		return '%04d-%02d-%02d %02d:%02d'.format(d.getFullYear(), d.getMonth() + 1, d.getDate(), d.getHours(), d.getMinutes());
	},

	stateLabel: function(state) {
		var map = {
			online: [ _('Online'), '#16a34a' ],
			offline: [ _('Offline'), '#64748b' ],
			disabled: [ _('Disabled'), '#9ca3af' ],
			expired: [ _('Expired'), '#dc2626' ],
			quota: [ _('Quota exhausted'), '#dc2626' ],
			timelimit: [ _('Time limit reached'), '#dc2626' ]
		};
		var e = map[state] || [ state, '#64748b' ];
		return E('span', { 'style': 'display:inline-block;padding:2px 8px;border-radius:10px;color:#fff;font-size:12px;background:' + e[1] }, e[0]);
	},

	quotaBar: function(used, quota) {
		if (!quota)
			return E('span', {}, this.fmtBytes(used) + ' / ∞');
		var pct = Math.min(100, Math.round(used * 100 / quota));
		var color = pct >= 90 ? '#dc2626' : (pct >= 70 ? '#f59e0b' : '#2563eb');
		return E('div', { 'style': 'min-width:140px' }, [
			E('div', { 'style': 'font-size:12px' }, this.fmtBytes(used) + ' / ' + this.fmtBytes(quota) + ' (' + pct + '%)'),
			E('div', { 'style': 'height:6px;background:#e2e8f0;border-radius:4px;overflow:hidden;margin-top:3px' }, [
				E('div', { 'style': 'height:100%;width:' + pct + '%;background:' + color })
			])
		]);
	}
});
