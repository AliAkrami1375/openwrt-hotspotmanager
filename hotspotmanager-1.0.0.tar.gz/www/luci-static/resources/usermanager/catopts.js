'use strict';
'require baseclass';
'require rpc';

// Content-category helpers shared by the Profiles and Users views.
// Kept in its own module so views do not depend on a (possibly cached) older api.js.

var callCategories = rpc.declare({ object: 'luci.usermanager', method: 'categories', expect: { categories: {} } });

return baseclass.extend({
	categories: callCategories,

	// adds the category checkboxes + throttle rate to a profile/user section (tab "access")
	add: function(s, form, categories, isUser) {
		var o;
		o = s.taboption('access', form.MultiValue, 'cat_block', _('Block categories'));
		o.modalonly = true;
		Object.keys(categories).forEach(function(k) {
			o.value(k, '%s (%d)'.format(categories[k].title, categories[k].count));
		});
		o.description = _('Built-in domain lists. Blocked on top of the custom list above.');

		o = s.taboption('access', form.MultiValue, 'cat_throttle', _('Throttle categories'));
		o.modalonly = true;
		Object.keys(categories).forEach(function(k) {
			o.value(k, '%s (%d)'.format(categories[k].title, categories[k].count));
		});
		o.description = _('Traffic from these categories is limited to the rate below instead of being blocked (e.g. make video streaming unusable while the rest stays fast).');

		o = s.taboption('access', form.Value, 'throttle_rate', _('Throttle rate (kbit/s)'));
		o.modalonly = true;
		o.datatype = 'uinteger';
		o.placeholder = isUser ? _('from profile') : '256';
		if (!isUser)
			o.default = '256';
		o.depends('cat_throttle', /.+/);

		o = s.taboption('access', form.Value, 'conn_max_mb', _('Max download per connection (MB)'));
		o.modalonly = true;
		o.datatype = 'uinteger';
		o.placeholder = isUser ? _('from profile') : '0 = unlimited';
		o.description = _('Cuts any single connection after this many megabytes have been received (works for HTTPS too). Stops large file downloads; streaming and normal browsing use many small requests and are rarely affected. Use together with throttled categories for media control.');
		return o;
	}
});
