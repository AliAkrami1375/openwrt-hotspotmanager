'use strict';
'require view';
'require ui';
'require poll';
'require dom';
'require usermanager.api as api';

function tile(title, value, sub, color) {
	return E('div', { 'class': 'um-tile', 'style': 'flex:1 1 170px;min-width:170px;padding:14px 16px;border:1px solid #e2e8f0;border-radius:12px;background:#fff;border-top:3px solid ' + (color || '#2563eb') }, [
		E('div', { 'style': 'font-size:12px;color:#64748b;text-transform:uppercase;letter-spacing:.04em' }, title),
		E('div', { 'style': 'font-size:' + (String(value).length > 14 ? '17px' : '22px') + ';font-weight:600;margin-top:4px;overflow-wrap:anywhere;word-break:break-word' }, value),
		sub ? E('div', { 'style': 'font-size:12px;color:#64748b;margin-top:2px' }, sub) : ''
	]);
}

function fmtBps(b) {
	b = +b || 0;
	var bits = b * 8;
	if (bits >= 1e6) return '%.2f Mbps'.format(bits / 1e6);
	if (bits >= 1e3) return '%.0f kbps'.format(bits / 1e3);
	return bits + ' bps';
}

function pill(text, color) {
	return E('span', { 'style': 'display:inline-block;padding:2px 8px;border-radius:10px;color:#fff;font-size:11px;background:' + color }, text);
}

return view.extend({
	load: function() {
		return Promise.all([ api.status(), api.sessions() ]);
	},

	renderTiles: function(st, sessions) {
		var totalDown = 0, totalUp = 0, rateDown = 0, rateUp = 0;
		sessions.forEach(function(s) { totalDown += s.down; totalUp += s.up; rateDown += s.rate_down_bps || 0; rateUp += s.rate_up_bps || 0; });
		var healthy = st.running && st.firewall && st.portal_running;
		return E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:12px;margin-bottom:16px' }, [
			tile(_('Service'), healthy ? _('Running') : (st.enabled ? _('Degraded') : _('Disabled')),
				st.enabled ? _('daemon %s · portal %s · resolver %s').format(st.running ? '✓' : '✗', st.portal_running ? '✓' : '✗', st.resolver_running ? '✓' : '✗') : _('Enable it in Settings'),
				healthy ? '#16a34a' : '#dc2626'),
			tile(_('Portal'), st.portal_host || '-', (st.portal_ip || '') + (st.passwall ? ' · ' + st.passwall : ' · ' + _('no proxy framework')), '#6366f1'),
			tile(_('Online users'), String(sessions.length), _('%d direct · %d users · %d profiles').format(st.direct_sessions || 0, st.users, st.profiles), '#0ea5e9'),
			tile(_('Live traffic'), '↓ ' + fmtBps(rateDown), '↑ ' + fmtBps(rateUp), '#f59e0b'),
			tile(_('Capabilities'), (function(c) { c = c || {}; var ok = function(b) { return b ? '✓' : '✗'; }; return E('span', { 'style': 'font-size:13px;line-height:1.5' }, [ 'Passwall ' + ok(c.passwall), ' · xray ' + ok(c.xray), E('br'), 'dnsmasq nftset ' + ok(c.dnsmasq_nftset), ' · TLS ' + ok(c.tls), ' · tunnel ' + ok(c.dbclient) ]); })(st.caps), _('OpenWrt %s · v%s').format((st.caps || {}).openwrt || '?', (st.caps || {}).version || 'dev'), '#0f766e'),
			tile(_('Session totals'), '↓ ' + api.fmtBytes(totalDown), '↑ ' + api.fmtBytes(totalUp) + ' · ' + (st.count_mode == 'download' ? _('download counted') : _('both counted')), '#64748b')
		]);
	},

	renderTable: function(sessions) {
		var self = this;
		var rows = sessions.map(function(s) {
			return [
				E('strong', {}, s.user),
				E('span', {}, [ s.ip, E('br'), E('span', { 'style': 'font-family:monospace;font-size:11px;color:#64748b' }, s.mac) ]),
				s.hostname || '-',
				E('span', {}, [ s.profile, E('br'),
					s.proxy == 'direct' ? pill(_('Direct'), '#c2410c') : ((s.proxy || '').indexOf('pc:') == 0 ? pill(_('Proxy'), '#1d4ed8') : pill(_('Default'), '#047857')),
					' ', s.blocked ? pill(_('filter'), '#7c3aed') : '' ]),
				E('span', {}, [ api.fmtDuration(s.uptime), E('br'), E('span', { 'style': 'font-size:11px;color:#64748b' }, _('idle %s').format(api.fmtDuration(s.idle))) ]),
				E('span', { 'style': 'font-variant-numeric:tabular-nums' }, [ '↓ ' + fmtBps(s.rate_down_bps), E('br'), '↑ ' + fmtBps(s.rate_up_bps) ]),
				E('span', {}, [ '↓ ' + api.fmtBytes(s.down), E('br'), '↑ ' + api.fmtBytes(s.up) ]),
				api.quotaBar(s.used_total, s.quota),
				E('span', { 'style': 'font-size:12px' }, [
					(s.rate_down || s.rate_up) ? ('↓ ' + (s.rate_down ? s.rate_down + ' kbps' : '∞') + ' ↑ ' + (s.rate_up ? s.rate_up + ' kbps' : '∞')) : '∞',
					E('br'),
					s.wifi ? '%s %d dBm'.format(s.wifi.ifname, s.wifi.signal) : _('wired')
				]),
				E('button', {
					'class': 'btn cbi-button cbi-button-remove',
					'click': ui.createHandlerFn(self, function(ip) {
						return api.kick(ip).then(function() { return self.refresh(); });
					}, s.ip)
				}, _('Kick'))
			];
		});

		var table = E('table', { 'class': 'table cbi-section-table' }, [
			E('tr', { 'class': 'tr table-titles' }, [
				E('th', { 'class': 'th' }, _('User')),
				E('th', { 'class': 'th' }, _('IP / MAC')),
				E('th', { 'class': 'th' }, _('Host')),
				E('th', { 'class': 'th' }, _('Profile / route')),
				E('th', { 'class': 'th' }, _('Uptime')),
				E('th', { 'class': 'th' }, _('Live rate')),
				E('th', { 'class': 'th' }, _('Session traffic')),
				E('th', { 'class': 'th' }, _('Total usage / quota')),
				E('th', { 'class': 'th' }, _('Speed limit / link')),
				E('th', { 'class': 'th cbi-section-actions' }, '')
			])
		]);
		cbi_update_table(table, rows, E('em', {}, _('No active sessions')));
		return table;
	},

	refresh: function() {
		var self = this;
		return Promise.all([ api.status(), api.sessions() ]).then(function(data) {
			dom.content(document.getElementById('um-tiles'), self.renderTiles(data[0], data[1]));
			dom.content(document.getElementById('um-sessions'), self.renderTable(data[1]));
		});
	},

	render: function(data) {
		var self = this;
		var st = data[0], sessions = data[1];

		poll.add(function() { return self.refresh(); }, 5);

		return E('div', { 'class': 'cbi-map' }, [
			E('h2', {}, _('Hotspot User Manager')),
			E('div', { 'class': 'cbi-map-descr' }, _('Captive portal with per-user accounts, data quotas, speed limits, Internet route (Passwall or direct), site filters and session control. Clients on the LAN must sign in at the portal before they get Internet access.')),
			E('div', { 'id': 'um-tiles' }, this.renderTiles(st, sessions)),
			E('div', { 'style': 'margin-bottom:12px;display:flex;gap:8px;flex-wrap:wrap' }, [
				E('button', { 'class': 'btn cbi-button cbi-button-action', 'click': ui.createHandlerFn(this, function() {
					return api.service('restart').then(function() { return self.refresh(); });
				}) }, _('Restart service')),
				E('a', { 'class': 'btn cbi-button', 'href': st.portal_url, 'target': '_blank' }, _('Open portal page'))
			]),
			E('h3', {}, _('Active sessions')),
			E('div', { 'id': 'um-sessions' }, this.renderTable(sessions))
		]);
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
