'use strict';
'require view';
'require form';
'require uci';
'require rpc';

var callCategories = rpc.declare({ object: 'luci.usermanager', method: 'categories', expect: { categories: {} } });

return view.extend({
	load: function() {
		return Promise.all([ uci.load('usermanager'), callCategories() ]);
	},

	render: function(data) {
		var categories = data[1] || {};
		var m, s, o;

		m = new form.Map('usermanager', _('Per-site Daily Quotas'),
			_('Limit how much data and/or time each user may spend on a given site (or group of sites) per day. Counting is per user and resets at midnight (router time). When the limit is reached the site shows the "daily limit reached" page until the next day while everything else keeps working.'));

		s = m.section(form.GridSection, 'sitequota', _('Rules'));
		s.anonymous = true;
		s.addremove = true;
		s.nodescriptions = true;
		s.sortable = false;
		s.modaltitle = function(sid) { return _('Site quota') + ' » ' + (uci.get('usermanager', sid, 'name') || _('new')); };

		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;
		o.placeholder = 'YouTube 1h/day';

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.DynamicList, 'domains', _('Sites'));
		o.placeholder = 'youtube.com';
		o.description = _('Domains (subdomains included) or IPv4/CIDR.');

		o = s.option(form.MultiValue, 'categories', _('Categories'));
		o.modalonly = true;
		Object.keys(categories).forEach(function(k) {
			o.value(k, '%s (%d)'.format(categories[k].title, categories[k].count));
		});
		o.description = _('Built-in domain groups added to the sites above.');

		o = s.option(form.Value, 'daily_mb', _('Data per day (MB)'));
		o.datatype = 'uinteger';
		o.placeholder = '0 = no data limit';

		o = s.option(form.Value, 'daily_min', _('Time per day (min)'));
		o.datatype = 'uinteger';
		o.placeholder = '0 = no time limit';
		o.description = _('Active time: every 5-second interval with traffic to the site counts.');

		o = s.option(form.MultiValue, 'profiles', _('Applies to profiles'));
		uci.sections('usermanager', 'profile').forEach(function(p) { o.value(p['.name'], p['.name']); });
		o.description = _('Empty = all users.');

		o = s.option(form.DummyValue, '_sum', _('Summary'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var d = uci.get('usermanager', sid, 'domains') || [], c = uci.get('usermanager', sid, 'categories') || [];
			d = Array.isArray(d) ? d : [ d ]; c = Array.isArray(c) ? c : [ c ];
			var parts = [];
			if (d.length) parts.push(d.slice(0, 3).join(', ') + (d.length > 3 ? ' +' + (d.length - 3) : ''));
			if (c.length) parts.push(c.join(', '));
			return parts.join(' · ') || '-';
		};

		return m.render();
	}
});
