'use strict';
'require view';
'require form';
'require uci';
'require ui';
'require rpc';

var callTunnels = rpc.declare({ object: 'luci.usermanager', method: 'tunnels', expect: {} });
var callSetup = rpc.declare({ object: 'luci.usermanager', method: 'tunnel_setup', params: [ 'sid', 'password' ], expect: {} });

var SCRIPT_URL = 'https://raw.githubusercontent.com/AliAkrami1375/dibachain-openwrt-usermanager/main/server/setup-tunnel-server.sh';

return view.extend({
	load: function() {
		return Promise.all([ uci.load('usermanager'), callTunnels() ]);
	},

	render: function(data) {
		var rep = data[1] || {}, report = rep.tunnels || {}, pubkey = rep.pubkey || '';
		var m, s, o;

		m = new form.Map('usermanager', _('Reverse SSH Tunnels'),
			_('Publish a device on the LAN through a Linux server on the Internet: the router keeps an SSH connection to the server and the server\'s port is tunneled to a hotspot user (follows the user\'s address) or a fixed LAN address. Works even when the router itself has no public IP. After saving a tunnel, press <b>Install key</b> once with the server password: the router\'s SSH key is installed on the server and <code>GatewayPorts</code> is enabled, so no password is stored.'));

		s = m.section(form.GridSection, 'tunnel', _('Tunnels'));
		s.anonymous = true;
		s.addremove = true;
		s.nodescriptions = true;
		s.sortable = false;
		s.modaltitle = function(sid) { return _('Tunnel') + ' » ' + (uci.get('usermanager', sid, 'name') || _('new')); };

		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Value, 'host', _('Server'));
		o.rmempty = false;
		o.placeholder = '203.0.113.10';

		o = s.option(form.Value, 'port', _('SSH port'));
		o.datatype = 'port';
		o.default = '22';
		o.modalonly = true;

		o = s.option(form.Value, 'user', _('SSH user'));
		o.rmempty = false;
		o.default = 'root';

		o = s.option(form.Value, 'remote_port', _('Port on server'));
		o.datatype = 'port';
		o.rmempty = false;
		o.description = _('Clients on the Internet connect to server:this port.');

		o = s.option(form.Value, 'bind', _('Bind address on server'));
		o.default = '0.0.0.0';
		o.modalonly = true;
		o.description = _('0.0.0.0 = reachable from the Internet (needs GatewayPorts), 127.0.0.1 = only from the server itself.');

		o = s.option(form.ListValue, 'target_user', _('Target user'));
		o.value('', _('— fixed IP address —'));
		uci.sections('usermanager', 'user').forEach(function(u) {
			if (u.username) o.value(u.username, u.username + (u.comment ? ' (' + u.comment + ')' : ''));
		});

		o = s.option(form.Value, 'target_ip', _('Target IP'));
		o.datatype = 'ip4addr("nomask")';
		o.depends('target_user', '');
		o.placeholder = '192.168.10.50';

		o = s.option(form.Value, 'target_port', _('Target port'));
		o.datatype = 'port';
		o.rmempty = false;

		o = s.option(form.Value, 'keepalive', _('Keepalive (s)'));
		o.datatype = 'uinteger';
		o.default = '30';
		o.modalonly = true;

		o = s.option(form.DummyValue, '_state', _('State'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var r = report[sid];
			if (!r)
				return E('em', {}, _('not saved'));
			var pill = function(t, c) { return E('span', { 'style': 'display:inline-block;padding:2px 8px;border-radius:10px;color:#fff;font-size:11px;background:' + c }, t); };
			if (r.running)
				return E('span', {}, [ pill(_('connected'), '#16a34a'), ' ', E('span', { 'style': 'font-size:12px' }, r.public_url + ' → ' + r.target) ]);
			if (!r.target)
				return E('span', {}, [ pill(_('paused'), '#64748b'), ' ', E('span', { 'style': 'font-size:12px;color:#64748b' }, r.reason == 'user offline' ? _('user offline') : _('no target')) ]);
			return E('span', {}, [ pill(_('connecting…'), '#f59e0b'), ' ', E('span', { 'style': 'font-size:12px;color:#64748b' }, _('retrying; is the key installed?')) ]);
		};

		o = s.option(form.Button, '_setup', _('Server'));
		o.editable = true;
		o.modalonly = false;
		o.inputtitle = _('Install key');
		o.inputstyle = 'apply';
		o.onclick = function(ev, sid) {
			var host = uci.get('usermanager', sid, 'host'), user = uci.get('usermanager', sid, 'user');
			if (!host || !user || !report[sid])
				return alert(_('Save & Apply the tunnel first.'));
			var pw = prompt(_('Password of %s@%s (used once to install the router key, not stored):').format(user, host));
			if (pw == null || !pw.length)
				return;
			return callSetup(sid, pw).then(function(r) {
				if (r && r.ok)
					ui.addNotification(null, E('p', _('Key installed on %s. %s').format(host, r.gateway ? _('GatewayPorts enabled.') : _('Could not change sshd_config (no root): run the server script or set "GatewayPorts clientspecified" manually.'))), 'info');
				else
					ui.addNotification(null, E('pre', { 'style': 'white-space:pre-wrap' }, _('Key installation failed:') + '\n' + ((r && (r.output || r.error)) || '')), 'error');
				window.setTimeout(function() { location.reload(); }, 1500);
			});
		};

		return m.render().then(function(node) {
			node.appendChild(E('div', { 'class': 'cbi-section' }, [
				E('h3', {}, _('Server preparation')),
				E('p', {}, _('Option A: press "Install key" above with the server password (root or a sudo user). Option B: run the setup script on the server yourself (creates a restricted user, enables GatewayPorts, opens firewall ports) and paste the key below into its authorized_keys:')),
				E('pre', { 'style': 'white-space:pre-wrap;word-break:break-all;background:#f8fafc;padding:10px;border-radius:8px;font-size:12px' },
					'curl -fsSL ' + SCRIPT_URL + ' | sudo bash -s -- --key "' + pubkey + '" --ports 8080'),
				E('p', { 'style': 'font-size:12px;color:#64748b' }, _('Router public key:')),
				E('pre', { 'style': 'white-space:pre-wrap;word-break:break-all;background:#f8fafc;padding:10px;border-radius:8px;font-size:12px' }, pubkey || _('(generated at first setup)'))
			]));
			return node;
		});
	}
});
