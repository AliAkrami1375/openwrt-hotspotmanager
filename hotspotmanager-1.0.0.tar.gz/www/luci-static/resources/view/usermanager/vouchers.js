'use strict';
'require view';
'require uci';
'require ui';
'require dom';
'require usermanager.api as api';

function printCodes(title, codes, profile, portalUrl) {
	var w = window.open('', '_blank');
	if (!w)
		return;
	var cards = codes.map(function(c) {
		return '<div class="c"><div class="t">' + title + '</div>' +
			'<div class="k">' + c + '</div>' +
			'<div class="p">' + profile + '</div>' +
			'<div class="u">' + portalUrl + '</div></div>';
	}).join('');
	w.document.write('<!DOCTYPE html><html><head><meta charset="utf-8"><title>' + title + '</title><style>' +
		'body{font-family:Arial,Tahoma,sans-serif;margin:10mm}' +
		'.g{display:grid;grid-template-columns:repeat(3,1fr);gap:6mm}' +
		'.c{border:1px dashed #888;border-radius:6px;padding:6mm 4mm;text-align:center;page-break-inside:avoid}' +
		'.t{font-size:12px;color:#444}.k{font-size:22px;font-weight:bold;letter-spacing:2px;margin:4mm 0;font-family:monospace}' +
		'.p{font-size:11px;color:#666}.u{font-size:10px;color:#999;margin-top:2mm}' +
		'@media print{button{display:none}}</style></head><body>' +
		'<button onclick="window.print()">Print</button><div class="g">' + cards + '</div></body></html>');
	w.document.close();
}

return view.extend({
	load: function() {
		return Promise.all([ uci.load('usermanager'), api.users(), api.status() ]);
	},

	renderList: function(stats, portalUrl) {
		var vouchers = uci.sections('usermanager', 'user').filter(function(u) { return u.voucher == '1'; });
		var rows = vouchers.map(function(u) {
			var st = stats[u.username] || {};
			return [
				E('code', { 'style': 'font-size:14px' }, u.username),
				u.profile || 'default',
				st.state ? api.stateLabel(st.state) : '-',
				st.quota ? api.quotaBar(st.used || 0, st.quota) : api.fmtBytes(st.used || 0),
				st.first_login ? api.fmtDate(st.first_login) : _('unused'),
				u.comment || ''
			];
		});
		var table = E('table', { 'class': 'table' }, [
			E('tr', { 'class': 'tr table-titles' }, [
				E('th', { 'class': 'th' }, _('Code')),
				E('th', { 'class': 'th' }, _('Profile')),
				E('th', { 'class': 'th' }, _('State')),
				E('th', { 'class': 'th' }, _('Usage')),
				E('th', { 'class': 'th' }, _('First use')),
				E('th', { 'class': 'th' }, _('Batch / comment'))
			])
		]);
		cbi_update_table(table, rows, E('em', {}, _('No vouchers yet')));

		var unused = vouchers.filter(function(u) { return !(stats[u.username] || {}).first_login; });
		return E('div', {}, [
			E('div', { 'style': 'display:flex;gap:8px;align-items:center;margin:8px 0' }, [
				E('h3', { 'style': 'margin:0;flex:1' }, _('Existing vouchers (%d, %d unused)').format(vouchers.length, unused.length)),
				E('button', { 'class': 'btn cbi-button', 'disabled': unused.length ? null : '', 'click': function() {
					printCodes(uci.get('usermanager', 'settings', 'portal_title') || 'Hotspot',
						unused.map(function(u) { return u.username; }), _('mixed profiles'), portalUrl);
				} }, _('Print all unused'))
			]),
			table,
			E('p', { 'style': 'color:#64748b;font-size:12px' }, _('Vouchers are ordinary users with the code as both username and password. Delete or edit them in the Users tab.'))
		]);
	},

	render: function(data) {
		var self = this;
		var stats = data[1] || {}, status = data[2] || {};
		var profiles = uci.sections('usermanager', 'profile').map(function(p) { return p['.name']; });

		var inCount = E('input', { 'type': 'number', 'class': 'cbi-input-text', 'min': 1, 'max': 500, 'value': 10, 'style': 'width:90px' });
		var inLen = E('input', { 'type': 'number', 'class': 'cbi-input-text', 'min': 4, 'max': 32, 'value': 8, 'style': 'width:90px' });
		var inPrefix = E('input', { 'type': 'text', 'class': 'cbi-input-text', 'placeholder': _('optional'), 'style': 'width:120px' });
		var inProfile = E('select', { 'class': 'cbi-input-select' }, profiles.map(function(p) { return E('option', { 'value': p }, p); }));
		var inComment = E('input', { 'type': 'text', 'class': 'cbi-input-text', 'placeholder': _('batch name, e.g. "Cafe October"'), 'style': 'width:240px' });
		var inCharset = E('select', { 'class': 'cbi-input-select' }, [
			E('option', { 'value': 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789' }, _('Letters + digits (no 0/O/1/I)')),
			E('option', { 'value': '0123456789' }, _('Digits only')),
			E('option', { 'value': 'abcdefghjkmnpqrstuvwxyz23456789' }, _('Lowercase + digits'))
		]);
		var result = E('div', { 'id': 'um-voucher-result' });

		function field(label, el) {
			return E('div', { 'style': 'display:flex;flex-direction:column;gap:4px' }, [ E('label', { 'style': 'font-size:12px;color:#64748b' }, label), el ]);
		}

		var genBtn = E('button', { 'class': 'btn cbi-button cbi-button-apply', 'click': ui.createHandlerFn(this, function() {
			return api.generateVouchers(+inCount.value, +inLen.value, inPrefix.value, inProfile.value, inComment.value, inCharset.value).then(function(r) {
				if (!r || !r.codes) {
					ui.addNotification(null, E('p', _('Generating vouchers failed: %s').format((r && r.error) || 'unknown')), 'error');
					return;
				}
				var title = uci.get('usermanager', 'settings', 'portal_title') || 'Hotspot';
				dom.content(result, E('div', { 'class': 'cbi-section' }, [
					E('h3', {}, _('%d new vouchers (profile %s)').format(r.codes.length, r.profile)),
					E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:8px;margin:8px 0' }, r.codes.map(function(c) {
						return E('code', { 'style': 'font-size:16px;padding:6px 10px;border:1px dashed #94a3b8;border-radius:6px' }, c);
					})),
					E('div', { 'style': 'display:flex;gap:8px' }, [
						E('button', { 'class': 'btn cbi-button cbi-button-action', 'click': function() { printCodes(title, r.codes, r.profile, status.portal_url || ''); } }, _('Print')),
						E('button', { 'class': 'btn cbi-button', 'click': function() {
							var blob = new Blob([ r.codes.join('\n') + '\n' ], { type: 'text/plain' });
							var a = document.createElement('a');
							a.href = URL.createObjectURL(blob);
							a.download = 'vouchers-' + r.batch.replace(/[: ]/g, '-') + '.txt';
							a.click();
						} }, _('Download .txt'))
					])
				]));
				return uci.unload('usermanager').then(function() { return uci.load('usermanager'); }).then(function() {
					return api.users();
				}).then(function(st) {
					dom.content(document.getElementById('um-voucher-list'), self.renderList(st, status.portal_url || ''));
				});
			});
		}) }, _('Generate'));

		return E('div', { 'class': 'cbi-map' }, [
			E('h2', {}, _('Vouchers')),
			E('div', { 'class': 'cbi-map-descr' }, _('Generate one-time access codes. A guest enters the code as username at the portal and leaves the password empty.')),
			E('div', { 'class': 'cbi-section' }, [
				E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end' }, [
					field(_('Count'), inCount),
					field(_('Code length'), inLen),
					field(_('Prefix'), inPrefix),
					field(_('Characters'), inCharset),
					field(_('Profile'), inProfile),
					field(_('Comment'), inComment),
					genBtn
				])
			]),
			result,
			E('div', { 'id': 'um-voucher-list' }, this.renderList(stats, status.portal_url || ''))
		]);
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
