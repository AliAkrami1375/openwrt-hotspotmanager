'use strict';
'require view';
'require form';
'require uci';
'require rpc';

var callInterfaces = rpc.declare({ object: 'luci.usermanager', method: 'interfaces', expect: { interfaces: [] } });
var callRoutes = rpc.declare({ object: 'luci.usermanager', method: 'routes', expect: { routes: {} } });

return view.extend({
	load: function() {
		return Promise.all([ uci.load('usermanager'), callInterfaces(), callRoutes() ]);
	},

	render: function(data) {
		var ifaces = data[1] || [], report = data[2] || {};
		var m, s, o;

		m = new form.Map('usermanager', _('Policy Routing'),
			_('Send the traffic of selected clients, users or destinations out through a specific network interface (second WAN, VPN tunnel, WireGuard, 4G…). Matching traffic is also taken out of Passwall, so it really leaves through the chosen interface. Interfaces are detected automatically from the router network configuration.'));

		s = m.section(form.GridSection, 'route', _('Routing rules'));
		s.anonymous = true;
		s.addremove = true;
		s.nodescriptions = true;
		s.sortable = false;
		s.modaltitle = function(sid) { return _('Routing rule') + ' » ' + (uci.get('usermanager', sid, 'name') || _('new')); };

		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.ListValue, 'iface', _('Out through interface'));
		ifaces.forEach(function(i) {
			o.value(i.name, '%s — %s%s%s'.format(i.name, i.device || '?', i.address ? ' ' + i.address : '', i.up ? '' : ' (' + _('down') + ')'));
		});
		o.rmempty = false;

		o = s.option(form.DynamicList, 'src', _('Sources'));
		o.placeholder = '192.168.10.50 / 192.168.10.0/28 / @username';
		o.description = _('Client IPv4 addresses or CIDR ranges, or <code>@username</code> for a hotspot user (follows the user\'s current address). Leave empty to match all clients (destination-only rule).');
		uci.sections('usermanager', 'user').forEach(function(u) {
			if (u.username) o.value('@' + u.username, '@' + u.username);
		});

		o = s.option(form.DynamicList, 'dst', _('Destinations'));
		o.placeholder = 'example.com / 1.2.3.0/24';
		o.description = _('Optional: only traffic to these domains (subdomains included) or IPv4/CIDR uses the interface. Empty = all destinations of the sources.');

		o = s.option(form.DummyValue, '_state', _('State'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var r = report[sid];
			if (!r)
				return E('em', {}, _('not saved'));
			return E('span', {}, [
				E('span', { 'style': 'display:inline-block;padding:2px 8px;border-radius:10px;color:#fff;font-size:11px;background:' + (r.iface_up ? '#16a34a' : '#dc2626') }, r.iface_up ? _('interface up') : _('interface down')),
				' ', E('span', { 'style': 'font-size:12px;color:#64748b' }, _('%d client(s) · %d dest. addresses · mark %s / table %d').format(r.members.length, r.dst_addrs, r.mark, r.table))
			]);
		};

		return m.render().then(function(node) {
			var rows = ifaces.map(function(i) {
				return [ E('strong', {}, i.name), i.proto || '-', i.device || '-', i.address || '-', i.gateway || '-',
					E('span', { 'style': 'color:' + (i.up ? '#16a34a' : '#dc2626') }, i.up ? _('up') : _('down')) ];
			});
			var table = E('table', { 'class': 'table' }, [ E('tr', { 'class': 'tr table-titles' }, [ _('Interface'), _('Protocol'), _('Device'), _('Address'), _('Gateway'), _('State') ].map(function(h) { return E('th', { 'class': 'th' }, h); })) ]);
			cbi_update_table(table, rows, E('em', {}, _('No interfaces')));
			node.appendChild(E('div', { 'class': 'cbi-section' }, [
				E('h3', {}, _('Detected interfaces')),
				table,
				E('p', { 'style': 'color:#64748b;font-size:12px' }, _('The interface must belong to a firewall zone with masquerading (the default wan zone and the Passwall/VPN zones do). While an interface is down its routed traffic is blackholed rather than leaking through the default route.'))
			]));
			return node;
		});
	}
});
