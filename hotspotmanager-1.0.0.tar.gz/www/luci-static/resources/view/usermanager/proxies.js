'use strict';
'require view';
'require form';
'require uci';
'require rpc';

var callProxies = rpc.declare({ object: 'luci.usermanager', method: 'proxies', expect: {} });
var callInterfaces = rpc.declare({ object: 'luci.usermanager', method: 'interfaces', expect: { interfaces: [] } });

function pill(t, c) { return E('span', { 'style': 'display:inline-block;padding:2px 8px;border-radius:10px;color:#fff;font-size:11px;background:' + c }, t); }

return view.extend({
	load: function() {
		return Promise.all([ uci.load('usermanager'), callProxies(), callInterfaces() ]);
	},

	render: function(data) {
		var rep = data[1] || {}, ifaces = data[2] || [];
		var m, s, o;

		m = new form.Map('usermanager', _('Proxies'),
			_('<b>Upstream proxies</b> are proxy servers somewhere else (a node you installed, a SOCKS/HTTP/Shadowsocks/VLESS/VMess/Trojan server). Each one may be bound to a router interface, so the proxy connection itself leaves through that network. Assign an upstream proxy to a profile or user (Internet route) and all of their TCP traffic is pushed through it transparently; filters, quotas and speed limits still apply. <b>Proxy servers</b> are SOCKS5/HTTP endpoints on the router that any device can use; their traffic leaves through a chosen interface or an upstream proxy.'));

		var status = E('div', { 'style': 'margin:0 0 12px' }, [
			rep.xray_available ? pill(_('xray %s').format(rep.xray_version || ''), rep.xray_running ? '#16a34a' : '#f59e0b') : pill(_('xray not installed'), '#dc2626'),
			' ', E('span', { 'style': 'font-size:12px;color:#64748b' }, rep.xray_running ? _('proxy engine running') : (rep.xray_available ? _('engine starts when a proxy is in use') : _('install the xray package (opkg install xray-core) or Passwall2')))
		]);

		// ---- upstream proxies
		s = m.section(form.GridSection, 'proxyclient', _('Upstream proxies'));
		s.anonymous = true;
		s.addremove = true;
		s.nodescriptions = true;
		s.sortable = false;
		s.modaltitle = function(sid) { return _('Upstream proxy') + ' » ' + (uci.get('usermanager', sid, 'name') || _('new')); };

		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.ListValue, 'type', _('Type'));
		o.value('node', _('Managed node (installed from the Nodes tab)'));
		o.value('socks', 'SOCKS5');
		o.value('http', 'HTTP / HTTPS proxy');
		o.value('ss', 'Shadowsocks');
		o.value('vless', 'VLESS');
		o.value('vmess', 'VMess');
		o.value('trojan', 'Trojan');
		o.value('json', _('Raw xray outbound (JSON)'));
		o.default = 'node';

		o = s.option(form.ListValue, 'node', _('Node'));
		o.depends('type', 'node');
		uci.sections('usermanager', 'node').forEach(function(n) { o.value(n['.name'], n.name || n['.name']); });
		o.modalonly = true;

		o = s.option(form.Value, 'host', _('Server'));
		o.depends({ type: 'socks' }); o.depends({ type: 'http' }); o.depends({ type: 'ss' }); o.depends({ type: 'vless' }); o.depends({ type: 'vmess' }); o.depends({ type: 'trojan' });
		o.modalonly = true;

		o = s.option(form.Value, 'port', _('Port'));
		o.datatype = 'port';
		o.depends({ type: 'socks' }); o.depends({ type: 'http' }); o.depends({ type: 'ss' }); o.depends({ type: 'vless' }); o.depends({ type: 'vmess' }); o.depends({ type: 'trojan' });
		o.modalonly = true;

		o = s.option(form.Value, 'username', _('Username'));
		o.depends({ type: 'socks' }); o.depends({ type: 'http' });
		o.modalonly = true;

		o = s.option(form.Value, 'password', _('Password'));
		o.depends({ type: 'socks' }); o.depends({ type: 'http' }); o.depends({ type: 'ss' }); o.depends({ type: 'trojan' });
		o.modalonly = true;

		o = s.option(form.ListValue, 'method', _('Cipher'));
		o.depends('type', 'ss');
		[ 'aes-256-gcm', 'aes-128-gcm', 'chacha20-ietf-poly1305', '2022-blake3-aes-128-gcm', '2022-blake3-aes-256-gcm', '2022-blake3-chacha20-poly1305' ].forEach(function(c) { o.value(c, c); });
		o.modalonly = true;

		o = s.option(form.Value, 'uuid', _('UUID'));
		o.depends({ type: 'vless' }); o.depends({ type: 'vmess' });
		o.modalonly = true;

		o = s.option(form.Value, 'flow', _('Flow'));
		o.depends('type', 'vless');
		o.placeholder = 'xtls-rprx-vision';
		o.modalonly = true;

		o = s.option(form.ListValue, 'security', _('Security'));
		o.depends({ type: 'vless' }); o.depends({ type: 'vmess' }); o.depends({ type: 'trojan' }); o.depends({ type: 'http' });
		o.value('none', _('none'));
		o.value('tls', 'TLS');
		o.value('reality', 'REALITY');
		o.modalonly = true;

		o = s.option(form.Value, 'sni', _('SNI / server name'));
		o.depends({ security: 'tls' }); o.depends({ security: 'reality' });
		o.modalonly = true;

		o = s.option(form.Value, 'public_key', _('REALITY public key'));
		o.depends('security', 'reality');
		o.modalonly = true;

		o = s.option(form.Value, 'short_id', _('REALITY short id'));
		o.depends('security', 'reality');
		o.modalonly = true;

		o = s.option(form.Flag, 'insecure', _('Allow insecure TLS'));
		o.depends('security', 'tls');
		o.modalonly = true;

		o = s.option(form.ListValue, 'network', _('Transport'));
		o.depends({ type: 'vless' }); o.depends({ type: 'vmess' }); o.depends({ type: 'trojan' });
		o.value('tcp', 'TCP');
		o.value('ws', 'WebSocket');
		o.value('grpc', 'gRPC');
		o.value('xhttp', 'XHTTP');
		o.modalonly = true;

		o = s.option(form.Value, 'path', _('Path / service name'));
		o.depends({ network: 'ws' }); o.depends({ network: 'grpc' }); o.depends({ network: 'xhttp' });
		o.modalonly = true;

		o = s.option(form.Value, 'host_header', _('Host header'));
		o.depends({ network: 'ws' }); o.depends({ network: 'xhttp' });
		o.modalonly = true;

		o = s.option(form.TextValue, 'json', _('Outbound JSON'));
		o.depends('type', 'json');
		o.rows = 8;
		o.modalonly = true;

		o = s.option(form.ListValue, 'iface', _('Connect through interface'));
		o.value('', _('default route'));
		ifaces.forEach(function(i) { o.value(i.name, '%s (%s%s)'.format(i.name, i.device || '?', i.up ? '' : ', down')); });

		o = s.option(form.DummyValue, '_state', _('State'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var r = (rep.clients || {})[sid];
			if (!r) return E('em', {}, _('not saved'));
			return E('span', { 'style': 'font-size:12px' }, [
				r.node_ok ? pill(_('ready'), '#16a34a') : pill(_('node not installed'), '#dc2626'),
				' ', _('%d user(s)').format(r.users), r.iface ? ' · ' + _('via %s').format(r.iface) : ''
			]);
		};

		// ---- proxy servers on the router
		var s2 = m.section(form.GridSection, 'proxyserver', _('Proxy servers on the router'));
		s2.anonymous = true;
		s2.addremove = true;
		s2.nodescriptions = true;
		s2.sortable = false;
		s2.modaltitle = function(sid) { return _('Proxy server') + ' » ' + (uci.get('usermanager', sid, 'name') || _('new')); };

		o = s2.option(form.Value, 'name', _('Name'));
		o.rmempty = false;

		o = s2.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s2.option(form.ListValue, 'type', _('Type'));
		o.value('socks', 'SOCKS5');
		o.value('http', 'HTTP');
		o.default = 'socks';

		o = s2.option(form.Value, 'port', _('Port'));
		o.datatype = 'port';
		o.rmempty = false;
		o.placeholder = '1080';

		o = s2.option(form.ListValue, 'listen', _('Listen on'));
		o.value('lan', _('LAN address only'));
		o.value('all', _('all addresses'));
		o.default = 'lan';
		o.modalonly = true;

		o = s2.option(form.Value, 'username', _('Username (optional auth)'));
		o.modalonly = true;

		o = s2.option(form.Value, 'password', _('Password'));
		o.modalonly = true;

		o = s2.option(form.ListValue, 'upstream', _('Traffic goes'));
		o.value('direct', _('directly out (choose interface)'));
		uci.sections('usermanager', 'proxyclient').forEach(function(p) { o.value('pc:' + p['.name'], _('through upstream proxy "%s"').format(p.name || p['.name'])); });
		o.default = 'direct';

		o = s2.option(form.ListValue, 'iface', _('Out through interface'));
		o.depends('upstream', 'direct');
		o.value('', _('default route'));
		ifaces.forEach(function(i) { o.value(i.name, '%s (%s%s)'.format(i.name, i.device || '?', i.up ? '' : ', down')); });

		o = s2.option(form.DummyValue, '_url', _('Address'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var r = (rep.servers || {})[sid];
			return r ? E('code', {}, r.url) : E('em', {}, _('not saved'));
		};

		return m.render().then(function(node) {
			node.insertBefore(status, node.firstChild.nextSibling);
			if (rep.log)
				node.appendChild(E('div', { 'class': 'cbi-section' }, [ E('h3', {}, _('Proxy engine log')), E('pre', { 'style': 'font-size:11px;max-height:200px;overflow:auto' }, rep.log) ]));
			return node;
		});
	}
});
