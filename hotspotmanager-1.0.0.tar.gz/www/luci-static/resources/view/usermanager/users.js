'use strict';
'require view';
'require form';
'require uci';
'require ui';
'require usermanager.api as api';
'require usermanager.catopts as catopts';

function fmtRate(kbit) {
	kbit = +kbit || 0;
	if (!kbit)
		return '∞';
	return kbit >= 1000 ? '%.1f Mbps'.format(kbit / 1000) : kbit + ' kbps';
}

return view.extend({
	load: function() {
		return Promise.all([ uci.load('usermanager'), api.users(), catopts.categories() ]);
	},

	render: function(data) {
		var stats = data[1] || {}, categories = data[2] || {};
		var m, s, o;

		m = new form.Map('usermanager', _('Hotspot Users'),
			_('Accounts that may sign in at the captive portal. Limits, Internet route and blocked sites come from the profile unless overridden per user. Passwords are stored in clear text (like MikroTik User Manager) so vouchers can be printed.'));

		s = m.section(form.GridSection, 'user', _('Users'));
		s.anonymous = true;
		s.addremove = true;
		s.sortable = false;
		s.nodescriptions = true;
		s.modaltitle = function(sid) {
			return _('User') + ' » ' + (uci.get('usermanager', sid, 'username') || _('new'));
		};

		s.tab('account', _('Account'));
		s.tab('limits', _('Limits (override profile)'));
		s.tab('access', _('Route & filter'));

		s.handleRemove = function(sid, ev) {
			var name = uci.get('usermanager', sid, 'username');
			var res = form.GridSection.prototype.handleRemove.apply(this, [ sid, ev ]);
			if (name)
				api.kickUser(name).then(function() { return api.forgetUser(name); });
			return res;
		};

		o = s.taboption('account', form.Value, 'username', _('Username'));
		o.rmempty = false;
		o.validate = function(sid, value) {
			if (!/^[A-Za-z0-9@._\-]{1,64}$/.test(value))
				return _('Only letters, digits and @ . _ - are allowed');
			var dup = uci.sections('usermanager', 'user').filter(function(u) {
				return u['.name'] != sid && u.username == value;
			});
			return dup.length ? _('Username already exists') : true;
		};

		o = s.taboption('account', form.Value, 'password', _('Password'));
		o.rmempty = false;
		o.description = _('Users may change it themselves at the portal; the date of the last self-service change is shown in the list.');

		o = s.taboption('account', form.DummyValue, 'pw_changed', _('Changed by user'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var v = uci.get('usermanager', sid, 'pw_changed');
			return v ? E('span', { 'style': 'font-size:12px;color:#047857' }, v) : E('span', { 'style': 'font-size:12px;color:#94a3b8' }, _('never'));
		};

		o = s.taboption('account', form.ListValue, 'profile', _('Profile'));
		uci.sections('usermanager', 'profile').forEach(function(p) {
			o.value(p['.name'], p['.name']);
		});
		o.default = 'default';

		o = s.taboption('account', form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s.taboption('account', form.Value, 'mac', _('Bind to MAC'));
		o.datatype = 'macaddr';
		o.placeholder = _('any device');
		o.modalonly = true;

		o = s.taboption('account', form.Value, 'valid_until', _('Valid until'));
		o.placeholder = 'YYYY-MM-DD [HH:MM]';
		o.modalonly = true;
		o.validate = function(sid, v) {
			if (!v || /^\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2})?$/.test(v))
				return true;
			return _('Use the format YYYY-MM-DD or YYYY-MM-DD HH:MM');
		};

		o = s.taboption('account', form.Flag, 'voucher', _('Voucher'));
		o.modalonly = true;

		o = s.taboption('account', form.Value, 'comment', _('Comment'));

		o = s.taboption('limits', form.Value, 'quota_mb', _('Data quota (MB)'));
		o.datatype = 'uinteger';
		o.placeholder = _('from profile');
		o.modalonly = true;

		o = s.taboption('limits', form.Value, 'rate_down', _('Download limit (kbit/s)'));
		o.datatype = 'uinteger';
		o.placeholder = _('from profile');
		o.modalonly = true;

		o = s.taboption('limits', form.Value, 'rate_up', _('Upload limit (kbit/s)'));
		o.datatype = 'uinteger';
		o.placeholder = _('from profile');
		o.modalonly = true;

		o = s.taboption('access', form.ListValue, 'proxy', _('Internet route'));
		o.value('', _('from profile'));
		o.value('passwall', _('Default route (through Passwall when installed)'));
		o.value('direct', _('Direct (no proxy)'));
		uci.sections('usermanager', 'proxyclient').forEach(function(p) { o.value('pc:' + p['.name'], _('Upstream proxy: %s').format(p.name || p['.name'])); });
		o.modalonly = true;

		o = s.taboption('access', form.DynamicList, 'block', _('Blocked sites / apps'));
		o.modalonly = true;
		o.placeholder = 'instagram.com';
		o.description = _('Additional domains or IPv4/CIDR this user cannot reach (on top of the profile and global lists).');

		catopts.add(s, form, categories, true);

		// ---- computed columns
		o = s.taboption('account', form.DummyValue, '_state', _('State'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var name = uci.get('usermanager', sid, 'username');
			var st = stats[name];
			if (!st)
				return E('em', {}, _('not saved'));
			var out = [ api.stateLabel(st.state) ];
			if (st.online > 1)
				out.push(' ×' + st.online);
			return E('span', {}, out);
		};

		o = s.taboption('account', form.DummyValue, '_usage', _('Usage'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var name = uci.get('usermanager', sid, 'username');
			var st = stats[name];
			if (!st)
				return '-';
			return api.quotaBar(st.used, st.quota);
		};

		o = s.taboption('account', form.DummyValue, '_limits', _('Speed / route'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var name = uci.get('usermanager', sid, 'username');
			var st = stats[name];
			if (!st)
				return '-';
			var blk = (uci.get('usermanager', sid, 'block') || []).length;
			return E('span', { 'style': 'font-size:12px' }, [
				'↓ ' + fmtRate(st.rate_down) + ' ↑ ' + fmtRate(st.rate_up), E('br'),
				E('span', { 'style': 'display:inline-block;padding:1px 7px;border-radius:9px;font-size:11px;color:#fff;background:' + (st.proxy == 'direct' ? '#c2410c' : '#047857') },
					st.proxy == 'direct' ? _('Direct') : _('Passwall')),
				blk ? ' ' + _('%d blocked').format(blk) : ''
			]);
		};

		o = s.taboption('account', form.DummyValue, '_expires', _('Expires'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var name = uci.get('usermanager', sid, 'username');
			var st = stats[name];
			if (!st)
				return '-';
			if (!st.expires)
				return st.first_login ? _('never') : _('on first login');
			return api.fmtDate(st.expires);
		};

		o = s.taboption('account', form.DummyValue, '_last', _('Last login'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var name = uci.get('usermanager', sid, 'username');
			var st = stats[name];
			if (!st || !st.last_login)
				return '-';
			return api.fmtDate(st.last_login) + (st.last_ip ? ' (' + st.last_ip + ')' : '');
		};

		o = s.taboption('account', form.Button, '_reset', _('Counters'));
		o.editable = true;
		o.modalonly = false;
		o.inputtitle = _('Reset');
		o.inputstyle = 'reset';
		o.onclick = function(ev, sid) {
			var name = uci.get('usermanager', sid, 'username');
			if (!name)
				return;
			if (!confirm(_('Reset data and time usage of "%s"? The validity period starts again at the next login.').format(name)))
				return;
			return api.resetUsage(name).then(function() {
				ui.addNotification(null, E('p', _('Usage of %s has been reset.').format(name)), 'info');
				window.setTimeout(function() { location.reload(); }, 800);
			});
		};

		o = s.taboption('account', form.Button, '_kick', _('Session'));
		o.editable = true;
		o.modalonly = false;
		o.inputtitle = _('Kick');
		o.inputstyle = 'remove';
		o.onclick = function(ev, sid) {
			var name = uci.get('usermanager', sid, 'username');
			if (!name)
				return;
			return api.kickUser(name).then(function(r) {
				ui.addNotification(null, E('p', _('%d session(s) of %s closed.').format(r.closed || 0, name)), 'info');
				window.setTimeout(function() { location.reload(); }, 800);
			});
		};

		return m.render();
	}
});
