'use strict';
'require view';
'require form';
'require uci';
'require rpc';
'require usermanager.api as api';

var callForwards = rpc.declare({ object: 'luci.usermanager', method: 'forwards', expect: { forwards: {} } });

return view.extend({
	load: function() {
		return Promise.all([ uci.load('usermanager'), callForwards(), api.status() ]);
	},

	render: function(data) {
		var report = data[1] || {}, status = data[2] || {};
		var m, s, o;

		m = new form.Map('usermanager', _('Port Forwards'),
			_('Forward ports from the Internet side to a hotspot user or a fixed LAN address. A forward to a <b>user</b> follows that user automatically: it points at the device the user is logged in from and is paused while the user is offline. The router WAN must itself be reachable from the Internet (a public IP, or a forward on the upstream router).'));

		s = m.section(form.GridSection, 'forward', _('Forwards'));
		s.anonymous = true;
		s.addremove = true;
		s.nodescriptions = true;
		s.sortable = false;
		s.modaltitle = function(sid) { return _('Port forward') + ' » ' + (uci.get('usermanager', sid, 'name') || _('new')); };

		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.ListValue, 'proto', _('Protocol'));
		o.value('tcp', 'TCP');
		o.value('udp', 'UDP');
		o.value('both', 'TCP + UDP');
		o.default = 'tcp';

		o = s.option(form.Value, 'src_port', _('External port'));
		o.rmempty = false;
		o.placeholder = '8080 or 5000-5010';
		o.validate = function(sid, v) {
			return /^\d{1,5}(-\d{1,5})?$/.test(v) ? true : _('Port or port range, e.g. 8080 or 5000-5010');
		};

		o = s.option(form.ListValue, 'dest_user', _('Forward to user'));
		o.value('', _('— fixed IP address —'));
		uci.sections('usermanager', 'user').forEach(function(u) {
			if (u.username)
				o.value(u.username, u.username + (u.comment ? ' (' + u.comment + ')' : ''));
		});

		o = s.option(form.Value, 'dest_ip', _('Fixed IP address'));
		o.datatype = 'ip4addr("nomask")';
		o.depends('dest_user', '');
		o.placeholder = '192.168.10.50';

		o = s.option(form.Value, 'dest_port', _('Internal port'));
		o.datatype = 'port';
		o.placeholder = _('same as external');

		o = s.option(form.DummyValue, '_state', _('State'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var r = report[sid];
			if (!r)
				return E('em', {}, _('not saved'));
			if (r.active)
				return E('span', { 'style': 'color:#16a34a;font-weight:600' }, _('active → %s').format(r.target));
			return E('span', { 'style': 'color:#64748b' }, r.reason == 'user offline' ? _('paused (user offline)') : _('no target'));
		};

		return m.render().then(function(node) {
			node.appendChild(E('div', { 'class': 'cbi-section' }, [
				E('p', { 'style': 'color:#64748b;font-size:13px' }, _('Current WAN side: forwards accept packets arriving on any interface except %s. Classic forwards for non-hotspot devices can also be made under Network → Firewall → Port Forwards.').format(status.lan_dev || 'br-lan'))
			]));
			return node;
		});
	}
});
