'use strict';
'require view';
'require poll';
'require dom';
'require usermanager.api as api';

return view.extend({
	load: function() {
		return api.log(300);
	},

	render: function(logText) {
		var pre = E('pre', { 'id': 'um-log', 'style': 'max-height:70vh;overflow:auto;font-size:12px;white-space:pre-wrap' }, logText || _('No log entries yet'));

		poll.add(function() {
			return api.log(300).then(function(t) {
				var atBottom = pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 20;
				dom.content(pre, t || _('No log entries yet'));
				if (atBottom)
					pre.scrollTop = pre.scrollHeight;
			});
		}, 10);

		return E('div', { 'class': 'cbi-map' }, [
			E('h2', {}, _('Hotspot Log')),
			E('div', { 'class': 'cbi-map-descr' }, _('Logins, logouts and enforcement events (quota, idle, expiry). Refreshes every 10 seconds.')),
			E('div', { 'class': 'cbi-section' }, pre)
		]);
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
