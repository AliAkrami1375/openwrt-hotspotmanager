'use strict';
'require view';
'require form';
'require uci';
'require usermanager.catopts as catopts';

return view.extend({
	load: function() {
		return Promise.all([ uci.load('usermanager'), catopts.categories() ]);
	},

	render: function(data) {
		var categories = data[1] || {};
		var m, s, o;

		m = new form.Map('usermanager', _('Hotspot Profiles'),
			_('A profile bundles the limits that apply to its users: data quota, speed, validity, session rules, Internet route and blocked sites. A value of 0 means unlimited. Users whose profile is deleted fall back to the "default" profile.'));

		s = m.section(form.GridSection, 'profile', _('Profiles'));
		s.anonymous = false;
		s.addremove = true;
		s.nodescriptions = true;
		s.sortable = false;
		s.modaltitle = function(sid) { return _('Profile') + ' » ' + sid; };

		s.tab('limits', _('Limits'));
		s.tab('session', _('Session'));
		s.tab('access', _('Route & filter'));

		o = s.taboption('limits', form.Value, 'quota_mb', _('Data quota (MB)'));
		o.datatype = 'uinteger';
		o.default = '0';
		o.placeholder = '0 = unlimited';

		o = s.taboption('limits', form.Value, 'rate_down', _('Download (kbit/s)'));
		o.datatype = 'uinteger';
		o.default = '0';
		o.placeholder = '0 = unlimited';

		o = s.taboption('limits', form.Value, 'rate_up', _('Upload (kbit/s)'));
		o.datatype = 'uinteger';
		o.default = '0';
		o.placeholder = '0 = unlimited';

		o = s.taboption('limits', form.Value, 'validity_days', _('Validity (days)'));
		o.datatype = 'uinteger';
		o.default = '0';
		o.description = _('Counted from the first login of the user.');

		o = s.taboption('limits', form.Value, 'time_limit_min', _('Total time (min)'));
		o.datatype = 'uinteger';
		o.default = '0';
		o.description = _('Maximum online time per user, summed over all sessions.');

		o = s.taboption('session', form.Value, 'session_timeout', _('Session timeout (s)'));
		o.datatype = 'uinteger';
		o.default = '0';
		o.modalonly = true;
		o.description = _('A session is closed after this many seconds regardless of activity.');

		o = s.taboption('session', form.Value, 'idle_timeout', _('Idle timeout (s)'));
		o.datatype = 'uinteger';
		o.default = '900';
		o.description = _('Session is closed when no traffic is seen for this long.');

		o = s.taboption('session', form.Value, 'shared_users', _('Shared users'));
		o.datatype = 'uinteger';
		o.default = '1';
		o.description = _('How many devices may be online with the same account at once.');

		o = s.taboption('session', form.Value, 'mac_cookie_hours', _('Remember device (h)'));
		o.datatype = 'uinteger';
		o.default = '0';
		o.modalonly = true;
		o.description = _('Devices that signed in are let through again without a password for this many hours (MAC cookie).');

		o = s.taboption('access', form.ListValue, 'proxy', _('Internet route'));
		o.value('passwall', _('Default route (through Passwall when installed)'));
		o.value('direct', _('Direct (no proxy)'));
		uci.sections('usermanager', 'proxyclient').forEach(function(p) { o.value('pc:' + p['.name'], _('Upstream proxy: %s').format(p.name || p['.name'])); });
		o.default = 'passwall';

		o = s.taboption('access', form.DynamicList, 'block', _('Blocked sites / apps'));
		o.modalonly = true;
		o.placeholder = 'instagram.com';
		o.description = _('Domains (subdomains included) or IPv4/CIDR that users of this profile cannot reach.');

		catopts.add(s, form, categories, false);

		o = s.taboption('access', form.DummyValue, '_block', _('Filter'));
		o.cfgvalue = function(sid) {
			var l = uci.get('usermanager', sid, 'block') || [];
			var cb = uci.get('usermanager', sid, 'cat_block') || [];
			var ct = uci.get('usermanager', sid, 'cat_throttle') || [];
			l = Array.isArray(l) ? l : [ l ]; cb = Array.isArray(cb) ? cb : [ cb ]; ct = Array.isArray(ct) ? ct : [ ct ];
			var parts = [];
			if (l.length) parts.push(_('%d domains').format(l.length));
			if (cb.length) parts.push(_('block: %s').format(cb.join(', ')));
			if (ct.length) parts.push(_('throttle: %s @ %s kbps').format(ct.join(', '), uci.get('usermanager', sid, 'throttle_rate') || '256'));
			return parts.length ? parts.join(' · ') : _('none');
		};

		return m.render();
	}
});
