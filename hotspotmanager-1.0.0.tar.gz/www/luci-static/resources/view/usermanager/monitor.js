'use strict';
'require view';
'require ui';
'require uci';
'require poll';
'require dom';
'require rpc';
'require usermanager.api as api';

// defined here as well so a browser holding an older cached api.js still works
var callUserDetail = rpc.declare({ object: 'luci.usermanager', method: 'user_detail', params: [ 'username' ], expect: {} });
var callKick = rpc.declare({ object: 'luci.usermanager', method: 'kick', params: [ 'ip' ], expect: {} });

var HISTORY_POINTS = 60;   // 5 s poll → 5 minutes of live rate

function fmtBps(b) {
	b = +b || 0;
	var bits = b * 8;
	if (bits >= 1e6) return '%.2f Mbps'.format(bits / 1e6);
	if (bits >= 1e3) return '%.0f kbps'.format(bits / 1e3);
	return bits + ' bps';
}

function pill(text, color) {
	return E('span', { 'style': 'display:inline-block;padding:2px 9px;border-radius:10px;color:#fff;font-size:11px;background:' + color }, text);
}

function card(title, body, extra) {
	return E('div', { 'class': 'cbi-section', 'style': 'padding:14px 16px;border:1px solid #e2e8f0;border-radius:12px;background:#fff;margin-bottom:14px;' + (extra || '') }, [
		E('h3', { 'style': 'margin:0 0 10px;font-size:15px' }, title),
		body
	]);
}

function kv(rows) {
	return E('table', { 'class': 'table', 'style': 'font-size:13px' }, rows.map(function(r) {
		return E('tr', { 'class': 'tr' }, [
			E('td', { 'class': 'td', 'style': 'color:#64748b;width:45%' }, r[0]),
			E('td', { 'class': 'td' }, r[1])
		]);
	}));
}

// tiny inline-SVG sparkline (two series)
function sparkline(down, up) {
	var W = 600, H = 90, n = HISTORY_POINTS;
	var max = 1;
	down.concat(up).forEach(function(v) { if (v > max) max = v; });
	function path(series) {
		var d = '';
		for (var i = 0; i < series.length; i++) {
			var x = (i / (n - 1)) * W, y = H - (series[i] / max) * (H - 6) - 3;
			d += (i ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1);
		}
		return d;
	}
	var pad = n - down.length;
	var dn = new Array(pad).fill(0).concat(down), upv = new Array(pad).fill(0).concat(up);
	return E('svg', { 'viewBox': '0 0 ' + W + ' ' + H, 'style': 'width:100%;height:90px;display:block;background:#f8fafc;border-radius:8px' }, [
		E('path', { 'd': path(dn) + ' L' + W + ' ' + H + ' L0 ' + H + ' Z', 'fill': 'rgba(37,99,235,.12)', 'stroke': 'none' }),
		E('path', { 'd': path(dn), 'fill': 'none', 'stroke': '#2563eb', 'stroke-width': '2' }),
		E('path', { 'd': path(upv), 'fill': 'none', 'stroke': '#f59e0b', 'stroke-width': '2' }),
		E('text', { 'x': '6', 'y': '14', 'style': 'font-size:11px;fill:#64748b' }, _('peak %s').format(fmtBps(max)))
	]);
}

function bars(daily) {
	var max = 1;
	daily.forEach(function(d) { if (d.bytes > max) max = d.bytes; });
	return E('div', { 'style': 'display:flex;align-items:flex-end;gap:6px;height:120px' }, daily.map(function(d) {
		var h = Math.max(2, Math.round(d.bytes / max * 100));
		return E('div', { 'style': 'flex:1;display:flex;flex-direction:column;align-items:center;gap:4px', 'title': d.date + ': ' + api.fmtBytes(d.bytes) }, [
			E('div', { 'style': 'font-size:10px;color:#64748b;white-space:nowrap' }, d.bytes ? api.fmtBytes(d.bytes) : ''),
			E('div', { 'style': 'width:100%;height:' + h + 'px;background:linear-gradient(180deg,#60a5fa,#2563eb);border-radius:4px 4px 0 0' }),
			E('div', { 'style': 'font-size:10px;color:#64748b' }, d.date.slice(5))
		]);
	}));
}

return view.extend({
	hist: { down: [], up: [] },

	load: function() {
		return Promise.all([ uci.load('usermanager'), api.sessions() ]);
	},

	currentUser: function() {
		var m = /[?&]user=([^&]+)/.exec(window.location.search);
		return m ? decodeURIComponent(m[1]) : (this.selectedUser || '');
	},

	renderDetail: function(d) {
		var self = this;
		if (!d || d.error)
			return E('div', { 'class': 'alert-message warning' }, d && d.error ? d.error : _('No data'));

		var rateDown = 0, rateUp = 0;
		d.active.forEach(function(s) { rateDown += s.rate_down_bps || 0; rateUp += s.rate_up_bps || 0; });
		this.hist.down.push(rateDown); this.hist.up.push(rateUp);
		if (this.hist.down.length > HISTORY_POINTS) { this.hist.down.shift(); this.hist.up.shift(); }

		var st = d.stats, lim = d.limits;
		var head = E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:12px;margin-bottom:14px' }, [
			E('div', { 'style': 'flex:1 1 220px;padding:14px 16px;border-radius:12px;background:#fff;border:1px solid #e2e8f0;border-top:3px solid ' + (st.state == 'online' ? '#16a34a' : '#64748b') }, [
				E('div', { 'style': 'font-size:12px;color:#64748b;text-transform:uppercase' }, _('User')),
				E('div', { 'style': 'font-size:22px;font-weight:600' }, d.username),
				E('div', { 'style': 'margin-top:4px' }, [ api.stateLabel(st.state), ' ', pill(d.profile, '#6366f1'), ' ', lim.proxy == 'direct' ? pill(_('Direct'), '#c2410c') : pill(_('Passwall'), '#047857') ]),
				E('div', { 'style': 'font-size:12px;color:#64748b;margin-top:4px' }, d.comment || '')
			]),
			E('div', { 'style': 'flex:1 1 220px;padding:14px 16px;border-radius:12px;background:#fff;border:1px solid #e2e8f0;border-top:3px solid #f59e0b' }, [
				E('div', { 'style': 'font-size:12px;color:#64748b;text-transform:uppercase' }, _('Live rate')),
				E('div', { 'style': 'font-size:22px;font-weight:600' }, '↓ ' + fmtBps(rateDown)),
				E('div', { 'style': 'font-size:13px;color:#64748b' }, '↑ ' + fmtBps(rateUp) + (lim.rate_down || lim.rate_up ? ' · ' + _('limit ↓%s ↑%s').format(lim.rate_down || '∞', lim.rate_up || '∞') + ' kbps' : ''))
			]),
			E('div', { 'style': 'flex:1 1 220px;padding:14px 16px;border-radius:12px;background:#fff;border:1px solid #e2e8f0;border-top:3px solid #2563eb' }, [
				E('div', { 'style': 'font-size:12px;color:#64748b;text-transform:uppercase' }, _('Quota')),
				api.quotaBar(st.used, st.quota),
				E('div', { 'style': 'font-size:12px;color:#64748b;margin-top:4px' }, _('↑ %s · ↓ %s total · %d logins').format(api.fmtBytes(st.up), api.fmtBytes(st.down), st.logins))
			]),
			E('div', { 'style': 'flex:1 1 220px;padding:14px 16px;border-radius:12px;background:#fff;border:1px solid #e2e8f0;border-top:3px solid #a855f7' }, [
				E('div', { 'style': 'font-size:12px;color:#64748b;text-transform:uppercase' }, _('Validity')),
				E('div', { 'style': 'font-size:16px;font-weight:600' }, st.expires ? api.fmtDate(st.expires) : _('no expiry')),
				E('div', { 'style': 'font-size:12px;color:#64748b;margin-top:4px' }, _('online time %s%s').format(api.fmtDuration(st.time_used), lim.time_limit ? ' / ' + api.fmtDuration(lim.time_limit) : ''))
			])
		]);

		var activeRows = d.active.map(function(s) {
			return [ s.ip, E('span', { 'style': 'font-family:monospace;font-size:12px' }, s.mac), s.hostname || '-',
				api.fmtDuration(s.uptime), api.fmtDuration(s.idle), '↓ ' + fmtBps(s.rate_down_bps) + ' ↑ ' + fmtBps(s.rate_up_bps),
				'↓ ' + api.fmtBytes(s.down) + ' ↑ ' + api.fmtBytes(s.up),
				s.wifi ? '%s %d dBm'.format(s.wifi.ifname, s.wifi.signal) : _('wired'), s.via,
				E('button', { 'class': 'btn cbi-button cbi-button-remove', 'click': ui.createHandlerFn(self, function(ip) {
					return callKick(ip).then(function() { return self.refresh(); });
				}, s.ip) }, _('Kick')) ];
		});
		var activeTable = E('table', { 'class': 'table' }, [ E('tr', { 'class': 'tr table-titles' }, [ _('IP'), _('MAC'), _('Host'), _('Uptime'), _('Idle'), _('Live rate'), _('Session traffic'), _('Link'), _('Via'), '' ].map(function(h) { return E('th', { 'class': 'th' }, h); })) ]);
		cbi_update_table(activeTable, activeRows, E('em', {}, _('User is offline')));

		var histRows = d.history.map(function(h) {
			return [ api.fmtDate(h.start), api.fmtDuration(h.end - h.start), h.ip, h.hostname || '-', '↓ ' + api.fmtBytes(h.down) + ' ↑ ' + api.fmtBytes(h.up), h.reason, h.proxy == 'direct' ? pill(_('Direct'), '#c2410c') : pill(_('Passwall'), '#047857') ];
		});
		var histTable = E('table', { 'class': 'table' }, [ E('tr', { 'class': 'tr table-titles' }, [ _('Start'), _('Duration'), _('IP'), _('Host'), _('Traffic'), _('Ended by'), _('Route') ].map(function(h) { return E('th', { 'class': 'th' }, h); })) ]);
		cbi_update_table(histTable, histRows, E('em', {}, _('No past sessions yet')));

		var dnsRows = d.dns.map(function(x) { return [ E('span', { 'style': 'font-family:monospace' }, x.domain), String(x.count), x.last ]; });
		var dnsTable = E('table', { 'class': 'table' }, [ E('tr', { 'class': 'tr table-titles' }, [ _('Domain'), _('Queries'), _('Last seen') ].map(function(h) { return E('th', { 'class': 'th' }, h); })) ]);
		cbi_update_table(dnsTable, dnsRows, E('em', {}, _('No DNS activity recorded yet')));

		var connRows = d.connections.top.map(function(c) {
			return [ E('span', {}, [ c.domain ? E('strong', {}, c.domain) : '', c.domain ? E('br') : '', E('span', { 'style': 'font-family:monospace;font-size:12px;color:#64748b' }, c.dst + ':' + c.port + '/' + c.proto) ]),
				String(c.conns), '↓ ' + api.fmtBytes(c.down), '↑ ' + api.fmtBytes(c.up), c.dst.indexOf('198.18.') == 0 ? pill(_('via Passwall'), '#047857') : pill(_('direct'), '#c2410c') ];
		});
		var connTable = E('table', { 'class': 'table' }, [ E('tr', { 'class': 'tr table-titles' }, [ _('Destination'), _('Conns'), _('Down'), _('Up'), _('Path') ].map(function(h) { return E('th', { 'class': 'th' }, h); })) ]);
		cbi_update_table(connTable, connRows, E('em', {}, _('No active connections')));

		var limitsBody = kv([
			[ _('Quota'), lim.quota ? api.fmtBytes(lim.quota) : _('unlimited') ],
			[ _('Speed limit'), (lim.rate_down || lim.rate_up) ? '↓ %s ↑ %s kbps'.format(lim.rate_down || '∞', lim.rate_up || '∞') : _('unlimited') ],
			[ _('Internet route'), lim.proxy == 'direct' ? _('Direct (no proxy)') : _('Passwall / xray') ],
			[ _('Validity'), lim.validity_days ? _('%d days from first login').format(lim.validity_days) : _('unlimited') ],
			[ _('Idle / session timeout'), (lim.idle_timeout ? api.fmtDuration(lim.idle_timeout) : '∞') + ' / ' + (lim.session_timeout ? api.fmtDuration(lim.session_timeout) : '∞') ],
			[ _('Shared devices'), String(lim.shared_users) ],
			[ _('Blocked'), (lim.cat_block || []).concat(lim.block || []).join(', ') || _('none') ],
			[ _('Throttled'), (lim.cat_throttle || []).length ? (lim.cat_throttle.join(', ') + ' @ ' + lim.throttle_rate + ' kbps') : _('none') ],
			[ _('MAC binding'), d.mac_bind || _('any device') ],
			[ _('First / last login'), (st.first_login ? api.fmtDate(st.first_login) : '-') + ' / ' + (st.last_login ? api.fmtDate(st.last_login) : '-') + (st.last_ip ? ' (' + st.last_ip + ')' : '') ]
		]);

		return E('div', {}, [
			head,
			card(_('Live traffic (last 5 minutes)'), E('div', {}, [ sparkline(this.hist.down, this.hist.up), E('div', { 'style': 'font-size:11px;color:#64748b;margin-top:4px' }, _('blue: download · orange: upload')) ])),
			card(_('Active sessions'), activeTable),
			E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:14px' }, [
				E('div', { 'style': 'flex:1 1 420px' }, card(_('Daily usage (14 days)'), bars(d.daily))),
				E('div', { 'style': 'flex:1 1 420px' }, card(_('Limits & profile'), limitsBody))
			]),
			card(_('Live connections (%d)').format(d.connections.total), connTable),
			card(_('Recent DNS activity (sites visited)'), E('div', { 'style': 'max-height:360px;overflow:auto' }, dnsTable)),
			card(_('Session history'), histTable)
		]);
	},

	refresh: function() {
		var self = this, user = this.currentUser();
		if (!user)
			return Promise.resolve();
		return callUserDetail(user).then(function(d) {
			dom.content(document.getElementById('um-detail'), self.renderDetail(d));
		});
	},

	render: function(data) {
		var self = this;
		var sessions = data[1] || [];
		var online = {};
		sessions.forEach(function(s) { online[s.user] = true; });
		var users = uci.sections('usermanager', 'user').map(function(u) { return u.username; }).filter(Boolean).sort(function(a, b) {
			return (online[b] ? 1 : 0) - (online[a] ? 1 : 0) || a.localeCompare(b);
		});
		var current = this.currentUser() || users[0] || '';
		this.selectedUser = current;

		var select = E('select', { 'class': 'cbi-input-select', 'style': 'min-width:260px', 'change': function(ev) {
			self.selectedUser = ev.target.value;
			self.hist = { down: [], up: [] };
			history.replaceState(null, '', window.location.pathname + '?user=' + encodeURIComponent(ev.target.value));
			self.refresh();
		} }, users.map(function(u) {
			return E('option', { 'value': u, 'selected': u == current ? '' : null }, (online[u] ? '● ' : '○ ') + u);
		}));

		poll.add(function() { return self.refresh(); }, 5);

		var node = E('div', { 'class': 'cbi-map' }, [
			E('h2', {}, _('User Monitor')),
			E('div', { 'class': 'cbi-map-descr' }, _('Live view of one account: rate, sessions, daily usage, the sites it resolves and its current connections. ● = online.')),
			E('div', { 'style': 'display:flex;gap:10px;align-items:center;margin:10px 0 16px' }, [ E('label', {}, _('User')), select ]),
			E('div', { 'id': 'um-detail' }, E('em', {}, _('Loading…')))
		]);
		if (current)
			callUserDetail(current).then(function(d) { dom.content(node.querySelector('#um-detail'), self.renderDetail(d)); });
		else
			dom.content(node.querySelector('#um-detail'), E('em', {}, _('No users defined')));
		return node;
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
