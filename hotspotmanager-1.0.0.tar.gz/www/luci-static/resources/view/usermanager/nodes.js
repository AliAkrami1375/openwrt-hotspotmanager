'use strict';
'require view';
'require form';
'require uci';
'require ui';
'require rpc';

var callNodes = rpc.declare({ object: 'luci.usermanager', method: 'nodes', expect: {} });
var callInstall = rpc.declare({ object: 'luci.usermanager', method: 'node_install', params: [ 'sid', 'password' ], expect: {} });
var callAction = rpc.declare({ object: 'luci.usermanager', method: 'node_action', params: [ 'sid', 'action', 'password' ], expect: {} });

function pill(t, c) { return E('span', { 'style': 'display:inline-block;padding:2px 8px;border-radius:10px;color:#fff;font-size:11px;background:' + c }, t); }

function showOutput(title, r) {
	var body = (r && (r.output || r.error)) || '';
	var res = r && r.result ? JSON.stringify(r.result, null, 2) : '';
	ui.showModal(title, [
		E('pre', { 'style': 'white-space:pre-wrap;max-height:50vh;overflow:auto;font-size:12px' }, (res ? res + '\n\n' : '') + body),
		E('div', { 'class': 'right' }, [ E('button', { 'class': 'btn cbi-button', 'click': ui.hideModal }, _('Close')) ])
	]);
}

return view.extend({
	load: function() {
		return Promise.all([ uci.load('usermanager'), callNodes() ]);
	},

	render: function(data) {
		var rep = data[1] || {}, report = rep.nodes || {};
		var m, s, o;

		m = new form.Map('usermanager', _('Proxy Nodes'),
			_('A node is a lightweight proxy server (Xray-core, VLESS + REALITY, about 20 MB of RAM, no extra ports besides the one you choose) that the router installs on any Linux server for you. The SSH details are used only to install and manage it: the first action uses the password once, installs the router\'s key, and every later action (status, restart, update, uninstall) uses that key. The data path is the REALITY protocol, not SSH. After installation add the node as an <b>upstream proxy</b> in the Proxies tab and assign it to users, profiles or a proxy server.'));

		s = m.section(form.GridSection, 'node', _('Nodes'));
		s.anonymous = true;
		s.addremove = true;
		s.nodescriptions = true;
		s.sortable = false;
		s.modaltitle = function(sid) { return _('Node') + ' » ' + (uci.get('usermanager', sid, 'name') || _('new')); };

		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;

		o = s.option(form.Value, 'host', _('Server IP / host'));
		o.rmempty = false;

		o = s.option(form.Value, 'ssh_port', _('SSH port'));
		o.datatype = 'port';
		o.default = '22';
		o.modalonly = true;

		o = s.option(form.Value, 'ssh_user', _('SSH user (root or sudo)'));
		o.default = 'root';
		o.modalonly = true;

		o = s.option(form.Value, 'port', _('Node port'));
		o.datatype = 'port';
		o.default = '8443';
		o.description = _('Port the proxy node listens on (opened in the server firewall).');

		o = s.option(form.Value, 'sni', _('Camouflage site (SNI)'));
		o.default = 'www.microsoft.com';
		o.modalonly = true;
		o.description = _('REALITY makes the node look like this site to anyone probing it. Use a popular site that supports TLS 1.3 and HTTP/2.');

		o = s.option(form.DummyValue, '_state', _('State'));
		o.modalonly = false;
		o.textvalue = function(sid) {
			var r = report[sid];
			if (!r) return E('em', {}, _('not saved'));
			return E('span', { 'style': 'font-size:12px' }, [
				r.installed ? pill(_('installed'), '#16a34a') : pill(_('not installed'), '#64748b'),
				r.version ? ' xray ' + r.version : '', r.used_by ? ' · ' + _('used by %d upstream').format(r.used_by) : ''
			]);
		};

		function act(label, style, handler) {
			var b = s.option(form.Button, '_' + label.toLowerCase().replace(/\W/g, ''), ' ');
			b.editable = true;
			b.modalonly = false;
			b.inputtitle = label;
			b.inputstyle = style;
			b.onclick = handler;
			return b;
		}

		act(_('Install'), 'apply', function(ev, sid) {
			if (!report[sid]) return alert(_('Save & Apply first.'));
			var host = uci.get('usermanager', sid, 'host'), user = uci.get('usermanager', sid, 'ssh_user') || 'root';
			var pw = prompt(_('Password of %s@%s (used once; the router key is installed for later management). Leave empty if the key is already installed:').format(user, host));
			if (pw == null) return;
			ui.showModal(_('Installing node…'), [ E('p', { 'class': 'spinning' }, _('Downloading xray on the server and starting the service. This can take a minute.')) ]);
			return callInstall(sid, pw).then(function(r) {
				ui.hideModal();
				showOutput(r && r.ok ? _('Node installed') : _('Installation failed'), r);
				if (r && r.ok) window.setTimeout(function() { location.reload(); }, 2500);
			});
		});

		act(_('Status'), 'action', function(ev, sid) {
			return callAction(sid, 'status', '').then(function(r) { showOutput(_('Node status'), r); });
		});

		act(_('Restart'), 'reload', function(ev, sid) {
			return callAction(sid, 'restart', '').then(function(r) { showOutput(_('Restart'), r); });
		});

		act(_('Update'), 'action', function(ev, sid) {
			return callAction(sid, 'update', '').then(function(r) { showOutput(_('Update'), r); });
		});

		act(_('Uninstall'), 'remove', function(ev, sid) {
			if (!confirm(_('Remove the node software from the server?'))) return;
			return callAction(sid, 'uninstall', '').then(function(r) { showOutput(_('Uninstall'), r); window.setTimeout(function() { location.reload(); }, 2000); });
		});

		return m.render().then(function(node) {
			var links = Object.keys(report).filter(function(k) { return report[k].link; }).map(function(k) {
				return E('div', { 'style': 'margin:6px 0' }, [
					E('strong', {}, uci.get('usermanager', k, 'name') || k), ' — ', E('span', { 'style': 'font-size:12px;color:#64748b' }, _('share link for other xray/v2rayNG clients:')),
					E('pre', { 'style': 'white-space:pre-wrap;word-break:break-all;background:#f8fafc;padding:8px;border-radius:8px;font-size:11px' }, report[k].link)
				]);
			});
			node.appendChild(E('div', { 'class': 'cbi-section' }, [
				E('h3', {}, _('Credentials')),
				links.length ? E('div', {}, links) : E('em', {}, _('No installed node yet')),
				E('p', { 'style': 'font-size:12px;color:#64748b' }, _('Router management key: ')),
				E('pre', { 'style': 'white-space:pre-wrap;word-break:break-all;background:#f8fafc;padding:8px;border-radius:8px;font-size:11px' }, rep.pubkey || '')
			]));
			return node;
		});
	}
});
