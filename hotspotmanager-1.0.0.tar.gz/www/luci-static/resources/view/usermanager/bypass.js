'use strict';
'require view';
'require form';
'require uci';
'require usermanager.api as api';

return view.extend({
	load: function() {
		return Promise.all([ uci.load('usermanager'), api.neighbors() ]);
	},

	render: function(data) {
		var neighbors = data[1] || [];
		var m, s, o;

		m = new form.Map('usermanager', _('Bypass Devices'),
			_('Devices listed here get Internet access without signing in and are not counted (e.g. your own PCs, printers, TVs). Keep the device you manage the router from in this list.'));

		s = m.section(form.GridSection, 'bypass', _('Bypassed MAC addresses'));
		s.anonymous = true;
		s.addremove = true;
		s.nodescriptions = true;
		s.sortable = false;

		o = s.option(form.Value, 'mac', _('MAC address'));
		o.datatype = 'macaddr';
		o.rmempty = false;
		neighbors.forEach(function(n) {
			o.value(n.mac, '%s (%s%s)'.format(n.mac, n.ip || '?', n.hostname ? ', ' + n.hostname : ''));
		});

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';

		o = s.option(form.Value, 'comment', _('Comment'));

		o = s.option(form.DummyValue, '_online', _('Seen now'));
		o.cfgvalue = function(sid) {
			var mac = (uci.get('usermanager', sid, 'mac') || '').toLowerCase();
			var n = neighbors.filter(function(x) { return x.mac == mac; })[0];
			if (!n)
				return _('no');
			return n.ip + (n.wifi ? ' (%s, %d dBm)'.format(n.wifi.ifname, n.wifi.signal) : '');
		};

		return m.render().then(function(node) {
			var rows = neighbors.map(function(n) {
				return [
					E('span', { 'style': 'font-family:monospace' }, n.mac),
					n.ip || '-',
					n.hostname || '-',
					n.wifi ? '%s (%d dBm)'.format(n.wifi.ifname, n.wifi.signal) : _('wired'),
					n.bypass ? _('bypass') : (n.user ? _('logged in as %s').format(n.user) : _('not signed in'))
				];
			});
			var table = E('table', { 'class': 'table' }, [
				E('tr', { 'class': 'tr table-titles' }, [
					E('th', { 'class': 'th' }, _('MAC')),
					E('th', { 'class': 'th' }, _('IP')),
					E('th', { 'class': 'th' }, _('Hostname')),
					E('th', { 'class': 'th' }, _('Link')),
					E('th', { 'class': 'th' }, _('Status'))
				])
			]);
			cbi_update_table(table, rows, E('em', {}, _('No clients seen')));
			node.appendChild(E('div', { 'class': 'cbi-section' }, [
				E('h3', {}, _('Clients currently on the LAN')),
				table
			]));
			return node;
		});
	}
});
