'use strict';
'require view';
'require form';
'require uci';
'require usermanager.api as api';

return view.extend({
	load: function() {
		return Promise.all([ uci.load('usermanager'), uci.load('network'), api.status() ]);
	},

	render: function(data) {
		var status = data[2] || {};
		var m, s, o;

		m = new form.Map('usermanager', _('Hotspot Settings'),
			_('Saving and applying restarts the hotspot service. Active sessions survive a restart. Portal address right now: <a href="%s" target="_blank">%s</a> (alias IP %s).')
				.format(status.portal_url || '#', status.portal_url || '-', status.portal_ip || '-'));

		s = m.section(form.NamedSection, 'settings', 'settings');
		s.addremove = false;

		s.tab('general', _('General'));
		s.tab('portal', _('Portal & branding'));
		s.tab('routing', _('Internet route (Passwall)'));
		s.tab('blocking', _('Site / app filter'));
		s.tab('walled', _('Walled garden'));

		// ---- general
		o = s.taboption('general', form.Flag, 'enabled', _('Enable hotspot'),
			_('When disabled, all firewall rules are removed and every client has unrestricted access.'));
		o.default = '1';
		o.rmempty = false;

		o = s.taboption('general', form.ListValue, 'interface', _('Client network'),
			_('Clients on this network interface must sign in.'));
		uci.sections('network', 'interface').forEach(function(n) {
			if (n['.name'] != 'loopback' && n.proto != 'none' && n.proto != 'wireguard')
				o.value(n['.name'], '%s (%s)'.format(n['.name'], n.device || n.proto || '?'));
		});
		o.default = 'lan';

		o = s.taboption('general', form.ListValue, 'count_mode', _('Quota counting'));
		o.value('both', _('Upload + download'));
		o.value('download', _('Download only'));
		o.default = 'both';

		o = s.taboption('general', form.Flag, 'kick_wifi', _('Deauthenticate WiFi on logout'),
			_('When a session ends (quota, timeout, kick) the device is also dropped from the WiFi so it shows the login page again.'));
		o.default = '1';

		o = s.taboption('general', form.Flag, 'admin_unauth', _('Allow router admin without login'),
			_('Lets unauthenticated clients reach SSH (22) and LuCI (80/443) on the router LAN address. Safer to keep off and use the Bypass list for your own device.'));
		o.default = '0';

		o = s.taboption('general', form.Value, 'save_interval', _('Usage save interval (s)'),
			_('How often running usage counters are written to flash.'));
		o.datatype = 'range(30,86400)';
		o.default = '300';

		// ---- portal
		o = s.taboption('portal', form.Value, 'portal_host', _('Portal hostname'),
			_('Clients are redirected to this name (e.g. <code>dibachain.router</code> or <code>dibachain.ir</code>). It is resolved by the router DNS to the portal alias address, so no IP:port is shown.'));
		o.datatype = 'hostname';
		o.default = 'dibachain.router';
		o.rmempty = false;

		o = s.taboption('portal', form.Value, 'portal_ip', _('Portal alias IP'),
			_('Extra address on the LAN interface used only by the portal and the direct resolver. Leave empty to use the .2 address of the LAN subnet.'));
		o.datatype = 'ip4addr("nomask")';
		o.placeholder = status.portal_ip || '';
		o.optional = true;

		o = s.taboption('portal', form.Value, 'portal_port', _('Portal port'),
			_('Keep 80 so the hostname works without a port.'));
		o.datatype = 'port';
		o.default = '80';

		o = s.taboption('portal', form.Value, 'portal_title', _('Title'));
		o.default = 'Dibachain Router';

		o = s.taboption('portal', form.Value, 'portal_subtitle', _('Subtitle'));
		o.optional = true;
		o.placeholder = 'Secure WiFi Access';

		o = s.taboption('portal', form.ListValue, 'portal_lang', _('Default language'));
		o.value('fa', 'فارسی');
		o.value('en', 'English');
		o.default = 'fa';

		o = s.taboption('portal', form.TextValue, 'portal_welcome', _('Welcome text'));
		o.rows = 3;
		o.optional = true;

		o = s.taboption('portal', form.Value, 'portal_footer', _('Footer text'));
		o.optional = true;

		o = s.taboption('portal', form.Value, 'redirect_url', _('Redirect after login'),
			_('Optional URL shown as "Continue" button after a successful login. Leave empty to return to the originally requested page.'));
		o.optional = true;
		o.placeholder = 'https://dibachain.ir';

		o = s.taboption('portal', form.Flag, 'pw_prompt_first', _('Ask new users to set a password'),
			_('On the first login a user (not a voucher) is offered to replace the password given by the admin with one of their own. They may skip it.'));
		o.default = '1';

		o = s.taboption('portal', form.Flag, 'pw_allow_change', _('Allow users to change their password'),
			_('Shows a "change password" button on the portal status page.'));
		o.default = '1';

		o = s.taboption('portal', form.Value, 'pw_min_len', _('Minimum password length'));
		o.datatype = 'range(4,64)';
		o.default = '6';

		o = s.taboption('portal', form.DummyValue, '_logo', _('Custom logo'));
		o.rawhtml = true;
		o.cfgvalue = function() {
			return _('Upload a square PNG to <code>/www/usermanager-portal/logo.png</code> on the router (e.g. with scp) to replace the built-in logo.');
		};

		// ---- routing
		o = s.taboption('routing', form.DummyValue, '_route_info', _('How it works'));
		o.rawhtml = true;
		o.cfgvalue = function() {
			return _('Each profile or user has an <b>Internet route</b>: <b>Passwall</b> sends traffic through the xray proxy as configured in Passwall2, <b>Direct</b> skips the proxy entirely (plain ISP connection). Direct clients get real DNS answers from the hotspot resolver below instead of Passwall FakeDNS.') +
				'<br>' + (status.passwall ? _('%s detected: bypass rules are active.').format(status.passwall) : _('No Passwall/Passwall2 detected: "Passwall" routes behave like the default route and these options only matter once a proxy framework is installed.'));
		};

		o = s.taboption('routing', form.DynamicList, 'direct_domains', _('Sites that never use the VPN'),
			_('Domains or TLDs whose traffic goes directly to the Internet for every hotspot client, even when the route is Passwall. Enter <code>ir</code> for all <code>.ir</code> sites, or names like <code>digikala.com</code>, <code>aparat.com</code> (subdomains included). IPv4/CIDR entries are allowed too. These names are resolved with real DNS (no FakeDNS).'));
		o.optional = true;
		o.placeholder = 'ir';

		o = s.taboption('routing', form.DynamicList, 'direct_dns', _('DNS servers for direct traffic'),
			_('Upstream resolvers used for clients whose route is "Direct" and for the sites listed above.'));
		o.datatype = 'ip4addr("nomask")';
		o.placeholder = '8.8.8.8';

		// ---- filter
		o = s.taboption('blocking', form.DynamicList, 'block_global', _('Blocked for everyone'),
			_('Domains (subdomains included) or IPv4/CIDR that no hotspot user may reach, e.g. <code>instagram.com</code>, <code>tiktok.com</code>. Type the name and press Enter (or the + button) to add it, then Save &amp; Apply. Per-profile and per-user lists are set in the Profiles / Users tabs. Devices in the Bypass list are never filtered.'));
		o.optional = true;
		o.placeholder = 'example.com';

		o = s.taboption('blocking', form.Flag, 'bypass_filter', _('Filter bypass devices too'),
			_('Apply the global block list (and the DNS enforcement below) to devices in the Bypass list as well. They still skip login and quotas. Turn off to leave bypass devices completely unfiltered.'));
		o.default = '1';

		o = s.taboption('blocking', form.Flag, 'block_page_https', _('Block page for HTTPS sites too'),
			_('Answer HTTPS requests to blocked sites with the router certificate so the "access restricted" page can be shown after the browser\'s certificate warning. Sites with HSTS (Google, Facebook, Instagram…) cannot be bypassed by the browser and show the certificate error instead. Off = connection is simply reset.'));
		o.default = '1';

		o = s.taboption('blocking', form.Flag, 'block_doh', _('Force router DNS'),
			_('Blocks DNS-over-TLS (port 853) and DNS-over-HTTPS to well-known public resolvers for hotspot users, so browsers and phones cannot bypass the site filter with "Secure DNS" / "Private DNS".'));
		o.default = '1';

		o = s.taboption('blocking', form.DummyValue, '_filter_tip', _('Common app domains'));
		o.rawhtml = true;
		o.cfgvalue = function() {
			return '<code>instagram.com cdninstagram.com</code> · <code>tiktok.com tiktokcdn.com</code> · <code>youtube.com googlevideo.com</code> · ' +
				'<code>telegram.org t.me</code> · <code>facebook.com fbcdn.net</code> · <code>twitter.com x.com twimg.com</code> · <code>netflix.com nflxvideo.net</code>';
		};

		// ---- walled garden
		o = s.taboption('walled', form.DynamicList, 'walled_garden', _('Allowed before login'),
			_('Domains or IPv4 addresses/CIDRs reachable without signing in (e.g. a payment page or your website).'));
		o.optional = true;
		o.placeholder = 'dibachain.ir';

		return m.render();
	}
});
