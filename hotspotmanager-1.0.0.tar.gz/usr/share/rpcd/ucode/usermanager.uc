// rpcd plugin: ubus object "luci.usermanager"
'use strict';

import { popen } from 'fs';
import * as um from 'usermanager.engine';

function shellquote(s) {
	return "'" + replace('' + (s ?? ''), "'", "'\\''") + "'";
}

function safe(fn) {
	try {
		return fn();
	} catch (e) {
		return { error: '' + e };
	}
}

const methods = {
	status: {
		call: function() {
			return safe(() => um.status());
		}
	},

	sessions: {
		call: function() {
			return safe(() => ({ sessions: um.sessions_report() }));
		}
	},

	users: {
		call: function() {
			return safe(() => ({ users: um.users_report() }));
		}
	},

	neighbors: {
		call: function() {
			return safe(() => ({ neighbors: um.neighbors() }));
		}
	},

	kick: {
		args: { ip: 'ip' },
		call: function(req) {
			return safe(() => ({ ok: um.logout(req.args.ip, 'kick') }));
		}
	},

	kick_user: {
		args: { username: 'username' },
		call: function(req) {
			return safe(() => ({ closed: um.kick_user(req.args.username, 'kick') }));
		}
	},

	reset_usage: {
		args: { username: 'username' },
		call: function(req) {
			return safe(() => ({ ok: um.reset_usage(req.args.username) }));
		}
	},

	forget_user: {
		args: { username: 'username' },
		call: function(req) {
			return safe(() => ({ ok: um.forget_user(req.args.username) }));
		}
	},

	generate_vouchers: {
		args: { count: 0, length: 0, prefix: 'prefix', profile: 'profile', comment: 'comment', charset: 'charset' },
		call: function(req) {
			return safe(() => um.generate_vouchers(req.args.count, req.args.length, req.args.prefix,
				req.args.profile, req.args.comment, req.args.charset));
		}
	},

	login: {
		args: { ip: 'ip', username: 'username', password: 'password' },
		call: function(req) {
			return safe(() => um.login(req.args.ip, req.args.username, req.args.password));
		}
	},

	proxies: {
		call: function() {
			return safe(() => um.proxies_report());
		}
	},

	nodes: {
		call: function() {
			return safe(() => um.nodes_report());
		}
	},

	node_install: {
		args: { sid: 'sid', password: 'password' },
		call: function(req) {
			return safe(() => um.node_install(req.args.sid, req.args.password));
		}
	},

	node_action: {
		args: { sid: 'sid', action: 'action', password: 'password' },
		call: function(req) {
			return safe(() => um.node_action(req.args.sid, req.args.action, req.args.password));
		}
	},

	set_password: {
		args: { username: 'username', password: 'password' },
		call: function(req) {
			return safe(() => um.set_user_password(req.args.username, req.args.password, false));
		}
	},

	interfaces: {
		call: function() {
			return safe(() => ({ interfaces: um.interfaces(um.load_config()) }));
		}
	},

	routes: {
		call: function() {
			return safe(() => ({ routes: um.routes_report() }));
		}
	},

	tunnels: {
		call: function() {
			return safe(() => um.tunnels_report());
		}
	},

	tunnel_setup: {
		args: { sid: 'sid', password: 'password' },
		call: function(req) {
			return safe(() => um.tunnel_setup(req.args.sid, req.args.password));
		}
	},

	user_detail: {
		args: { username: 'username' },
		call: function(req) {
			return safe(() => um.user_detail(req.args.username));
		}
	},

	categories: {
		call: function() {
			return safe(() => {
				let out = {};
				for (let k, v in um.CATEGORIES)
					out[k] = { title: v.title, count: length(v.domains), domains: v.domains };
				return { categories: out };
			});
		}
	},

	forwards: {
		call: function() {
			return safe(() => ({ forwards: um.forwards_report() }));
		}
	},

	set_contents: {
		args: { name: 'name' },
		call: function(req) {
			return safe(() => ({ elements: um.set_contents(req.args.name) }));
		}
	},

	log: {
		args: { lines: 0 },
		call: function(req) {
			let n = req.args.lines ?? 200;
			if (n < 1 || n > 5000)
				n = 200;
			let p = popen('logread -e usermanager 2>/dev/null | tail -n ' + n);
			let out = p ? p.read('all') : '';
			if (p) p.close();
			return { log: out };
		}
	},

	service: {
		args: { action: 'action' },
		call: function(req) {
			let act = req.args.action;
			if (act != 'start' && act != 'stop' && act != 'restart' && act != 'reload')
				return { error: 'bad action' };
			let p = popen('/etc/init.d/usermanager ' + act + ' 2>&1');
			let out = p ? p.read('all') : '';
			if (p) p.close();
			return { ok: true, output: out };
		}
	}
};

return { 'luci.usermanager': methods };
