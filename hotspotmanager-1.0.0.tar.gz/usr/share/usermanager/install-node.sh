#!/usr/bin/env bash
# ------------------------------------------------------------------------------
#  Dibachain OpenWrt User Manager - remote node installer / manager
#
#  Installs a lightweight proxy node (Xray-core, VLESS + REALITY, ~20 MB RAM) on a
#  Linux server and manages it. Runs on the server; the router streams this file
#  over SSH (bootstrap with a password, afterwards with the router's key) and
#  parses the last "NODE_RESULT {json}" line.
#
#  Actions (exactly one):
#    --install     install/upgrade xray, create config + service, print credentials
#    --status      print service status / version / memory as JSON
#    --restart     restart the service
#    --update      download the latest xray binary and restart
#    --logs        print the last 40 log lines
#    --uninstall   stop + remove service, binary, config and the dedicated user
#  Options:
#    --port <n>     inbound port (default 8443)
#    --sni <host>   REALITY camouflage site (default www.microsoft.com)
#    --key "<pub>"  router SSH public key to install for key-based management
#    --regen        regenerate uuid/keys on --install
#  Supported: Debian/Ubuntu, RHEL/Rocky/Alma/CentOS, Fedora, Arch, Alpine (OpenRC), openSUSE
# ------------------------------------------------------------------------------
set -uo pipefail

ACTION=""; PORT=8443; SNI="www.microsoft.com"; KEY=""; REGEN=0
NAME="usermanager-node"
BIN="/usr/local/bin/xray"
CONF_DIR="/usr/local/etc/$NAME"
CONF="$CONF_DIR/config.json"
CREDS="$CONF_DIR/credentials.env"
LOG="/var/log/$NAME.log"
SVC_USER="umnode"

while [ $# -gt 0 ]; do
	case "$1" in
		--install|--status|--restart|--update|--logs|--uninstall) ACTION="${1#--}";;
		--port) shift; PORT="${1:-8443}";;
		--sni) shift; SNI="${1:-www.microsoft.com}";;
		--key) shift; KEY="${1:-}";;
		--regen) REGEN=1;;
		*) ;;
	esac
	shift
done

result() { printf 'NODE_RESULT %s\n' "$1"; }
fail()   { echo "ERROR: $*" >&2; result "{\"ok\":false,\"error\":\"$(echo "$*" | sed 's/"/\\"/g')\"}"; exit 1; }
j()      { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }

[ "$(id -u)" = 0 ] || fail "run as root"
[ -n "$ACTION" ] || fail "no action given"

# ---- helpers -----------------------------------------------------------------
has() { command -v "$1" >/dev/null 2>&1; }
pkg_install() {
	if has apt-get; then DEBIAN_FRONTEND=noninteractive apt-get install -y -qq "$@" >/dev/null 2>&1 || { apt-get update -qq >/dev/null 2>&1; DEBIAN_FRONTEND=noninteractive apt-get install -y -qq "$@" >/dev/null 2>&1; }
	elif has dnf; then dnf install -y -q "$@" >/dev/null 2>&1
	elif has yum; then yum install -y -q "$@" >/dev/null 2>&1
	elif has apk; then apk add --no-cache -q "$@" >/dev/null 2>&1
	elif has pacman; then pacman -Sy --noconfirm --needed "$@" >/dev/null 2>&1
	elif has zypper; then zypper -n install "$@" >/dev/null 2>&1
	fi
}
init_sys() { if has systemctl && [ -d /run/systemd/system ]; then echo systemd; elif has rc-service; then echo openrc; else echo none; fi; }
svc() {   # svc start|stop|restart|enable|status
	case "$(init_sys)" in
		systemd) systemctl "$1" "$NAME" 2>/dev/null;;
		openrc)  case "$1" in enable) rc-update add "$NAME" default >/dev/null 2>&1;; status) rc-service "$NAME" status 2>/dev/null;; *) rc-service "$NAME" "$1" >/dev/null 2>&1;; esac;;
		*) return 1;;
	esac
}
arch_tag() {
	case "$(uname -m)" in
		x86_64|amd64) echo 64;; aarch64|arm64) echo arm64-v8a;; armv7l|armv7) echo arm32-v7a;; armv6l) echo arm32-v6;;
		i386|i686) echo 32;; riscv64) echo riscv64;; *) fail "unsupported architecture $(uname -m)";;
	esac
}
download_xray() {
	has curl || has wget || pkg_install curl
	has unzip || pkg_install unzip
	local tag url tmp
	tag="$(arch_tag)"
	url="https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-${tag}.zip"
	tmp="$(mktemp -d)"
	if has curl; then curl -fsSL --retry 3 -o "$tmp/x.zip" "$url" || fail "download failed ($url)"
	else wget -q -O "$tmp/x.zip" "$url" || fail "download failed ($url)"; fi
	unzip -qo "$tmp/x.zip" -d "$tmp" || fail "unzip failed"
	install -m 755 "$tmp/xray" "$BIN"
	mkdir -p /usr/local/share/xray
	[ -f "$tmp/geoip.dat" ] && install -m 644 "$tmp/geoip.dat" /usr/local/share/xray/
	[ -f "$tmp/geosite.dat" ] && install -m 644 "$tmp/geosite.dat" /usr/local/share/xray/
	rm -rf "$tmp"
}
xray_version() { "$BIN" version 2>/dev/null | head -1 | awk '{print $2}'; }
install_key() {
	[ -n "$KEY" ] || return 0
	mkdir -p /root/.ssh && chmod 700 /root/.ssh
	touch /root/.ssh/authorized_keys && chmod 600 /root/.ssh/authorized_keys
	grep -qF "$(echo "$KEY" | awk '{print $2}')" /root/.ssh/authorized_keys || echo "$KEY" >> /root/.ssh/authorized_keys
}
open_port() {
	local p="$1"
	if has ufw && ufw status 2>/dev/null | grep -q "Status: active"; then ufw allow "$p/tcp" >/dev/null 2>&1
	elif has firewall-cmd && firewall-cmd --state >/dev/null 2>&1; then firewall-cmd --permanent --add-port="$p/tcp" >/dev/null 2>&1; firewall-cmd --reload >/dev/null 2>&1
	elif has iptables; then iptables -C INPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null || iptables -I INPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null
	fi
}
write_service() {
	case "$(init_sys)" in
		systemd)
			cat > "/etc/systemd/system/$NAME.service" <<EOF
[Unit]
Description=Dibachain User Manager proxy node (xray)
After=network-online.target
Wants=network-online.target

[Service]
User=$SVC_USER
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
ReadWritePaths=/var/log
ExecStart=$BIN run -c $CONF
Restart=always
RestartSec=3
LimitNOFILE=65536
MemoryMax=256M

[Install]
WantedBy=multi-user.target
EOF
			systemctl daemon-reload;;
		openrc)
			cat > "/etc/init.d/$NAME" <<EOF
#!/sbin/openrc-run
description="Dibachain User Manager proxy node (xray)"
command="$BIN"
command_args="run -c $CONF"
command_user="$SVC_USER"
command_background=true
pidfile="/run/$NAME.pid"
depend() { need net; }
EOF
			chmod +x "/etc/init.d/$NAME";;
		*) fail "no supported init system (systemd/OpenRC)";;
	esac
}

# ---- actions -----------------------------------------------------------------
case "$ACTION" in
install)
	install_key
	id "$SVC_USER" >/dev/null 2>&1 || { useradd --system --no-create-home --shell /usr/sbin/nologin "$SVC_USER" 2>/dev/null || adduser -S -D -H -s /sbin/nologin "$SVC_USER" 2>/dev/null; }
	[ -x "$BIN" ] || download_xray
	mkdir -p "$CONF_DIR"
	if [ -f "$CREDS" ] && [ "$REGEN" = 0 ]; then
		# shellcheck disable=SC1090
		. "$CREDS"
	else
		UUID="$("$BIN" uuid)"
		KEYS="$("$BIN" x25519)"
		PRIV="$(echo "$KEYS" | awk -F': *' 'tolower($1) ~ /private/ {print $2; exit}')"
		PUB="$(echo "$KEYS" | awk -F': *' 'tolower($1) ~ /public|password/ {print $2; exit}')"
		SHORT="$(head -c 8 /dev/urandom | od -An -tx1 | tr -d ' \n')"
		printf 'UUID=%s\nPRIV=%s\nPUB=%s\nSHORT=%s\n' "$UUID" "$PRIV" "$PUB" "$SHORT" > "$CREDS"
		chmod 600 "$CREDS"
	fi
	cat > "$CONF" <<EOF
{
  "log": { "loglevel": "warning", "error": "$LOG" },
  "inbounds": [{
    "tag": "in", "listen": "0.0.0.0", "port": $PORT, "protocol": "vless",
    "settings": { "clients": [{ "id": "$UUID", "flow": "xtls-rprx-vision" }], "decryption": "none" },
    "streamSettings": {
      "network": "tcp", "security": "reality",
      "realitySettings": { "show": false, "dest": "$SNI:443", "xver": 0, "serverNames": ["$SNI"], "privateKey": "$PRIV", "shortIds": ["$SHORT", ""] }
    },
    "sniffing": { "enabled": true, "destOverride": ["http", "tls", "quic"] }
  }],
  "outbounds": [
    { "tag": "direct", "protocol": "freedom", "settings": { "domainStrategy": "UseIP" } },
    { "tag": "block", "protocol": "blackhole" }
  ],
  "routing": { "rules": [ { "type": "field", "ip": ["geoip:private"], "outboundTag": "block" } ] }
}
EOF
	chown -R "$SVC_USER" "$CONF_DIR"; chmod 640 "$CONF"
	touch "$LOG"; chown "$SVC_USER" "$LOG"
	"$BIN" run -test -c "$CONF" >/dev/null 2>&1 || fail "generated xray config failed validation"
	write_service
	svc enable; svc restart
	open_port "$PORT"
	sleep 1
	ACTIVE=$(svc status >/dev/null 2>&1 && echo true || echo false)
	result "{\"ok\":true,\"uuid\":\"$UUID\",\"public_key\":\"$PUB\",\"short_id\":\"$SHORT\",\"port\":$PORT,\"sni\":\"$(j "$SNI")\",\"version\":\"$(j "$(xray_version)")\",\"active\":$ACTIVE,\"init\":\"$(init_sys)\"}"
	;;
status)
	install_key
	ACTIVE=$(svc status >/dev/null 2>&1 && echo true || echo false)
	PID=$(pgrep -f "$BIN run -c $CONF" | head -1)
	RSS=0; UP=""
	if [ -n "$PID" ]; then RSS=$(awk '/VmRSS/{print $2}' "/proc/$PID/status" 2>/dev/null); UP=$(ps -o etime= -p "$PID" 2>/dev/null | tr -d ' '); fi
	CONNS=$(ss -Htn state established "( sport = :$PORT )" 2>/dev/null | wc -l)
	LOAD=$(cut -d' ' -f1 /proc/loadavg)
	result "{\"ok\":true,\"active\":$ACTIVE,\"version\":\"$(j "$(xray_version)")\",\"rss_kb\":${RSS:-0},\"uptime\":\"$(j "${UP:-}")\",\"connections\":${CONNS:-0},\"load\":\"$LOAD\",\"installed\":$([ -x "$BIN" ] && echo true || echo false)}"
	;;
restart)
	svc restart; sleep 1
	result "{\"ok\":$(svc status >/dev/null 2>&1 && echo true || echo false)}"
	;;
update)
	download_xray; svc restart; sleep 1
	result "{\"ok\":true,\"version\":\"$(j "$(xray_version)")\"}"
	;;
logs)
	tail -n 40 "$LOG" 2>/dev/null
	result "{\"ok\":true}"
	;;
uninstall)
	svc stop; case "$(init_sys)" in systemd) systemctl disable "$NAME" >/dev/null 2>&1; rm -f "/etc/systemd/system/$NAME.service"; systemctl daemon-reload;; openrc) rc-update del "$NAME" default >/dev/null 2>&1; rm -f "/etc/init.d/$NAME";; esac
	rm -rf "$CONF_DIR" "$BIN" "$LOG" /usr/local/share/xray
	userdel "$SVC_USER" >/dev/null 2>&1 || true
	result "{\"ok\":true}"
	;;
esac
