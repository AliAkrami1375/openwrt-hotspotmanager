// usermanager engine - MikroTik-style hotspot user manager for OpenWrt
// Licensed under the Apache License 2.0.
'use strict';

import { readfile, writefile, mkdir, rmdir, stat, access, popen, unlink, open, glob } from 'fs';
import { cursor } from 'uci';
import { connect } from 'ubus';

const TABLE = 'inet usermanager';
const STATE_DIR = '/etc/usermanager';
const STATE_FILE = STATE_DIR + '/state.json';
const RUN_DIR = '/var/run/usermanager';
const SESS_FILE = RUN_DIR + '/sessions.json';
const LOCK_DIR = '/var/lock/usermanager.lck';
const NFT_TMP = RUN_DIR + '/batch.nft';
const NFTSET_CONF = RUN_DIR + '/nftset.conf';
const DIRECT_DNS_CONF = RUN_DIR + '/dnsmasq-direct.conf';
const PROXY_DNS_CONF = RUN_DIR + '/dnsmasq-proxy.conf';
const DIRECT_DNS_PORT = 5353;   // resolver for "direct" users: real upstream DNS
const PROXY_DNS_PORT = 5354;    // resolver for everyone else: forwards to the main dnsmasq (passwall), adds nftsets
const CONFIG_FILE = '/etc/config/usermanager';
const DNSLOG_PROXY = RUN_DIR + '/dns-proxy.log';
const DNSLOG_DIRECT = RUN_DIR + '/dns-direct.log';
const DNSLOG_MAX = 1536 * 1024;     // rotate the query logs above this size (tmpfs)
const DNSLOG_KEEP = 384 * 1024;
const HISTORY_MAX = 40;             // sessions kept per user
const DAILY_KEEP = 62;              // days of per-user daily usage kept
const ROUTE_MARK_BASE = 0x7a00;     // fwmarks 0x7a01.. for policy routes / interface tables
const ROUTE_TABLE_BASE = 7000;
const MARK_OUR_DEFAULT = 0x7aff;    // router-originated proxy traffic that must skip passwall but use the main table
const XRAY_BIN = '/usr/bin/xray';
const XRAY_CONF = RUN_DIR + '/xray.json';
const XRAY_LOG = RUN_DIR + '/xray.log';
const TUNNEL_KEY = STATE_DIR + '/tunnel_key';
const TUNNELS_FILE = RUN_DIR + '/tunnels.txt';

// public DNS-over-HTTPS/TLS resolvers that browsers and phones use to bypass the router DNS
const DOH_RESOLVERS = [
	'8.8.8.8', '8.8.4.4', '1.1.1.1', '1.0.0.1', '9.9.9.9', '149.112.112.112',
	'94.140.14.14', '94.140.15.15', '208.67.222.222', '208.67.220.220',
	'185.228.168.9', '185.228.169.9', '76.76.2.0', '76.76.10.0', '45.90.28.0/24', '45.90.30.0/24'
];
const DOH_RESOLVERS6 = [
	'2001:4860:4860::8888', '2001:4860:4860::8844', '2606:4700:4700::1111', '2606:4700:4700::1001',
	'2620:fe::fe', '2620:fe::9', '2a10:50c0::ad1:ff', '2a10:50c0::ad2:ff', '2a07:a8c0::/32', '2a07:a8c1::/32'
];

// Built-in content categories (domain lists, subdomains included). Used for per-profile /
// per-user blocking and throttling. HTTPS payload (images, video bytes) cannot be inspected
// without breaking TLS, so categories are the practical way to control this kind of content.
const CATEGORIES = {
	video: {
		title: 'Video & streaming',
		domains: [ 'youtube.com', 'youtu.be', 'googlevideo.com', 'ytimg.com', 'youtube-nocookie.com',
			'aparat.com', 'aparatcdn.com', 'filimo.com', 'namava.ir', 'telewebion.com', 'namasha.com',
			'netflix.com', 'nflxvideo.net', 'nflximg.net', 'twitch.tv', 'ttvnw.net', 'vimeo.com', 'vimeocdn.com',
			'dailymotion.com', 'dmcdn.net', 'tiktok.com', 'tiktokcdn.com', 'tiktokv.com', 'disneyplus.com',
			'primevideo.com', 'hulu.com', 'rumble.com', 'bilibili.com' ]
	},
	social: {
		title: 'Social networks',
		domains: [ 'instagram.com', 'cdninstagram.com', 'facebook.com', 'fbcdn.net', 'fb.com',
			'twitter.com', 'x.com', 'twimg.com', 't.co', 'tiktok.com', 'tiktokcdn.com', 'snapchat.com', 'sc-cdn.net',
			'pinterest.com', 'pinimg.com', 'reddit.com', 'redd.it', 'redditmedia.com', 'linkedin.com', 'licdn.com',
			'threads.net', 'tumblr.com', 'vk.com' ]
	},
	messaging: {
		title: 'Messaging & calls',
		domains: [ 'telegram.org', 'telegram.me', 't.me', 'tdesktop.com', 'whatsapp.com', 'whatsapp.net',
			'discord.com', 'discordapp.com', 'discord.gg', 'signal.org', 'viber.com', 'imo.im', 'skype.com',
			'zoom.us', 'meet.google.com', 'eitaa.com', 'rubika.ir', 'splus.ir', 'bale.ai', 'igap.net' ]
	},
	games: {
		title: 'Online games',
		domains: [ 'steampowered.com', 'steamcontent.com', 'steamstatic.com', 'epicgames.com', 'unrealengine.com',
			'riotgames.com', 'leagueoflegends.com', 'playstation.net', 'playstation.com', 'xboxlive.com',
			'pubgmobile.com', 'igamecj.com', 'supercell.com', 'supercellgames.com', 'roblox.com', 'rbxcdn.com',
			'ea.com', 'battle.net', 'blizzard.com', 'garena.com', 'activision.com', 'minecraft.net', 'mojang.com' ]
	},
	downloads: {
		title: 'Large downloads & updates',
		domains: [ 'windowsupdate.com', 'update.microsoft.com', 'download.microsoft.com', 'delivery.mp.microsoft.com',
			'download.windowsupdate.com', 'dl.google.com', 'android.clients.google.com', 'swcdn.apple.com',
			'updates.cdn-apple.com', 'mesu.apple.com', 'gdmf.apple.com', 'nvidia.com', 'download.nvidia.com',
			'softonic.com', 'soft98.ir', 'p30download.ir', 'downloadly.ir', 'sourceforge.net', 'mediafire.com',
			'mega.nz', 'mega.io', '4shared.com', 'uptodown.com', 'apkpure.com', 'apkmirror.com', 'bittorrent.com' ]
	},
	adult: {
		title: 'Adult content',
		domains: [ 'pornhub.com', 'phncdn.com', 'xvideos.com', 'xvideos-cdn.com', 'xnxx.com', 'xnxx-cdn.com',
			'redtube.com', 'youporn.com', 'xhamster.com', 'xhcdn.com', 'onlyfans.com', 'spankbang.com',
			'chaturbate.com', 'livejasmin.com', 'stripchat.com', 'brazzers.com' ]
	},
	ads: {
		title: 'Ads & trackers',
		domains: [ 'doubleclick.net', 'googlesyndication.com', 'googleadservices.com', 'adservice.google.com',
			'adnxs.com', 'adsrvr.org', 'criteo.com', 'taboola.com', 'outbrain.com', 'yektanet.com',
			'tapsell.ir', 'mediaad.org', 'adtrace.io', 'scorecardresearch.com', 'moatads.com', 'pubmatic.com' ]
	}
};

function category_domains(names) {
	let out = [];
	for (let n in (names ?? []))
		for (let d in (CATEGORIES[n]?.domains ?? []))
			push(out, d);
	return out;
}

// Every hotspot client must use the hotspot resolvers (IPv4, DNAT-ed): IPv6 DNS would reach
// the system dnsmasq directly and return FakeDNS answers, DoT/DoH would bypass filtering.
function dns_enforce_rules(block_doh) {
	let out = '';
	out += `		meta nfproto ipv6 meta l4proto { tcp, udp } th dport 53 reject comment "ipv6 dns: fall back to ipv4"\n`;
	if (block_doh) {
		out += `		tcp dport 853 goto blocked comment "dns-over-tls"\n`;
		out += `		ip daddr { ${join(', ', DOH_RESOLVERS)} } meta l4proto { tcp, udp } th dport 443 goto blocked comment "dns-over-https"\n`;
		out += `		ip6 daddr { ${join(', ', DOH_RESOLVERS6)} } meta l4proto { tcp, udp } th dport 443 goto blocked comment "dns-over-https v6"\n`;
	}
	return out;
}
const PORTAL_LISTEN = 2050;    // internal port of the portal web server (public port is DNAT-ed to it)
const PORTAL_LISTEN_TLS = 2443; // HTTPS listener (router certificate) used for the block page of HTTPS sites

let ubus_conn = null;

function ubus() {
	if (!ubus_conn)
		ubus_conn = connect();
	return ubus_conn;
}

function shellquote(s) {
	return "'" + replace('' + (s ?? ''), "'", "'\\''") + "'";
}

function log(msg) {
	system('logger -t usermanager -p daemon.notice ' + shellquote(msg));
}

function run(cmd) {
	let p = popen(cmd + ' 2>&1', 'r');
	if (!p)
		return null;
	let out = p.read('all');
	p.close();
	return out;
}

function now() {
	return time();
}

function today() {
	let t = localtime();
	return sprintf('%04d-%02d-%02d', t.year, t.mon, t.mday);
}

function ensure_dirs() {
	if (!access(RUN_DIR))
		mkdir(RUN_DIR, 0o755);
	if (!access(STATE_DIR))
		mkdir(STATE_DIR, 0o700);
}

// nft identifiers: letters, digits, underscore
function ident(s) {
	return replace('' + s, /[^A-Za-z0-9_]/g, '_');
}

function uniq(arr) {
	let seen = {}, out = [];
	for (let x in arr) {
		x = trim('' + (x ?? ''));
		if (!length(x) || seen[x])
			continue;
		seen[x] = true;
		push(out, x);
	}
	return out;
}

function is_ipv4(s) {
	return !!match(s, /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+(\/[0-9]+)?$/);
}

// ---------------------------------------------------------------- locking

function with_lock(fn) {
	ensure_dirs();
	let tries = 0;
	while (!mkdir(LOCK_DIR, 0o700)) {
		let st = stat(LOCK_DIR);
		if (st && (now() - st.mtime) > 20) {
			rmdir(LOCK_DIR);
			continue;
		}
		if (++tries > 100)
			die('usermanager: could not acquire lock');
		sleep(50);
	}
	let res, err;
	try {
		res = fn();
	} catch (e) {
		err = e;
	}
	rmdir(LOCK_DIR);
	if (err)
		die(err);
	return res;
}

// ---------------------------------------------------------------- config

function to_int(v, dflt) {
	if (v == null || v === '')
		return dflt ?? 0;
	let n = int(v);
	return (type(n) == 'int') ? n : (dflt ?? 0);
}

function to_list(v) {
	if (v == null)
		return [];
	if (type(v) == 'string')
		return uniq(split(v, /[\s,]+/));
	return uniq(v);
}

function load_config() {
	let c = cursor();
	let cfg = {
		settings: {},
		profiles: {},
		users: {},
		bypass: []
	};

	let s = c.get_all('usermanager', 'settings') ?? {};
	cfg.settings = {
		enabled: to_int(s.enabled, 1) == 1,
		interface: s.interface ?? 'lan',
		portal_host: lc(trim(s.portal_host ?? '')) || 'hotspot.router',
		portal_ip: trim(s.portal_ip ?? ''),
		portal_port: to_int(s.portal_port, 80),
		count_mode: s.count_mode ?? 'both',
		admin_unauth: to_int(s.admin_unauth, 0) == 1,
		kick_wifi: to_int(s.kick_wifi, 1) == 1,
		save_interval: to_int(s.save_interval, 300),
		portal_title: s.portal_title ?? 'Hotspot',
		portal_subtitle: s.portal_subtitle ?? '',
		portal_lang: s.portal_lang ?? 'fa',
		portal_welcome: s.portal_welcome ?? '',
		portal_footer: s.portal_footer ?? '',
		redirect_url: s.redirect_url ?? '',
		walled_garden: to_list(s.walled_garden),
		block_global: to_list(s.block_global),
		block_doh: to_int(s.block_doh, 1) == 1,
		block_page_https: to_int(s.block_page_https, 1) == 1,
		bypass_filter: to_int(s.bypass_filter, 1) == 1,
		direct_dns: to_list(s.direct_dns),
		direct_domains: map(to_list(s.direct_domains), d => lc(trim(d, '. '))),
		pw_prompt_first: to_int(s.pw_prompt_first, 1) == 1,
		pw_allow_change: to_int(s.pw_allow_change, 1) == 1,
		pw_min_len: to_int(s.pw_min_len, 6)
	};
	if (!length(cfg.settings.direct_dns))
		cfg.settings.direct_dns = [ '8.8.8.8', '1.1.1.1' ];

	c.foreach('usermanager', 'profile', function(p) {
		cfg.profiles[p['.name']] = {
			id: p['.name'],
			quota_mb: to_int(p.quota_mb, 0),
			rate_down: to_int(p.rate_down, 0),
			rate_up: to_int(p.rate_up, 0),
			validity_days: to_int(p.validity_days, 0),
			session_timeout: to_int(p.session_timeout, 0),
			idle_timeout: to_int(p.idle_timeout, 0),
			time_limit_min: to_int(p.time_limit_min, 0),
			shared_users: to_int(p.shared_users, 1),
			mac_cookie_hours: to_int(p.mac_cookie_hours, 0),
			proxy: (p.proxy == 'direct' || index(p.proxy ?? '', 'pc:') == 0) ? p.proxy : 'passwall',
			block: uniq([ ...to_list(p.block), ...category_domains(to_list(p.cat_block)) ]),
			cat_block: to_list(p.cat_block),
			cat_throttle: to_list(p.cat_throttle),
			throttle_rate: to_int(p.throttle_rate, 0),
			conn_max_mb: to_int(p.conn_max_mb, 0)
		};
	});

	c.foreach('usermanager', 'user', function(u) {
		if (!u.username)
			return;
		cfg.users[u.username] = {
			sid: u['.name'],
			username: u.username,
			password: u.password ?? '',
			profile: u.profile ?? 'default',
			enabled: to_int(u.enabled, 1) == 1,
			mac: lc(u.mac ?? ''),
			comment: u.comment ?? '',
			voucher: to_int(u.voucher, 0) == 1,
			quota_mb: (u.quota_mb != null && u.quota_mb !== '') ? to_int(u.quota_mb, 0) : null,
			rate_down: (u.rate_down != null && u.rate_down !== '') ? to_int(u.rate_down, 0) : null,
			rate_up: (u.rate_up != null && u.rate_up !== '') ? to_int(u.rate_up, 0) : null,
			valid_until: u.valid_until ?? '',
			proxy: (u.proxy == 'direct' || u.proxy == 'passwall' || index(u.proxy ?? '', 'pc:') == 0) ? u.proxy : null,
			pw_changed: u.pw_changed ?? '',
			block: uniq([ ...to_list(u.block), ...category_domains(to_list(u.cat_block)) ]),
			cat_block: to_list(u.cat_block),
			cat_throttle: to_list(u.cat_throttle),
			throttle_rate: (u.throttle_rate != null && u.throttle_rate !== '') ? to_int(u.throttle_rate, 0) : null,
			conn_max_mb: (u.conn_max_mb != null && u.conn_max_mb !== '') ? to_int(u.conn_max_mb, 0) : null
		};
	});

	c.foreach('usermanager', 'bypass', function(b) {
		if (b.mac && to_int(b.enabled, 1) == 1)
			push(cfg.bypass, lc(b.mac));
	});

	// policy routing: send selected clients / destinations out through a chosen interface
	cfg.routes = [];
	c.foreach('usermanager', 'route', function(r) {
		if (to_int(r.enabled, 1) != 1 || !length(r.iface ?? ''))
			return;
		let src = [], users = [];
		for (let s in to_list(r.src)) {
			if (substr(s, 0, 1) == '@')
				push(users, substr(s, 1));
			else if (is_ipv4(s))
				push(src, s);
		}
		let dst = map(to_list(r.dst), d => lc(trim(d, '. ')));
		if (!length(src) && !length(users) && !length(dst))
			return;
		push(cfg.routes, {
			sid: r['.name'],
			name: r.name ?? r['.name'],
			iface: r.iface,
			src: src,
			users: users,
			dst: dst,
			set_src: 'rs_' + ident(r['.name']),
			set_dst: 'rd_' + ident(r['.name']),
			mark: 0x7a00 + length(cfg.routes) + 1,
			table: 7000 + length(cfg.routes) + 1
		});
	});

	// per-site daily quotas (data and/or time per user)
	cfg.sitequotas = [];
	c.foreach('usermanager', 'sitequota', function(q) {
		if (to_int(q.enabled, 1) != 1)
			return;
		let domains = uniq([ ...map(to_list(q.domains), d => lc(trim(d, '. '))), ...category_domains(to_list(q.categories)) ]);
		if (!length(domains))
			return;
		push(cfg.sitequotas, {
			sid: q['.name'],
			name: q.name ?? q['.name'],
			domains: domains,
			daily_bytes: to_int(q.daily_mb, 0) * 1024 * 1024,
			daily_secs: to_int(q.daily_min, 0) * 60,
			profiles: to_list(q.profiles),
			set: 'q_' + ident(q['.name']),
			set_up: 'qu_' + ident(q['.name']),
			set_down: 'qd_' + ident(q['.name']),
			set_block: 'qb_' + ident(q['.name'])
		});
	});

	// upstream proxies (xray outbounds, optionally bound to an interface) and proxy servers on the router
	cfg.proxyclients = [];
	c.foreach('usermanager', 'proxyclient', function(p) {
		if (to_int(p.enabled, 1) != 1)
			return;
		let type = p.type ?? 'socks';
		if (index([ 'node', 'socks', 'http', 'ss', 'vless', 'vmess', 'trojan', 'json' ], type) < 0)
			return;
		if (type != 'json' && type != 'node' && !length(p.host ?? ''))
			return;
		push(cfg.proxyclients, {
			sid: p['.name'],
			id: ident(p['.name']),
			name: p.name ?? p['.name'],
			type: type,
			host: trim(p.host ?? ''),
			port: to_int(p.port, type == 'ssh' ? 22 : 1080),
			username: p.username ?? '',
			password: p.password ?? '',
			method: p.method ?? 'aes-256-gcm',
			uuid: p.uuid ?? '',
			security: p.security ?? 'none',
			sni: p.sni ?? '',
			network: p.network ?? 'tcp',
			path: p.path ?? '',
			host_header: p.host_header ?? '',
			flow: p.flow ?? '',
			public_key: p.public_key ?? '',
			short_id: p.short_id ?? '',
			insecure: to_int(p.insecure, 0) == 1,
			json: p.json ?? '',
			node: p.node ?? '',
			iface: p.iface ?? '',
			set: 'pc_' + ident(p['.name']),
			inbound_port: 12000 + length(cfg.proxyclients) + 1
		});
	});

	// managed remote nodes (xray installed on a Linux server by the router)
	cfg.nodes = {};
	c.foreach('usermanager', 'node', function(n) {
		if (!length(n.host ?? ''))
			return;
		cfg.nodes[n['.name']] = {
			sid: n['.name'],
			name: n.name ?? n['.name'],
			host: trim(n.host),
			ssh_port: to_int(n.ssh_port, 22),
			ssh_user: n.ssh_user ?? 'root',
			port: to_int(n.port, 8443),
			sni: n.sni ?? 'www.microsoft.com',
			uuid: n.uuid ?? '',
			public_key: n.public_key ?? '',
			short_id: n.short_id ?? '',
			fingerprint: n.fingerprint ?? 'chrome',
			installed: to_int(n.installed, 0) == 1,
			version: n.version ?? ''
		};
	});

	cfg.proxyservers = [];
	c.foreach('usermanager', 'proxyserver', function(p) {
		if (to_int(p.enabled, 1) != 1 || to_int(p.port, 0) <= 0)
			return;
		push(cfg.proxyservers, {
			sid: p['.name'],
			id: ident(p['.name']),
			name: p.name ?? p['.name'],
			type: (p.type == 'http') ? 'http' : 'socks',
			listen: (p.listen == 'all') ? 'all' : 'lan',
			port: to_int(p.port, 0),
			username: p.username ?? '',
			password: p.password ?? '',
			upstream: p.upstream ?? 'direct',    // 'direct' or 'pc:<sid>'
			iface: p.iface ?? ''
		});
	});

	// reverse SSH tunnels to a Linux server
	cfg.tunnels = [];
	c.foreach('usermanager', 'tunnel', function(t) {
		if (!length(t.host ?? '') || !length(t.user ?? ''))
			return;
		push(cfg.tunnels, {
			sid: t['.name'],
			name: t.name ?? t['.name'],
			enabled: to_int(t.enabled, 1) == 1,
			host: trim(t.host),
			port: to_int(t.port, 22),
			user: trim(t.user),
			remote_port: to_int(t.remote_port, 0),
			bind: length(t.bind ?? '') ? t.bind : '0.0.0.0',
			target_user: trim(t.target_user ?? ''),
			target_ip: trim(t.target_ip ?? ''),
			target_port: to_int(t.target_port, 0),
			keepalive: to_int(t.keepalive, 30)
		});
	});

	// one routing table / fwmark per interface used by routes, upstream proxies or proxy servers
	cfg.iface_tables = {};
	let ifn = 0;
	let want_iface = function(name) {
		if (!length(name ?? '') || exists(cfg.iface_tables, name))
			return;
		ifn++;
		cfg.iface_tables[name] = { mark: ROUTE_MARK_BASE + 0x40 + ifn, table: ROUTE_TABLE_BASE + 64 + ifn };
	};
	for (let p in cfg.proxyclients)
		want_iface(p.iface);
	for (let p in cfg.proxyservers)
		want_iface(p.iface);

	cfg.forwards = [];
	c.foreach('usermanager', 'forward', function(f) {
		if (to_int(f.enabled, 1) != 1)
			return;
		let proto = (f.proto == 'udp' || f.proto == 'tcp') ? f.proto : 'both';
		let sport = trim(f.src_port ?? '');
		if (!match(sport, /^[0-9]+(-[0-9]+)?$/))
			return;
		let dport = trim(f.dest_port ?? '');
		if (!match(dport, /^[0-9]+$/))
			dport = split(sport, '-')[0];
		push(cfg.forwards, {
			sid: f['.name'],
			name: f.name ?? '',
			proto: proto,
			src_port: sport,
			dest_user: trim(f.dest_user ?? ''),
			dest_ip: trim(f.dest_ip ?? ''),
			dest_port: dport
		});
	});

	return cfg;
}

// effective limits for a user (user overrides > profile)
function effective_limits(cfg, user) {
	let p = cfg.profiles[user.profile] ?? cfg.profiles['default'] ?? {
		id: user.profile, quota_mb: 0, rate_down: 0, rate_up: 0, validity_days: 0, session_timeout: 0,
		idle_timeout: 0, time_limit_min: 0, shared_users: 1, mac_cookie_hours: 0, proxy: 'passwall', block: []
	};
	return {
		profile: p.id,
		quota_bytes: (user.quota_mb ?? p.quota_mb) * 1024 * 1024,
		rate_down: user.rate_down ?? p.rate_down,
		rate_up: user.rate_up ?? p.rate_up,
		validity_days: p.validity_days,
		session_timeout: p.session_timeout,
		idle_timeout: p.idle_timeout,
		time_limit: p.time_limit_min * 60,
		shared_users: p.shared_users,
		mac_cookie: p.mac_cookie_hours * 3600,
		proxy: user.proxy ?? p.proxy,
		profile_block: length(p.block) > 0,
		user_block: length(user.block) > 0,
		throttle_rate: user.throttle_rate ?? p.throttle_rate,
		profile_throttle: length(p.cat_throttle) > 0,
		user_throttle: length(user.cat_throttle) > 0,
		conn_max_mb: user.conn_max_mb ?? p.conn_max_mb,
		conn_max_set: (user.conn_max_mb != null && user.conn_max_mb > 0) ? 'cm_u_' + ident(user.sid) : (p.conn_max_mb > 0 ? 'cm_p_' + ident(p.id) : null)
	};
}

// upstream proxy a session must use ('pc:<sid>' route), or null
function proxyclient_of(cfg, lim) {
	if (index(lim.proxy ?? '', 'pc:') != 0)
		return null;
	let sid = substr(lim.proxy, 3);
	for (let p in cfg.proxyclients)
		if (p.sid == sid)
			return p;
	return null;
}

// site-quota rules that apply to a user (by profile), route rules that name the user
function user_sitequotas(cfg, user, lim) {
	return filter(cfg.sitequotas, q => !length(q.profiles) || index(q.profiles, lim.profile) >= 0);
}

function user_routes(cfg, user) {
	return filter(cfg.routes, r => index(r.users, user.username) >= 0);
}

// ---------------------------------------------------------------- network info

function hostapd_objects() {
	let all;
	try {
		all = ubus().list();
	} catch (e) {
		return [];
	}
	return filter(all, n => index(n, 'hostapd.') == 0);
}

function lan_info(cfg) {
	let iface = cfg?.settings?.interface ?? 'lan';
	let st;
	try {
		st = ubus().call('network.interface.' + iface, 'status', {});
	} catch (e) {
		st = null;
	}
	let ip = st?.['ipv4-address']?.[0]?.address;
	let dev = st?.l3_device ?? st?.device;
	if (!ip) {
		let c = cursor();
		ip = c.get('network', iface, 'ipaddr');
		dev = dev ?? 'br-' + iface;
	}
	ip = ip ?? '192.168.1.1';

	// portal alias address: configured, or the .2 (or .3) address of the LAN subnet
	let pip = cfg?.settings?.portal_ip;
	if (!pip || !is_ipv4(pip)) {
		let o = split(ip, '.');
		let last = (o[3] == '2') ? '3' : '2';
		pip = o[0] + '.' + o[1] + '.' + o[2] + '.' + last;
	}
	return { ifname: dev ?? 'br-lan', ipaddr: ip, portal_ip: pip };
}

function portal_url(cfg, lan) {
	let s = cfg.settings;
	return 'http://' + s.portal_host + ((s.portal_port == 80) ? '' : ':' + s.portal_port);
}

function arp_table() {
	let res = {};
	let data = readfile('/proc/net/arp') ?? '';
	for (let line in split(data, '\n')) {
		let f = split(trim(line), /\s+/);
		if (length(f) < 6 || f[0] == 'IP')
			continue;
		if (f[2] == '0x0' || f[3] == '00:00:00:00:00:00')
			continue;
		res[f[0]] = { mac: lc(f[3]), dev: f[5] };
	}
	return res;
}

function dhcp_leases() {
	let res = { by_ip: {}, by_mac: {} };
	let data = readfile('/tmp/dhcp.leases') ?? '';
	for (let line in split(data, '\n')) {
		let f = split(trim(line), ' ');
		if (length(f) < 4)
			continue;
		let e = { expires: int(f[0]), mac: lc(f[1]), ip: f[2], hostname: (f[3] == '*') ? '' : f[3] };
		res.by_ip[e.ip] = e;
		res.by_mac[e.mac] = e;
	}
	return res;
}

function mac_of(ip) {
	let a = arp_table();
	if (a[ip])
		return a[ip].mac;
	let l = dhcp_leases();
	if (l.by_ip[ip])
		return l.by_ip[ip].mac;
	return null;
}

function wifi_clients() {
	let res = {};
	for (let obj in hostapd_objects()) {
		let r;
		try {
			r = ubus().call(obj, 'get_clients', {});
		} catch (e) {
			continue;
		}
		for (let mac, cl in (r?.clients ?? {}))
			res[lc(mac)] = { ifname: substr(obj, 8), signal: cl.signal, connected_time: cl.connected_time, bytes: cl.bytes };
	}
	return res;
}

function wifi_kick(mac) {
	let done = false;
	for (let obj in hostapd_objects()) {
		try {
			ubus().call(obj, 'del_client', { addr: mac, reason: 5, deauth: true, ban_time: 0 });
			done = true;
		} catch (e) {}
	}
	return done;
}

// ---------------------------------------------------------------- persistent state

function load_state() {
	let st = null;
	try {
		st = json(readfile(STATE_FILE) ?? '');
	} catch (e) {
		st = null;
	}
	if (type(st) != 'object')
		st = {};
	st.users = st.users ?? {};
	st.cookies = st.cookies ?? {};
	return st;
}

function save_state(st) {
	ensure_dirs();
	writefile(STATE_FILE + '.tmp', sprintf('%.J\n', st));
	run('mv ' + shellquote(STATE_FILE + '.tmp') + ' ' + shellquote(STATE_FILE));
}

function load_sessions() {
	let s = null;
	try {
		s = json(readfile(SESS_FILE) ?? '');
	} catch (e) {
		s = null;
	}
	return (type(s) == 'object') ? s : {};
}

function save_sessions(s) {
	ensure_dirs();
	writefile(SESS_FILE, sprintf('%.J\n', s));
}

// ---------------------------------------------------------------- nftables

function nft_batch(script) {
	ensure_dirs();
	writefile(NFT_TMP, script);
	let out = run('nft -f ' + NFT_TMP);
	if (length(trim(out ?? ''))) {
		log('nft error: ' + trim(out));
		return false;
	}
	return true;
}

function nft_json(cmd) {
	let out = run('nft -j ' + cmd);
	try {
		return json(out);
	} catch (e) {
		return null;
	}
}

function lim_name(dir, ip) {
	return dir + '_' + replace(ip, '.', '_');
}

// rate in kbit/s -> nft limit definition
function limit_def(name, kbit) {
	let bps = kbit * 125;            // bytes per second
	let burst = max(bps, 32768);     // 1 second of traffic, at least 32KB
	return sprintf('add limit %s %s { rate over %d bytes/second burst %d bytes }\n', TABLE, name, bps, burst);
}

function block_sets(cfg) {
	// returns [{ set, members, domains, kind, id }]
	let res = [];
	for (let pid, p in cfg.profiles)
		if (length(p.block))
			push(res, { kind: 'profile', id: pid, set: 'b_p_' + ident(pid), members: 'm_p_' + ident(pid), domains: p.block });
	for (let name, u in cfg.users)
		if (length(u.block))
			push(res, { kind: 'user', id: name, set: 'b_u_' + ident(u.sid), members: 'm_u_' + ident(u.sid), domains: u.block });
	return res;
}

// throttled categories: destination set (dnsmasq-fed) + member clients, per profile / user
function throttle_sets(cfg) {
	let res = [];
	for (let pid, p in cfg.profiles)
		if (length(p.cat_throttle))
			push(res, { kind: 'profile', id: pid, set: 't_p_' + ident(pid), members: 'tm_p_' + ident(pid), domains: category_domains(p.cat_throttle) });
	for (let name, u in cfg.users)
		if (length(u.cat_throttle))
			push(res, { kind: 'user', id: name, set: 't_u_' + ident(u.sid), members: 'tm_u_' + ident(u.sid), domains: category_domains(u.cat_throttle) });
	return res;
}

// per-connection download caps: one member set per profile / user that has conn_max_mb
function connmax_sets(cfg) {
	let res = [];
	for (let pid, p in cfg.profiles)
		if (p.conn_max_mb > 0)
			push(res, { set: 'cm_p_' + ident(pid), bytes: p.conn_max_mb * 1024 * 1024 });
	for (let name, u in cfg.users)
		if (u.conn_max_mb != null && u.conn_max_mb > 0)
			push(res, { set: 'cm_u_' + ident(u.sid), bytes: u.conn_max_mb * 1024 * 1024 });
	return res;
}

function fw_ruleset(cfg, lan) {
	let s = cfg.settings;
	let port = s.portal_port;
	let ip = lan.ipaddr;
	let pip = lan.portal_ip;
	let dev = lan.ifname;
	let out = '';
	let blocks = block_sets(cfg);
	let throttles = throttle_sets(cfg);
	let cms = connmax_sets(cfg);

	out += `destroy table ${TABLE}\n`;
	out += `table ${TABLE} {\n`;
	out += `	set authed { type ipv4_addr . ether_addr; counter; }\n`;
	out += `	set down { type ipv4_addr; counter; }\n`;
	out += `	set allow { type ipv4_addr; }\n`;
	out += `	set direct { type ipv4_addr; flags interval; auto-merge; }\n`;
	out += `	set bypass { type ether_addr; }\n`;
	out += `	set walled { type ipv4_addr; flags interval; auto-merge; }\n`;
	out += `	set b_g { type ipv4_addr; flags interval; auto-merge; }\n`;
	out += `	set direct_dst { type ipv4_addr; flags interval; auto-merge; }\n`;
	for (let b in blocks) {
		out += `	set ${b.set} { type ipv4_addr; flags interval; auto-merge; }\n`;
		out += `	set ${b.members} { type ipv4_addr; }\n`;
	}
	for (let t in throttles) {
		out += `	set ${t.set} { type ipv4_addr; flags interval; auto-merge; }\n`;
		out += `	set ${t.members} { type ipv4_addr; }\n`;
	}
	for (let c in cms)
		out += `	set ${c.set} { type ipv4_addr; }\n`;
	for (let r in cfg.routes) {
		out += `	set ${r.set_src} { type ipv4_addr; flags interval; auto-merge; }\n`;
		out += `	set ${r.set_dst} { type ipv4_addr; flags interval; auto-merge; }\n`;
	}
	for (let q in cfg.sitequotas) {
		out += `	set ${q.set} { type ipv4_addr; flags interval; auto-merge; }\n`;
		out += `	set ${q.set_up} { type ipv4_addr; counter; }\n`;
		out += `	set ${q.set_down} { type ipv4_addr; counter; }\n`;
		out += `	set ${q.set_block} { type ipv4_addr; }\n`;
	}
	for (let p in cfg.proxyclients)
		out += `	set ${p.set} { type ipv4_addr; }\n`;
	out += `	map up_lim { type ipv4_addr : limit; }\n`;
	out += `	map down_lim { type ipv4_addr : limit; }\n`;
	out += `	map thr_lim { type ipv4_addr : limit; }\n`;

	// policy routing marks: before passwall2 (-151) and fw4 mangle (-150)
	if (length(cfg.routes)) {
		out += `	chain route_mark {\n`;
		out += `		type filter hook prerouting priority -160; policy accept;\n`;
		for (let r in cfg.routes) {
			let m = sprintf('0x%x', r.mark);
			let has_src = length(r.src) || length(r.users);
			if (has_src && length(r.dst))
				out += `		iifname "${dev}" ip saddr @${r.set_src} ip daddr @${r.set_dst} meta mark set ${m} ct mark set ${m} comment "route ${ident(r.sid)}"\n`;
			else if (has_src)
				out += `		iifname "${dev}" ip saddr @${r.set_src} meta mark set ${m} ct mark set ${m} comment "route ${ident(r.sid)}"\n`;
			else
				out += `		iifname "${dev}" ip daddr @${r.set_dst} meta mark set ${m} ct mark set ${m} comment "route ${ident(r.sid)}"\n`;
		}
		out += `	}\n`;
	}

	out += `	chain pre_filter {\n`;
	out += `		type filter hook prerouting priority -300; policy accept;\n`;
	out += `		iifname "${dev}" jump lan_in\n`;
	out += `	}\n`;

	out += `	chain lan_in {\n`;
	out += `		ether saddr @bypass goto bypass_in\n`;
	out += `		ip saddr . ether saddr @authed goto authed_up\n`;
	out += `		ip saddr @allow counter drop comment "ip/mac mismatch"\n`;
	// unauthenticated clients
	out += `		udp sport 68 udp dport 67 accept comment "dhcp"\n`;
	out += `		ip daddr ${ip} meta l4proto { tcp, udp } th dport 53 accept comment "dns"\n`;
	out += `		ip daddr ${pip} tcp dport { ${port}, ${PORTAL_LISTEN}, ${PORTAL_LISTEN_TLS} } accept comment "portal"\n`;
	out += `		ip daddr { ${ip}, ${pip} } icmp type echo-request accept\n`;
	if (s.admin_unauth)
		out += `		ip daddr ${ip} tcp dport { 22, 80, 443 } accept comment "admin"\n`;
	out += `		tcp dport 80 accept comment "redirected to portal"\n`;
	out += `		ip daddr @walled accept comment "walled garden"\n`;
	out += `		tcp dport 443 reject with tcp reset\n`;
	out += `		meta nfproto ipv6 meta l4proto icmpv6 accept\n`;
	out += `		meta nfproto ipv6 udp dport 547 accept\n`;
	out += `		meta nfproto ipv6 meta l4proto { tcp, udp } th dport 53 reject comment "ipv6 dns: fall back to ipv4"\n`;
	out += `		counter drop comment "unauthenticated"\n`;
	out += `	}\n`;

	// Blocked destinations. HTTP(S) is let through here so that NEW connections can be
	// DNAT-ed to the block page; the decision for the rest happens in blocked_ct below,
	// after conntrack has run (this chain sits before conntrack at -300).
	out += `	chain blocked {\n`;
	out += `		tcp dport ${s.block_page_https ? '{ 80, 443 }' : '80'} meta mark set 0x7bb1 accept comment "block page candidate"\n`;
	out += `		meta l4proto tcp counter reject with tcp reset\n`;
	out += `		counter drop\n`;
	out += `	}\n`;
	out += `	chain blocked_ct {\n`;
	out += `		type filter hook prerouting priority -190; policy accept;\n`;
	// NB: "ct status != dnat" would compare the whole flag word and always match; mask the bit instead
	out += `		meta l4proto tcp meta mark 0x7bb1 ct state != new ct status & dnat == 0 counter reject with tcp reset comment "existing connection to a blocked site"\n`;
	out += `	}\n`;

	// bypass devices: no login, no quota - but (optionally) still subject to the global filter
	out += `	chain bypass_in {\n`;
	if (s.bypass_filter) {
		out += dns_enforce_rules(s.block_doh);
		out += `		ip daddr @b_g goto blocked\n`;
	}
	out += `		accept\n`;
	out += `	}\n`;

	out += `	chain authed_up {\n`;
	out += dns_enforce_rules(s.block_doh);
	out += `		ip daddr @b_g goto blocked\n`;
	for (let b in blocks)
		out += `		ip saddr @${b.members} ip daddr @${b.set} goto blocked\n`;
	for (let q in cfg.sitequotas) {
		out += `		ip saddr @${q.set_block} ip daddr @${q.set} goto blocked comment "sitequota exhausted"\n`;
		out += `		ip daddr @${q.set} ip saddr @${q.set_up} comment "sitequota upload"\n`;
	}
	// clients behind an upstream proxy: only TCP is proxied; drop other UDP so nothing leaks around it
	for (let p in cfg.proxyclients)
		out += `		ip saddr @${p.set} meta l4proto udp udp dport != 53 counter drop comment "proxy client udp"\n`;
	out += `		limit name ip saddr map @up_lim drop\n`;
	out += `		accept\n`;
	out += `	}\n`;

	out += `	chain post {\n`;
	out += `		type filter hook postrouting priority 0; policy accept;\n`;
	// throttled categories (download direction: traffic coming from the category's servers)
	for (let t in throttles)
		out += `		oifname "${dev}" ip saddr @${t.set} ip daddr @${t.members} limit name ip daddr map @thr_lim drop\n`;
	// per-site quota download accounting
	for (let q in cfg.sitequotas)
		out += `		oifname "${dev}" ip saddr @${q.set} ip daddr @${q.set_down} comment "sitequota download"\n`;
	// per-connection download size cap (protocol agnostic: counts conntrack reply bytes)
	for (let c in cms)
		out += `		oifname "${dev}" ip daddr @${c.set} ct reply bytes > ${c.bytes} counter drop comment "conn max ${c.set}"\n`;
	out += `		oifname "${dev}" ip daddr @down limit name ip daddr map @down_lim drop\n`;
	out += `	}\n`;

	// port forwards from the Internet side (filled dynamically by forwards_apply)
	out += `	chain wan_nat {\n`;
	out += `		type nat hook prerouting priority -100; policy accept;\n`;
	out += `	}\n`;
	out += `	chain wan_fwd {\n`;
	out += `		type filter hook forward priority -10; policy accept;\n`;
	out += `	}\n`;

	out += `	chain pre_nat {\n`;
	out += `		type nat hook prerouting priority -150; policy accept;\n`;
	out += `		iifname "${dev}" jump lan_nat\n`;
	out += `	}\n`;

	out += `	chain lan_nat {\n`;
	out += `		ip daddr ${pip} tcp dport ${port} dnat ip to ${pip}:${PORTAL_LISTEN} comment "portal"\n`;
	if (!s.bypass_filter)
		out += `		ether saddr @bypass return\n`;
	// DNS of hotspot clients goes through our own resolvers: "direct" users get real answers,
	// everyone else is forwarded to the main dnsmasq (passwall). Both feed the nftables filter sets.
	out += `		ip saddr @direct meta l4proto { tcp, udp } th dport 53 dnat ip to ${pip}:${DIRECT_DNS_PORT}\n`;
	out += `		meta l4proto { tcp, udp } th dport 53 dnat ip to ${pip}:${PROXY_DNS_PORT}\n`;
	// HTTP (and, with the router certificate, HTTPS) to a blocked site shows the "access restricted" page
	out += `		ip daddr @b_g tcp dport 80 dnat ip to ${pip}:${PORTAL_LISTEN} comment "block page"\n`;
	if (s.block_page_https)
		out += `		ip daddr @b_g tcp dport 443 dnat ip to ${pip}:${PORTAL_LISTEN_TLS} comment "block page https"\n`;
	for (let b in blocks) {
		out += `		ip saddr @${b.members} ip daddr @${b.set} tcp dport 80 dnat ip to ${pip}:${PORTAL_LISTEN} comment "block page"\n`;
		if (s.block_page_https)
			out += `		ip saddr @${b.members} ip daddr @${b.set} tcp dport 443 dnat ip to ${pip}:${PORTAL_LISTEN_TLS} comment "block page https"\n`;
	}
	for (let q in cfg.sitequotas) {
		out += `		ip saddr @${q.set_block} ip daddr @${q.set} tcp dport 80 dnat ip to ${pip}:${PORTAL_LISTEN} comment "quota page"\n`;
		if (s.block_page_https)
			out += `		ip saddr @${q.set_block} ip daddr @${q.set} tcp dport 443 dnat ip to ${pip}:${PORTAL_LISTEN_TLS} comment "quota page https"\n`;
	}
	if (s.bypass_filter)
		out += `		ether saddr @bypass return\n`;
	// transparent redirect of proxy-client TCP traffic into the matching xray inbound
	// (local / private destinations stay direct, otherwise the router's own services would loop)
	for (let p in cfg.proxyclients)
		out += `		ip saddr @${p.set} ip daddr != { 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 100.64.0.0/10, 127.0.0.0/8, 169.254.0.0/16, 224.0.0.0/3 } meta l4proto tcp redirect to :${p.inbound_port} comment "proxy ${p.id}"\n`;
	out += `		ip saddr @allow return\n`;
	if (s.admin_unauth)
		out += `		ip daddr != { ${ip}, ${pip} } tcp dport 80 dnat ip to ${pip}:${PORTAL_LISTEN}\n`;
	else
		out += `		ip daddr != ${pip} tcp dport 80 dnat ip to ${pip}:${PORTAL_LISTEN}\n`;
	out += `	}\n`;
	out += `}\n`;

	if (length(cfg.bypass))
		out += sprintf('add element %s bypass { %s }\n', TABLE, join(', ', cfg.bypass));

	// plain IPs / CIDRs go directly to the sets, domains are resolved by dnsmasq (nftset)
	let ips = filter(s.walled_garden, is_ipv4);
	if (length(ips))
		out += sprintf('add element %s walled { %s }\n', TABLE, join(', ', ips));
	ips = filter(s.block_global, is_ipv4);
	if (length(ips))
		out += sprintf('add element %s b_g { %s }\n', TABLE, join(', ', ips));
	ips = filter(s.direct_domains, is_ipv4);
	if (length(ips))
		out += sprintf('add element %s direct_dst { %s }\n', TABLE, join(', ', ips));
	for (let b in blocks) {
		ips = filter(b.domains, is_ipv4);
		if (length(ips))
			out += sprintf('add element %s %s { %s }\n', TABLE, b.set, join(', ', ips));
	}
	for (let t in throttles) {
		ips = filter(t.domains, is_ipv4);
		if (length(ips))
			out += sprintf('add element %s %s { %s }\n', TABLE, t.set, join(', ', ips));
	}
	for (let r in cfg.routes) {
		if (length(r.src)) {
			out += sprintf('add element %s %s { %s }\n', TABLE, r.set_src, join(', ', r.src));
			// statically routed clients leave the proxy, so they need real DNS answers too
			out += sprintf('add element %s direct { %s }\n', TABLE, join(', ', r.src));
		}
		ips = filter(r.dst, is_ipv4);
		if (length(ips))
			out += sprintf('add element %s %s { %s }\n', TABLE, r.set_dst, join(', ', ips));
	}
	for (let q in cfg.sitequotas) {
		ips = filter(q.domains, is_ipv4);
		if (length(ips))
			out += sprintf('add element %s %s { %s }\n', TABLE, q.set, join(', ', ips));
	}

	return out;
}

function session_rules(ip, mac, lim, sess) {
	let out = '';
	out += sprintf('add element %s authed { %s . %s }\n', TABLE, ip, mac);
	out += sprintf('add element %s down { %s }\n', TABLE, ip);
	out += sprintf('add element %s allow { %s }\n', TABLE, ip);
	if (lim.rate_up > 0) {
		out += limit_def(lim_name('u', ip), lim.rate_up);
		out += sprintf('add element %s up_lim { %s : "%s" }\n', TABLE, ip, lim_name('u', ip));
	}
	if (lim.rate_down > 0) {
		out += limit_def(lim_name('d', ip), lim.rate_down);
		out += sprintf('add element %s down_lim { %s : "%s" }\n', TABLE, ip, lim_name('d', ip));
	}
	if (sess.proxy == 'direct' || length(sess.rsets ?? []) || sess.pc_set)
		out += sprintf('add element %s direct { %s }\n', TABLE, ip);
	if (sess.pc_set)
		out += sprintf('add element %s %s { %s }\n', TABLE, sess.pc_set, ip);
	for (let m in (sess.members ?? []))
		out += sprintf('add element %s %s { %s }\n', TABLE, m, ip);
	if (sess.throttle_rate > 0 && length(sess.tmembers ?? [])) {
		out += limit_def(lim_name('t', ip), sess.throttle_rate);
		out += sprintf('add element %s thr_lim { %s : "%s" }\n', TABLE, ip, lim_name('t', ip));
		for (let m in sess.tmembers)
			out += sprintf('add element %s %s { %s }\n', TABLE, m, ip);
	}
	if (sess.cm_set)
		out += sprintf('add element %s %s { %s }\n', TABLE, sess.cm_set, ip);
	for (let q in (sess.quotas ?? [])) {
		out += sprintf('add element %s qu_%s { %s }\n', TABLE, q, ip);
		out += sprintf('add element %s qd_%s { %s }\n', TABLE, q, ip);
	}
	for (let q in (sess.quota_blocked ?? []))
		out += sprintf('add element %s qb_%s { %s }\n', TABLE, q, ip);
	for (let rs in (sess.rsets ?? []))
		out += sprintf('add element %s %s { %s }\n', TABLE, rs, ip);
	return out;
}

function session_remove_rules(sess) {
	let out = '';
	let ip = sess.ip;
	out += sprintf('delete element %s authed { %s . %s }\n', TABLE, ip, sess.mac);
	out += sprintf('delete element %s down { %s }\n', TABLE, ip);
	out += sprintf('delete element %s allow { %s }\n', TABLE, ip);
	if (sess.rate_up > 0) {
		out += sprintf('delete element %s up_lim { %s }\n', TABLE, ip);
		out += sprintf('delete limit %s %s\n', TABLE, lim_name('u', ip));
	}
	if (sess.rate_down > 0) {
		out += sprintf('delete element %s down_lim { %s }\n', TABLE, ip);
		out += sprintf('delete limit %s %s\n', TABLE, lim_name('d', ip));
	}
	if (sess.proxy == 'direct' || length(sess.rsets ?? []) || sess.pc_set)
		out += sprintf('delete element %s direct { %s }\n', TABLE, ip);
	if (sess.pc_set)
		out += sprintf('delete element %s %s { %s }\n', TABLE, sess.pc_set, ip);
	for (let m in (sess.members ?? []))
		out += sprintf('delete element %s %s { %s }\n', TABLE, m, ip);
	if (sess.throttle_rate > 0 && length(sess.tmembers ?? [])) {
		for (let m in sess.tmembers)
			out += sprintf('delete element %s %s { %s }\n', TABLE, m, ip);
		out += sprintf('delete element %s thr_lim { %s }\n', TABLE, ip);
		out += sprintf('delete limit %s %s\n', TABLE, lim_name('t', ip));
	}
	if (sess.cm_set)
		out += sprintf('delete element %s %s { %s }\n', TABLE, sess.cm_set, ip);
	for (let q in (sess.quotas ?? [])) {
		out += sprintf('delete element %s qu_%s { %s }\n', TABLE, q, ip);
		out += sprintf('delete element %s qd_%s { %s }\n', TABLE, q, ip);
	}
	for (let q in (sess.quota_blocked ?? []))
		out += sprintf('delete element %s qb_%s { %s }\n', TABLE, q, ip);
	for (let rs in (sess.rsets ?? []))
		out += sprintf('delete element %s %s { %s }\n', TABLE, rs, ip);
	return out;
}

// ---------------------------------------------------------------- port forwards

const FORWARDS_FILE = RUN_DIR + '/forwards.nft';

// resolve forward targets (username -> ip of an active session) and (re)build the wan chains
function forwards_apply(cfg, sessions, lan) {
	lan = lan ?? lan_info(cfg);
	let dev = lan.ifname;
	let nat = '', fwd = '';
	for (let f in cfg.forwards) {
		let dst = null;
		if (length(f.dest_user)) {
			for (let ip, s in sessions)
				if (s.user == f.dest_user) {
					dst = ip;
					break;
				}
		} else if (is_ipv4(f.dest_ip)) {
			dst = f.dest_ip;
		}
		if (!dst)
			continue;
		let protos = (f.proto == 'both') ? [ 'tcp', 'udp' ] : [ f.proto ];
		for (let p in protos) {
			nat += sprintf('add rule %s wan_nat iifname != "%s" meta nfproto ipv4 %s dport %s dnat ip to %s:%s comment "fwd %s"\n',
				TABLE, dev, p, f.src_port, dst, f.dest_port, ident(f.sid));
			fwd += sprintf('add rule %s wan_fwd iifname != "%s" oifname "%s" ct status dnat ip daddr %s %s dport %s accept comment "fwd %s"\n',
				TABLE, dev, dev, dst, p, f.dest_port, ident(f.sid));
		}
	}
	let script = sprintf('flush chain %s wan_nat\nflush chain %s wan_fwd\n', TABLE, TABLE) + nat + fwd;
	if ((readfile(FORWARDS_FILE) ?? '') == script)
		return false;
	if (nft_batch(script))
		writefile(FORWARDS_FILE, script);
	return true;
}

function forwards_report(cfg, sessions) {
	cfg = cfg ?? load_config();
	sessions = sessions ?? load_sessions();
	let res = {};
	for (let f in cfg.forwards) {
		let dst = null;
		if (length(f.dest_user)) {
			for (let ip, s in sessions)
				if (s.user == f.dest_user) { dst = ip; break; }
		} else if (is_ipv4(f.dest_ip)) {
			dst = f.dest_ip;
		}
		res[f.sid] = { active: !!dst, target: dst, reason: dst ? null : (length(f.dest_user) ? 'user offline' : 'no target') };
	}
	return res;
}

// ---------------------------------------------------------------- passwall integration (auto-detected)

// Which proxy framework is installed and active? Detected from its nftables chains, cached 10 s.
// Supported: Passwall2 (table inet passwall2, PSW2_*), Passwall (table inet passwall, PSW_*), none.
let pw_cache = null, pw_cache_t = 0;
function passwall_info() {
	if (pw_cache_t && (now() - pw_cache_t) < 10)
		return pw_cache;
	let res = null;
	if (match(run('nft list chain inet passwall2 PSW2_NAT') ?? '', /chain PSW2_NAT/))
		res = { name: 'passwall2', table: 'inet passwall2', nat: 'PSW2_NAT', mangle: 'PSW2_MANGLE', out_nat: 'PSW2_OUTPUT_NAT', out_mangle: 'PSW2_OUTPUT_MANGLE' };
	else if (match(run('nft list chain inet passwall PSW_NAT') ?? '', /chain PSW_NAT/))
		res = { name: 'passwall', table: 'inet passwall', nat: 'PSW_NAT', mangle: 'PSW_MANGLE', out_nat: 'PSW_OUTPUT_NAT', out_mangle: 'PSW_OUTPUT_MANGLE' };
	pw_cache = res;
	pw_cache_t = now();
	return res;
}

function passwall_present() {
	return passwall_info() != null;
}

// what this router can do; features degrade gracefully when something is missing
function capabilities() {
	let dm = run('dnsmasq --version') ?? '';
	let rel = readfile('/etc/openwrt_release') ?? '';
	let m = match(rel, /DISTRIB_RELEASE='([^']*)'/);
	return {
		openwrt: m ? m[1] : '',
		passwall: passwall_info()?.name ?? null,
		xray: !!access(XRAY_BIN, 'x'),
		dnsmasq_nftset: !!match(dm, /[^-]nftset/) && !match(dm, /no-nftset/),
		tls: !!(access('/lib/libustream-ssl.so') || access('/usr/lib/libustream-ssl.so') || length(glob('/usr/lib/libustream-*')) || access('/usr/lib/uhttpd_tls.so')),
		dbclient: !!access('/usr/bin/dbclient', 'x'),
		fw4: !!(access('/usr/sbin/fw4', 'x') || access('/sbin/fw4', 'x')),
		conntrack_acct: (trim(readfile('/proc/sys/net/netfilter/nf_conntrack_acct') ?? '0') == '1'),
		version: trim(readfile('/usr/share/usermanager/VERSION') ?? 'dev')
	};
}

// elements of an nftables set as strings (plain, prefix or range)
function set_elements(table, name) {
	let j = nft_json('list set ' + table + ' ' + ident(name));
	let out = [];
	let found = false;
	for (let item in (j?.nftables ?? [])) {
		if (!item?.set)
			continue;
		found = true;
		for (let e in (item.set.elem ?? [])) {
			if (type(e) == 'string')
				push(out, e);
			else if (type(e) == 'object' && e.prefix)
				push(out, e.prefix.addr + '/' + e.prefix.len);
			else if (type(e) == 'object' && e.range)
				push(out, e.range[0] + '-' + e.range[1]);
		}
	}
	return found ? out : null;
}

// remove everything we ever added to passwall2's table
function passwall_cleanup() {
	let pw = passwall_info();
	if (!pw)
		return;
	let script = '';
	for (let chain in [ pw.nat, pw.mangle ]) {
		let out = run('nft -a list chain ' + pw.table + ' ' + chain) ?? '';
		for (let line in split(out, '\n')) {
			let m = match(line, /um_direct.*# handle ([0-9]+)/);
			if (m)
				script += sprintf('delete rule ' + pw.table + ' %s handle %s\n', chain, m[1]);
		}
	}
	script += 'destroy set ' + pw.table + ' um_direct\n';
	script += 'destroy set ' + pw.table + ' um_direct_dst\n';
	nft_batch(script);
}

// keep passwall2 from hijacking the proxy traffic the router itself originates (marked 0x7aXX)
function passwall_output_sync() {
	let pw = passwall_info();
	if (!pw)
		return;
	let script = '';
	for (let chain in [ pw.out_nat, pw.out_mangle ]) {
		let out = run('nft list chain ' + pw.table + ' ' + chain) ?? '';
		if (match(out, /chain /) && !match(out, /0x00007a00/))
			script += sprintf('insert rule ' + pw.table + ' %s meta mark & 0x0000ff00 == 0x00007a00 counter return comment "usermanager proxies"\n', chain);
	}
	if (length(script))
		nft_batch(script);
}

// clients that must leave the proxy: direct-route sessions, sessions of policy-routed users
// and statically policy-routed addresses
function direct_sources(cfg, sessions) {
	let out = [];
	for (let ip, s in sessions)
		if (s.proxy == 'direct' || length(s.rsets ?? []) || s.pc_set)
			push(out, ip);
	for (let r in cfg.routes)
		for (let a in r.src)
			push(out, a);
	return sort(uniq(out));
}

// keep passwall2's chains skipping (a) the clients that must go direct and
// (b) the destinations (sites / TLDs) that must not go through the proxy
function passwall_sync(sessions, cfg) {
	let pw = passwall_info();
	if (!pw)
		return false;
	cfg = cfg ?? load_config();
	let script = '';

	// (a) source based bypass (interval set: policy routes may list CIDRs)
	let want = direct_sources(cfg, sessions);
	let have = set_elements(pw.table, 'um_direct');
	let listing = run('nft list set ' + pw.table + ' um_direct') ?? '';
	if (have != null && !match(listing, /interval/)) {
		// created by an older version without interval support: drop rules + sets and rebuild
		passwall_cleanup();
		have = null;
	}
	if (have == null)
		script += 'add set ' + pw.table + ' um_direct { type ipv4_addr; flags interval; auto-merge; }\n';
	else if (join(',', sort(have)) != join(',', want))
		script += 'flush set ' + pw.table + ' um_direct\n';
	if (have == null || join(',', sort(have)) != join(',', want))
		if (length(want))
			script += sprintf('add element ' + pw.table + ' um_direct { %s }\n', join(', ', want));

	// (b) destination based bypass: mirror of our direct_dst set (dnsmasq feeds both,
	//     the mirror survives a passwall2 restart)
	let dst_have = set_elements(pw.table, 'um_direct_dst');
	if (dst_have == null) {
		script += 'add set ' + pw.table + ' um_direct_dst { type ipv4_addr; flags interval; auto-merge; }\n';
		let mirror = set_elements(TABLE, 'direct_dst') ?? [];
		if (length(mirror))
			script += sprintf('add element ' + pw.table + ' um_direct_dst { %s }\n', join(', ', mirror));
	}

	for (let chain in [ pw.nat, pw.mangle ]) {
		let out = run('nft list chain ' + pw.table + ' ' + chain) ?? '';
		if (!match(out, /chain /))
			continue;
		if (!match(out, /@um_direct_dst/))
			script += sprintf('insert rule ' + pw.table + ' %s ip daddr @um_direct_dst counter return comment "usermanager direct-dst"\n', chain);
		if (!match(out, /@um_direct /))
			script += sprintf('insert rule ' + pw.table + ' %s ip saddr @um_direct counter return comment "usermanager direct"\n', chain);
	}
	let ok = length(script) ? nft_batch(script) : true;
	passwall_output_sync();
	return ok;
}

// make passwall2's destination bypass set identical to our (freshly rebuilt) mirror
function passwall_mirror_dst() {
	let pw = passwall_info();
	if (!pw)
		return;
	let mirror = set_elements(TABLE, 'direct_dst') ?? [];
	let script = '';
	if (set_elements(pw.table, 'um_direct_dst') == null)
		script += 'add set ' + pw.table + ' um_direct_dst { type ipv4_addr; flags interval; auto-merge; }\n';
	else
		script += 'flush set ' + pw.table + ' um_direct_dst\n';
	if (length(mirror))
		script += sprintf('add element ' + pw.table + ' um_direct_dst { %s }\n', join(', ', mirror));
	nft_batch(script);
}

// ---------------------------------------------------------------- policy routing

// all logical interfaces of the router that could carry hotspot traffic (for the UI)
function interfaces(cfg) {
	let res = [];
	let dump;
	try {
		dump = ubus().call('network.interface', 'dump', {});
	} catch (e) {
		return res;
	}
	let lan_name = cfg?.settings?.interface ?? 'lan';
	for (let i in (dump?.interface ?? [])) {
		if (i.interface == 'loopback' || i.interface == lan_name)
			continue;
		let gw = null;
		for (let r in (i.route ?? []))
			if (r.target == '0.0.0.0' && r.mask == 0 && r.nexthop)
				gw = r.nexthop;
		push(res, {
			name: i.interface,
			proto: i.proto,
			up: !!i.up,
			device: i.l3_device ?? i.device ?? '',
			address: i['ipv4-address']?.[0]?.address ?? '',
			gateway: gw,
			uptime: i.uptime ?? 0
		});
	}
	return res;
}

// program ip rules / tables for the configured policy routes and the interfaces used by
// upstream proxies / proxy servers (idempotent)
function routes_apply(cfg) {
	let want = {};   // mark(hex) -> table
	let info = {};
	for (let i in interfaces(cfg))
		info[i.name] = i;
	let entries = [];
	for (let r in cfg.routes)
		push(entries, { iface: r.iface, mark: r.mark, table: r.table });
	for (let name, t in (cfg.iface_tables ?? {}))
		push(entries, { iface: name, mark: t.mark, table: t.table });
	for (let e in entries) {
		let i = info[e.iface];
		let m = sprintf('0x%x', e.mark);
		want[m] = e.table;
		if (i && i.up && length(i.device)) {
			if (i.gateway)
				run(sprintf('ip -4 route replace default via %s dev %s table %d', i.gateway, i.device, e.table));
			else
				run(sprintf('ip -4 route replace default dev %s table %d', i.device, e.table));
		} else {
			// interface down: blackhole instead of silently falling back to the main table
			run(sprintf('ip -4 route replace blackhole default table %d', e.table));
		}
	}
	// rules: add missing, remove stale (only our mark range)
	let rules = run('ip -4 rule show') ?? '';
	let present = {};
	for (let line in split(rules, '\n')) {
		let m = match(line, /fwmark (0x7a[0-9a-f]{2}) lookup (\d+)/);
		if (m)
			present[m[1]] = int(m[2]);
	}
	for (let mark, table in want)
		if (present[mark] != table)
			run(sprintf('ip -4 rule add fwmark %s table %d priority %d', mark, table, 32000 + (table - ROUTE_TABLE_BASE)));
	for (let mark, table in present)
		if (!exists(want, mark)) {
			run(sprintf('ip -4 rule del fwmark %s table %d', mark, table));
			run(sprintf('ip -4 route flush table %d', table));
		}
}

// ---------------------------------------------------------------- proxies (xray)

function xray_available() {
	return access(XRAY_BIN, 'x');
}

function iface_mark(cfg, iface) {
	let t = cfg.iface_tables?.[iface];
	return t ? t.mark : MARK_OUR_DEFAULT;
}

// xray outbound object for an upstream proxy definition
function xray_outbound(cfg, p) {
	let tag = 'out_pc_' + p.id;
	let sockopt = { mark: iface_mark(cfg, p.iface) };
	let stream = { network: 'tcp', security: 'none', sockopt: sockopt };
	let ob = { tag: tag, protocol: 'freedom', settings: {}, streamSettings: stream };

	let apply_transport = function() {
		stream.network = (p.network == 'ws' || p.network == 'grpc' || p.network == 'xhttp') ? p.network : 'tcp';
		if (stream.network == 'ws')
			stream.wsSettings = { path: length(p.path) ? p.path : '/', headers: length(p.host_header) ? { Host: p.host_header } : {} };
		else if (stream.network == 'grpc')
			stream.grpcSettings = { serviceName: p.path };
		else if (stream.network == 'xhttp')
			stream.xhttpSettings = { path: length(p.path) ? p.path : '/', host: p.host_header };
		if (p.security == 'tls') {
			stream.security = 'tls';
			stream.tlsSettings = { serverName: length(p.sni) ? p.sni : p.host, allowInsecure: p.insecure, fingerprint: 'chrome' };
		} else if (p.security == 'reality') {
			stream.security = 'reality';
			stream.realitySettings = { serverName: p.sni, publicKey: p.public_key, shortId: p.short_id, fingerprint: 'chrome' };
		}
	};

	switch (p.type) {
	case 'node': {
		let n = cfg.nodes[p.node];
		if (!n || !length(n.uuid))
			return null;
		ob.protocol = 'vless';
		ob.settings = { vnext: [ { address: n.host, port: n.port, users: [ { id: n.uuid, encryption: 'none', flow: 'xtls-rprx-vision' } ] } ] };
		stream.security = 'reality';
		stream.realitySettings = { serverName: n.sni, publicKey: n.public_key, shortId: n.short_id, fingerprint: n.fingerprint ?? 'chrome' };
		break;
	}
	case 'socks':
		ob.protocol = 'socks';
		ob.settings = { servers: [ { address: p.host, port: p.port, users: length(p.username) ? [ { user: p.username, pass: p.password } ] : [] } ] };
		break;
	case 'http':
		ob.protocol = 'http';
		ob.settings = { servers: [ { address: p.host, port: p.port, users: length(p.username) ? [ { user: p.username, pass: p.password } ] : [] } ] };
		if (p.security == 'tls') { stream.security = 'tls'; stream.tlsSettings = { serverName: length(p.sni) ? p.sni : p.host, allowInsecure: p.insecure }; }
		break;
	case 'ss':
		ob.protocol = 'shadowsocks';
		ob.settings = { servers: [ { address: p.host, port: p.port, method: p.method, password: p.password } ] };
		break;
	case 'vless':
		ob.protocol = 'vless';
		{
			let user = { id: p.uuid, encryption: 'none' };
			if (length(p.flow))
				user.flow = p.flow;
			ob.settings = { vnext: [ { address: p.host, port: p.port, users: [ user ] } ] };
		}
		apply_transport();
		break;
	case 'vmess':
		ob.protocol = 'vmess';
		ob.settings = { vnext: [ { address: p.host, port: p.port, users: [ { id: p.uuid, security: 'auto' } ] } ] };
		apply_transport();
		break;
	case 'trojan':
		ob.protocol = 'trojan';
		ob.settings = { servers: [ { address: p.host, port: p.port, password: p.password } ] };
		if (p.security != 'reality') p.security = 'tls';
		apply_transport();
		break;
	case 'json': {
		let j = null;
		try { j = json(p.json); } catch (e) { j = null; }
		if (type(j) != 'object')
			return null;
		j.tag = tag;
		j.streamSettings = j.streamSettings ?? {};
		j.streamSettings.sockopt = { ...(j.streamSettings.sockopt ?? {}), mark: sockopt.mark };
		return j;
	}
	}
	return ob;
}

// full xray configuration for the router: transparent inbounds per upstream proxy,
// socks/http proxy servers, outbounds bound to the selected interfaces
function xray_config(cfg, lan) {
	let inbounds = [], outbounds = [], rules = [];
	let used_pc = {};
	for (let pid, p in cfg.profiles)
		if (index(p.proxy, 'pc:') == 0) used_pc[substr(p.proxy, 3)] = true;
	for (let name, u in cfg.users)
		if (u.proxy && index(u.proxy, 'pc:') == 0) used_pc[substr(u.proxy, 3)] = true;
	for (let s in cfg.proxyservers)
		if (index(s.upstream, 'pc:') == 0) used_pc[substr(s.upstream, 3)] = true;

	for (let p in cfg.proxyclients) {
		let ob = xray_outbound(cfg, p);
		if (!ob)
			continue;
		push(outbounds, ob);
		if (used_pc[p.sid]) {
			push(inbounds, {
				tag: 'in_pc_' + p.id, protocol: 'dokodemo-door', listen: '0.0.0.0', port: p.inbound_port,
				settings: { network: 'tcp', followRedirect: true },
				sniffing: { enabled: true, destOverride: [ 'http', 'tls' ], routeOnly: false }
			});
			push(rules, { type: 'field', inboundTag: [ 'in_pc_' + p.id ], outboundTag: ob.tag });
		}
	}
	// direct outbounds (per interface) used by proxy servers
	let direct_tags = {};
	for (let s in cfg.proxyservers) {
		let tag;
		if (index(s.upstream, 'pc:') == 0) {
			tag = 'out_pc_' + ident(substr(s.upstream, 3));
			if (!length(filter(outbounds, o => o.tag == tag)))
				continue;
		} else {
			tag = 'out_direct_' + (length(s.iface) ? ident(s.iface) : 'main');
			if (!direct_tags[tag]) {
				direct_tags[tag] = true;
				push(outbounds, { tag: tag, protocol: 'freedom', settings: { domainStrategy: 'UseIPv4' }, streamSettings: { sockopt: { mark: iface_mark(cfg, s.iface) } } });
			}
		}
		let listen = (s.listen == 'all') ? '0.0.0.0' : lan.ipaddr;
		let ib = { tag: 'in_ps_' + s.id, protocol: s.type, listen: listen, port: s.port, settings: {} };
		if (s.type == 'socks') {
			ib.settings = { auth: length(s.username) ? 'password' : 'noauth', udp: true, ip: lan.ipaddr };
			if (length(s.username)) ib.settings.accounts = [ { user: s.username, pass: s.password } ];
		} else {
			ib.settings = length(s.username) ? { accounts: [ { user: s.username, pass: s.password } ] } : {};
		}
		push(inbounds, ib);
		push(rules, { type: 'field', inboundTag: [ 'in_ps_' + s.id ], outboundTag: tag });
	}
	if (!length(inbounds))
		return null;
	push(outbounds, { tag: 'out_block', protocol: 'blackhole' });
	return {
		log: { loglevel: 'warning', error: XRAY_LOG },
		// resolve names with real DNS: the system resolver would hand out Passwall FakeDNS addresses
		dns: { servers: cfg.settings.direct_dns, queryStrategy: 'UseIPv4', disableCache: false },
		inbounds: inbounds,
		outbounds: outbounds,
		routing: { domainStrategy: 'AsIs', rules: [ ...rules, { type: 'field', inboundTag: map(inbounds, i => i.tag), outboundTag: 'out_block' } ] }
	};
}

// write the xray config; returns true when it changed (init reload restarts the instance)
function write_xray_config(cfg, lan) {
	ensure_dirs();
	let conf = xray_config(cfg, lan);
	let text = conf ? sprintf('%.J\n', conf) : '';
	let old = readfile(XRAY_CONF) ?? '';
	if (length(text))
		writefile(XRAY_CONF, text);
	else if (access(XRAY_CONF))
		unlink(XRAY_CONF);
	return old != text;
}

function proxies_report() {
	let cfg = load_config();
	let inst = {};
	try {
		inst = ubus().call('service', 'list', { name: 'usermanager' })?.usermanager?.instances ?? {};
	} catch (e) {}
	let lan = lan_info(cfg);
	let clients = {}, servers = {};
	for (let p in cfg.proxyclients) {
		let users = 0;
		for (let name, u in cfg.users) {
			let lim = effective_limits(cfg, u);
			if (lim.proxy == 'pc:' + p.sid) users++;
		}
		clients[p.sid] = { inbound_port: p.inbound_port, users: users, iface: p.iface, iface_mark: sprintf('0x%x', iface_mark(cfg, p.iface)), node_ok: p.type != 'node' || !!(cfg.nodes[p.node]?.uuid) };
	}
	for (let s in cfg.proxyservers)
		servers[s.sid] = { url: sprintf('%s://%s:%d', s.type, (s.listen == 'all') ? lan.ipaddr : lan.ipaddr, s.port) };
	return {
		xray_available: xray_available(),
		xray_running: !!inst.proxyd?.running,
		xray_version: xray_available() ? trim(split(run(XRAY_BIN + ' version 2>/dev/null') ?? '', '\n')[0]) : '',
		clients: clients,
		servers: servers,
		log: run('tail -n 20 ' + XRAY_LOG + ' 2>/dev/null') ?? ''
	};
}

function routes_clear() {
	let rules = run('ip -4 rule show') ?? '';
	for (let line in split(rules, '\n')) {
		let m = match(line, /fwmark (0x7a[0-9a-f]{2}) lookup (\d+)/);
		if (m) {
			run(sprintf('ip -4 rule del fwmark %s table %s', m[1], m[2]));
			run(sprintf('ip -4 route flush table %s', m[2]));
		}
	}
}

function routes_report(cfg) {
	cfg = cfg ?? load_config();
	let info = {};
	for (let i in interfaces(cfg))
		info[i.name] = i;
	let res = {};
	for (let r in cfg.routes) {
		let i = info[r.iface];
		res[r.sid] = {
			iface_up: !!(i && i.up),
			device: i?.device ?? null,
			gateway: i?.gateway ?? null,
			mark: sprintf('0x%x', r.mark),
			table: r.table,
			members: set_elements(TABLE, r.set_src) ?? [],
			dst_addrs: length(set_elements(TABLE, r.set_dst) ?? [])
		};
	}
	return res;
}

// ---------------------------------------------------------------- dnsmasq integration

function dnsmasq_confdir() {
	for (let f in glob('/var/etc/dnsmasq.conf.*')) {
		let m = match(readfile(f) ?? '', /conf-dir=([^,\n]+)/);
		if (m)
			return m[1];
	}
	return '/tmp/dnsmasq.d';
}

// dnsmasq picks the *longest matching* domain for nftset= and server= directives. A name such
// as dibachain.ir therefore must carry the targets of all its suffixes (walled garden entry
// AND the ".ir goes direct" rule), otherwise the more specific entry hides the general one.
function nftset_lines(cfg, lan) {
	let s = cfg.settings;
	let pw = passwall_info();
	let psw = !!pw;
	let pw_target = pw ? ('4#' + replace(pw.table, ' ', '#') + '#um_direct_dst') : '';
	let targets = {};   // domain -> { nftset target -> true }
	let direct = {};    // domain -> true (needs real DNS)

	let add = function(domain, target) {
		domain = lc(trim(domain, '. '));
		if (!length(domain) || is_ipv4(domain))
			return;
		targets[domain] = targets[domain] ?? {};
		if (target)
			targets[domain][target] = true;
	};

	for (let d in s.walled_garden)
		add(d, '4#inet#usermanager#walled');
	for (let d in s.block_global)
		add(d, '4#inet#usermanager#b_g');
	for (let b in block_sets(cfg))
		for (let d in b.domains)
			add(d, '4#inet#usermanager#' + b.set);
	for (let t in throttle_sets(cfg))
		for (let d in t.domains)
			add(d, '4#inet#usermanager#' + t.set);
	for (let d in s.direct_domains) {
		add(d, '4#inet#usermanager#direct_dst');
		if (psw)
			add(d, pw_target);
		if (!is_ipv4(d))
			direct[lc(trim(d, '. '))] = true;
	}
	// policy-routed destinations also leave the proxy
	for (let r in cfg.routes)
		for (let d in r.dst) {
			add(d, '4#inet#usermanager#' + r.set_dst);
			if (psw)
				add(d, pw_target);
			if (!is_ipv4(d))
				direct[lc(trim(d, '. '))] = true;
		}
	for (let q in cfg.sitequotas)
		for (let d in q.domains)
			add(d, '4#inet#usermanager#' + q.set);

	// inherit the targets of every parent suffix that has its own entry
	let names = sort(keys(targets));
	let final = {};
	let needs_real_dns = {};
	for (let name in names) {
		let set = { ...targets[name] };
		let real = !!direct[name];
		let parts = split(name, '.');
		for (let i = 1; i < length(parts); i++) {
			let parent = join('.', slice(parts, i));
			if (targets[parent])
				for (let t in keys(targets[parent]))
					set[t] = true;
			if (direct[parent])
				real = true;
		}
		final[name] = sort(keys(set));
		if (real)
			needs_real_dns[name] = true;
	}

	let out = '# generated by usermanager\n';
	out += sprintf('address=/%s/%s\n', s.portal_host, lan.portal_ip);
	for (let name in names) {
		if (needs_real_dns[name])
			for (let dns in s.direct_dns)
				out += sprintf('server=/%s/%s\n', name, dns);
		if (length(final[name]))
			out += sprintf('nftset=/%s/%s\n', name, join(',', final[name]));
	}
	return out;
}

// write the shared nftset/address config for the main dnsmasq and our resolvers.
// The resolvers only read nftset.conf at start: when it changes (and we are not already
// running from the init script) the service is reloaded so procd restarts them.
function write_dns_configs(cfg, lan, from_init) {
	ensure_dirs();
	let lines = nftset_lines(cfg, lan);
	let old_lines = readfile(NFTSET_CONF) ?? '';
	writefile(NFTSET_CONF, lines);
	let resolvers_changed = (old_lines != lines);

	let common = sprintf('listen-address=%s\nbind-interfaces\nno-resolv\nno-hosts\nno-poll\ncache-size=1000\nconf-file=%s\nlog-queries\n', lan.portal_ip, NFTSET_CONF);

	let direct = sprintf('port=%d\npid-file=%s/dnsmasq-direct.pid\nlog-facility=%s\n', DIRECT_DNS_PORT, RUN_DIR, DNSLOG_DIRECT) + common;
	for (let d in cfg.settings.direct_dns)
		direct += sprintf('server=%s\n', d);
	if ((readfile(DIRECT_DNS_CONF) ?? '') != direct)
		resolvers_changed = true;
	writefile(DIRECT_DNS_CONF, direct);

	let proxy = sprintf('port=%d\npid-file=%s/dnsmasq-proxy.pid\nlog-facility=%s\n', PROXY_DNS_PORT, RUN_DIR, DNSLOG_PROXY) + common;
	proxy += sprintf('server=%s#53\n', lan.ipaddr);
	writefile(PROXY_DNS_CONF, proxy);

	// main dnsmasq: only the portal hostname (needed for clients that bypass the hotspot)
	let dir = dnsmasq_confdir();
	let path = dir + '/usermanager.conf';
	let want = sprintf('# generated by usermanager\naddress=/%s/%s\n', cfg.settings.portal_host, lan.portal_ip);
	let have = readfile(path) ?? '';
	if (have != want) {
		if (!access(dir))
			mkdir(dir, 0o755);
		writefile(path, want);
		run('/etc/init.d/dnsmasq reload');
	}

	if (resolvers_changed && !from_init) {
		log('resolver configuration changed, restarting resolvers');
		system('( /etc/init.d/usermanager reload ) >/dev/null 2>&1 &');
	}
	return resolvers_changed;
}

function remove_dns_configs() {
	let path = dnsmasq_confdir() + '/usermanager.conf';
	if (access(path)) {
		unlink(path);
		run('/etc/init.d/dnsmasq reload');
	}
}

// alias address the portal and the direct resolver listen on
function alias_add(lan) {
	run(sprintf('ip addr replace %s/32 dev %s label %s:um', lan.portal_ip, lan.ifname, lan.ifname));
}

function alias_del(lan) {
	run(sprintf('ip addr del %s/32 dev %s', lan.portal_ip, lan.ifname));
}

// called by the init script before starting the portal / resolver instances
function prepare() {
	let cfg = load_config();
	let lan = lan_info(cfg);
	ensure_dirs();
	run('chmod 600 /etc/config/usermanager');
	alias_add(lan);
	write_dns_configs(cfg, lan, true);
	write_xray_config(cfg, lan);
	print(sprintf('%s %s %d %d\n', lan.portal_ip, lan.ifname, PORTAL_LISTEN, PORTAL_LISTEN_TLS));
	return lan;
}

function fw_installed() {
	let out = run('nft list chain ' + TABLE + ' lan_in');
	return !!match(out ?? '', /chain lan_in/);
}

// live view of one of our nftables sets (for monitoring the block / walled / direct lists)
function set_contents(name) {
	return set_elements(TABLE, name) ?? [];
}

// definitions of the dnsmasq-fed sets (walled garden + block lists): set name -> sorted entries
function dns_set_defs(cfg) {
	let defs = {
		walled: sort(uniq(cfg.settings.walled_garden)),
		b_g: sort(uniq(cfg.settings.block_global)),
		direct_dst: sort(uniq(cfg.settings.direct_domains))
	};
	for (let b in block_sets(cfg))
		defs[b.set] = sort(uniq(b.domains));
	for (let t in throttle_sets(cfg))
		defs[t.set] = sort(uniq(t.domains));
	for (let r in cfg.routes)
		defs[r.set_dst] = sort(uniq(r.dst));
	for (let q in cfg.sitequotas)
		defs[q.set] = sort(uniq(q.domains));
	return defs;
}

const DNSSETS_FILE = RUN_DIR + '/dnssets.json';

// The addresses dnsmasq collected so far must survive a ruleset rebuild (otherwise clients
// with cached DNS answers slip through until they resolve the name again) - but only for
// sets whose domain list did not change. A set whose list changed starts empty and is
// re-seeded, so removing a domain from a block list really unblocks it.
function snapshot_sets(cfg) {
	let snap = {};
	if (!fw_installed())
		return snap;
	let prev = null;
	try {
		prev = json(readfile(DNSSETS_FILE) ?? '');
	} catch (e) {
		prev = null;
	}
	if (type(prev) != 'object')
		prev = {};
	let defs = dns_set_defs(cfg);
	for (let name, entries in defs) {
		if (!exists(prev, name) || join('\n', prev[name]) != join('\n', entries))
			continue;
		let el = set_contents(name);
		if (length(el))
			snap[name] = el;
	}
	return snap;
}

function save_set_defs(cfg) {
	ensure_dirs();
	writefile(DNSSETS_FILE, sprintf('%.J\n', dns_set_defs(cfg)));
}

function restore_sets(snap) {
	let out = '';
	for (let name, el in snap)
		out += sprintf('add element %s %s { %s }\n', TABLE, name, join(', ', el));
	if (length(out))
		nft_batch(out);
}

// resolve the filtered domains once through our resolver so the sets are filled right away
function seed_sets(cfg, lan) {
	let domains = [];
	for (let d in cfg.settings.block_global)
		if (!is_ipv4(d)) push(domains, d);
	for (let b in block_sets(cfg))
		for (let d in b.domains)
			if (!is_ipv4(d)) push(domains, d);
	for (let t in throttle_sets(cfg))
		for (let d in t.domains)
			if (!is_ipv4(d)) push(domains, d);
	for (let r in cfg.routes)
		for (let d in r.dst)
			if (!is_ipv4(d)) push(domains, d);
	for (let q in cfg.sitequotas)
		for (let d in q.domains)
			if (!is_ipv4(d)) push(domains, d);
	for (let d in cfg.settings.walled_garden)
		if (!is_ipv4(d)) push(domains, d);
	for (let d in cfg.settings.direct_domains)
		if (!is_ipv4(d) && index(d, '.') > 0) push(domains, d);   // bare TLDs cannot be pre-resolved
	domains = uniq(domains);
	if (!length(domains))
		return;
	let cmd = '(sleep 5; for d in';
	for (let d in slice(domains, 0, 60))
		cmd += ' ' + shellquote(d) + ' ' + shellquote('www.' + d);
	cmd += sprintf('; do nslookup "$d" %s:%d >/dev/null 2>&1; done) >/dev/null 2>&1 &', lan.portal_ip, PROXY_DNS_PORT);
	system(cmd);
}

function fw_setup(cfg) {
	cfg = cfg ?? load_config();
	let lan = lan_info(cfg);
	alias_add(lan);
	let snap = snapshot_sets(cfg);
	let ok = nft_batch(fw_ruleset(cfg, lan));
	if (ok) {
		restore_sets(snap);
		save_set_defs(cfg);
		passwall_mirror_dst();
		write_dns_configs(cfg, lan);
		seed_sets(cfg, lan);
		if (length(cfg.routes) || length(keys(cfg.iface_tables)))
			routes_apply(cfg);
		else
			routes_clear();
		if (write_xray_config(cfg, lan)) {
			log('proxy configuration changed, restarting xray');
			system('( /etc/init.d/usermanager reload ) >/dev/null 2>&1 &');
		}
		passwall_output_sync();
	}
	return ok;
}

function fw_teardown() {
	let cfg = load_config();
	let lan = lan_info(cfg);
	nft_batch(`destroy table ${TABLE}\n`);
	unlink(DNSSETS_FILE);
	unlink(FORWARDS_FILE);
	routes_clear();
	passwall_cleanup();
	remove_dns_configs();
	alias_del(lan);
}

// read per-element counters
function fw_counters() {
	let res = { up: {}, down: {} };
	let j = nft_json('list set ' + TABLE + ' authed');
	for (let item in (j?.nftables ?? [])) {
		for (let e in (item?.set?.elem ?? [])) {
			let ip = e?.elem?.val?.concat?.[0];
			if (ip)
				res.up[ip] = e.elem.counter?.bytes ?? 0;
		}
	}
	j = nft_json('list set ' + TABLE + ' down');
	for (let item in (j?.nftables ?? [])) {
		for (let e in (item?.set?.elem ?? [])) {
			let ip = e?.elem?.val;
			if (type(ip) == 'string')
				res.down[ip] = e.elem.counter?.bytes ?? 0;
		}
	}
	return res;
}

// ---------------------------------------------------------------- usage helpers

function session_bytes(cfg, sess) {
	return (cfg.settings.count_mode == 'download') ? sess.down_acc : (sess.up_acc + sess.down_acc);
}

function user_used(cfg, st, sessions, username) {
	let base = st.users[username]?.used ?? 0;
	for (let ip, s in sessions)
		if (s.user == username)
			base += session_bytes(cfg, s);
	return base;
}

function user_time_used(st, sessions, username) {
	let base = st.users[username]?.time_used ?? 0;
	for (let ip, s in sessions)
		if (s.user == username)
			base += (now() - s.start);
	return base;
}

function parse_date(str) {
	let m = match(str ?? '', /^(\d{4})-(\d{2})-(\d{2})([ T](\d{2}):(\d{2}))?/);
	if (!m)
		return null;
	return timelocal({ year: int(m[1]), mon: int(m[2]), mday: int(m[3]), hour: int(m[5] ?? 0), min: int(m[6] ?? 0), sec: 0, isdst: -1 });
}

function user_expiry(cfg, st, user) {
	let lim = effective_limits(cfg, user);
	let exp = null;
	if (lim.validity_days > 0) {
		let first = st.users[user.username]?.first_login;
		if (first)
			exp = first + lim.validity_days * 86400;
	}
	if (length(user.valid_until)) {
		let t = parse_date(user.valid_until);
		if (t && (exp == null || t < exp))
			exp = t;
	}
	return exp;
}

// Check whether a user may (still) be online. Returns null if OK or an error code.
function check_user(cfg, st, sessions, user) {
	if (!user.enabled)
		return 'disabled';
	let lim = effective_limits(cfg, user);
	let exp = user_expiry(cfg, st, user);
	if (exp != null && now() >= exp)
		return 'expired';
	if (lim.quota_bytes > 0 && user_used(cfg, st, sessions, user.username) >= lim.quota_bytes)
		return 'quota';
	if (lim.time_limit > 0 && user_time_used(st, sessions, user.username) >= lim.time_limit)
		return 'timelimit';
	return null;
}

// which member sets a session of this user belongs to
function member_sets(cfg, user, lim) {
	let m = [];
	if (lim.profile_block)
		push(m, 'm_p_' + ident(lim.profile));
	if (lim.user_block)
		push(m, 'm_u_' + ident(user.sid));
	return m;
}

// throttle member sets of a session (only meaningful with a throttle rate)
function throttle_members(cfg, user, lim) {
	let m = [];
	if (lim.profile_throttle)
		push(m, 'tm_p_' + ident(lim.profile));
	if (lim.user_throttle)
		push(m, 'tm_u_' + ident(user.sid));
	return m;
}

// ---------------------------------------------------------------- per-site daily quotas

// today's consumption of one quota rule by one user: folded state + running sessions
function quota_used(cfg, st, sessions, username, qid) {
	let d = today();
	let su = st.users[username]?.sq?.[qid];
	let bytes = (su && su.date == d) ? (su.bytes ?? 0) : 0;
	let secs = (su && su.date == d) ? (su.secs ?? 0) : 0;
	for (let ip, s in sessions)
		if (s.user == username && s.sq?.[qid] && s.sq[qid].date == d) {
			bytes += s.sq[qid].bytes ?? 0;
			secs += s.sq[qid].secs ?? 0;
		}
	return { bytes: bytes, secs: secs };
}

function quota_exhausted(q, used) {
	return (q.daily_bytes > 0 && used.bytes >= q.daily_bytes) || (q.daily_secs > 0 && used.secs >= q.daily_secs);
}

// fold a session's running quota counters into persistent state
function fold_quotas(st, sess) {
	if (!sess.sq)
		return;
	let u = st.users[sess.user] = st.users[sess.user] ?? {};
	u.sq = u.sq ?? {};
	for (let qid, acc in sess.sq) {
		if (!(acc.bytes || acc.secs))
			continue;
		let e = u.sq[qid];
		if (!e || e.date != acc.date)
			e = u.sq[qid] = { date: acc.date, bytes: 0, secs: 0 };
		e.bytes += acc.bytes;
		e.secs += acc.secs;
		acc.bytes = 0;
		acc.secs = 0;
	}
}

// the quota rules of this user that are already exhausted today (set idents)
function quota_blocked_today(cfg, st, sessions, user, lim) {
	let out = [];
	for (let q in user_sitequotas(cfg, user, lim))
		if (quota_exhausted(q, quota_used(cfg, st, sessions, user.username, ident(q.sid))))
			push(out, ident(q.sid));
	return out;
}

// per-element byte counters of a set
function set_counters(name) {
	let res = {};
	let j = nft_json('list set ' + TABLE + ' ' + name);
	for (let item in (j?.nftables ?? []))
		for (let e in (item?.set?.elem ?? []))
			if (type(e) == 'object' && type(e.elem?.val) == 'string')
				res[e.elem.val] = e.elem.counter?.bytes ?? 0;
	return res;
}

// why a request to <host> from <ip> is blocked, if it is a per-site quota (for the portal)
function quota_block_info(ip, host) {
	let cfg = load_config();
	let st = load_state();
	let sessions = load_sessions();
	let s = sessions[ip];
	if (!s || !host)
		return null;
	let user = cfg.users[s.user];
	if (!user)
		return null;
	let lim = effective_limits(cfg, user);
	host = lc(host);
	for (let q in user_sitequotas(cfg, user, lim)) {
		let hit = false;
		for (let d in q.domains)
			if (host == d || substr(host, -length(d) - 1) == '.' + d)
				hit = true;
		if (!hit)
			continue;
		let used = quota_used(cfg, st, sessions, s.user, ident(q.sid));
		if (quota_exhausted(q, used))
			return { name: q.name, daily_bytes: q.daily_bytes, daily_secs: q.daily_secs, used: used };
	}
	return null;
}

// ---------------------------------------------------------------- sessions

// attribute the bytes a running session gained since the last fold to today's daily total
function fold_daily(cfg, st, sess) {
	let u = st.users[sess.user] = st.users[sess.user] ?? {};
	let total = session_bytes(cfg, sess);
	let delta = total - (sess.folded ?? 0);
	if (delta <= 0)
		return;
	u.daily = u.daily ?? {};
	let d = today();
	u.daily[d] = (u.daily[d] ?? 0) + delta;
	sess.folded = total;
	// trim old days
	let days = sort(keys(u.daily));
	while (length(days) > DAILY_KEEP) {
		delete u.daily[days[0]];
		days = slice(days, 1);
	}
}

function do_deauth(cfg, st, sessions, ip, reason) {
	let sess = sessions[ip];
	if (!sess)
		return false;
	nft_batch(session_remove_rules(sess));
	fold_daily(cfg, st, sess);
	fold_quotas(st, sess);
	let u = st.users[sess.user] = st.users[sess.user] ?? {};
	u.used = (u.used ?? 0) + session_bytes(cfg, sess);
	u.up = (u.up ?? 0) + sess.up_acc;
	u.down = (u.down ?? 0) + sess.down_acc;
	u.time_used = (u.time_used ?? 0) + (now() - sess.start);
	u.last_logout = now();
	u.history = u.history ?? [];
	push(u.history, { start: sess.start, end: now(), ip: ip, mac: sess.mac, hostname: sess.hostname ?? '',
		up: sess.up_acc, down: sess.down_acc, reason: reason, via: sess.via ?? 'portal', proxy: sess.proxy ?? 'passwall' });
	while (length(u.history) > HISTORY_MAX)
		shift(u.history);
	delete sessions[ip];
	log(sprintf('logout user=%s ip=%s mac=%s reason=%s up=%d down=%d dur=%ds',
		sess.user, ip, sess.mac, reason, sess.up_acc, sess.down_acc, now() - sess.start));
	if (sess.proxy == 'direct' || length(sess.rsets ?? []))
		passwall_sync(sessions, cfg);
	forwards_apply(cfg, sessions);
	if (cfg.settings.kick_wifi && reason != 'logout' && reason != 'relogin')
		wifi_kick(sess.mac);
	return true;
}

function login(ip, username, password, opts) {
	return with_lock(function() {
		let cfg = load_config();
		let st = load_state();
		let sessions = load_sessions();
		opts = opts ?? {};

		if (!cfg.settings.enabled)
			return { ok: false, error: 'disabled_service' };

		let mac = opts.mac ?? mac_of(ip);
		if (!mac)
			return { ok: false, error: 'nomac' };
		mac = lc(mac);

		let user = cfg.users[username];
		if (!user)
			return { ok: false, error: 'badcred' };
		if (!opts.cookie && user.password != password)
			return { ok: false, error: 'badcred' };
		if (length(user.mac) && user.mac != mac)
			return { ok: false, error: 'macbind' };

		if (sessions[ip]) {
			if (sessions[ip].user == username && sessions[ip].mac == mac)
				return { ok: true, session: sessions[ip], already: true };
			do_deauth(cfg, st, sessions, ip, 'relogin');
		}

		let err = check_user(cfg, st, sessions, user);
		if (err)
			return { ok: false, error: err };

		let lim = effective_limits(cfg, user);
		let active = length(filter(values(sessions), s => s.user == username));
		if (lim.shared_users > 0 && active >= lim.shared_users)
			return { ok: false, error: 'shared' };

		if (!fw_installed())
			fw_setup(cfg);

		let leases = dhcp_leases();
		let sess = {
			ip: ip,
			mac: mac,
			user: username,
			profile: lim.profile,
			hostname: leases.by_ip[ip]?.hostname ?? leases.by_mac[mac]?.hostname ?? '',
			start: now(),
			last_activity: now(),
			up_last: 0,
			down_last: 0,
			up_acc: 0,
			down_acc: 0,
			rate_up: lim.rate_up,
			rate_down: lim.rate_down,
			proxy: lim.proxy,
			members: member_sets(cfg, user, lim),
			throttle_rate: lim.throttle_rate,
			tmembers: throttle_members(cfg, user, lim),
			cm_set: lim.conn_max_set,
			quotas: map(user_sitequotas(cfg, user, lim), q => ident(q.sid)),
			quota_blocked: quota_blocked_today(cfg, st, sessions, user, lim),
			sq: {},
			rsets: map(user_routes(cfg, user), r => r.set_src),
			pc_set: proxyclient_of(cfg, lim)?.set ?? null,
			via: opts.cookie ? 'cookie' : 'portal'
		};
		let first_login = !(st.users[username]?.logins > 0);

		if (!nft_batch(session_rules(ip, mac, lim, sess)))
			return { ok: false, error: 'firewall' };

		sessions[ip] = sess;
		if (sess.proxy == 'direct' || length(sess.rsets))
			passwall_sync(sessions, cfg);
		forwards_apply(cfg, sessions);

		let u = st.users[username] = st.users[username] ?? {};
		u.first_login = u.first_login ?? now();
		u.last_login = now();
		u.last_ip = ip;
		u.last_mac = mac;
		u.logins = (u.logins ?? 0) + 1;

		if (lim.mac_cookie > 0)
			st.cookies[mac] = { user: username, until: now() + lim.mac_cookie };

		save_sessions(sessions);
		save_state(st);
		log(sprintf('login user=%s ip=%s mac=%s via=%s proxy=%s', username, ip, mac, sess.via, sess.proxy));
		return { ok: true, session: sess, first_login: first_login && !user.voucher && !opts.cookie };
	});
}

// try MAC-cookie auto login for a client
function cookie_login(ip) {
	let mac = mac_of(ip);
	if (!mac)
		return { ok: false, error: 'nomac' };
	let st = load_state();
	let ck = st.cookies[lc(mac)];
	if (!ck || ck.until < now())
		return { ok: false, error: 'nocookie' };
	return login(ip, ck.user, null, { cookie: true, mac: mac });
}

function logout(ip, reason) {
	return with_lock(function() {
		let cfg = load_config();
		let st = load_state();
		let sessions = load_sessions();
		if (!sessions[ip])
			return false;
		if (reason == 'logout' || reason == 'kick')
			delete st.cookies[sessions[ip].mac];
		do_deauth(cfg, st, sessions, ip, reason ?? 'logout');
		save_sessions(sessions);
		save_state(st);
		return true;
	});
}

function kick_user(username, reason) {
	return with_lock(function() {
		let cfg = load_config();
		let st = load_state();
		let sessions = load_sessions();
		let n = 0;
		for (let ip in keys(sessions)) {
			if (sessions[ip].user == username) {
				delete st.cookies[sessions[ip].mac];
				do_deauth(cfg, st, sessions, ip, reason ?? 'kick');
				n++;
			}
		}
		save_sessions(sessions);
		save_state(st);
		return n;
	});
}

function reset_usage(username) {
	return with_lock(function() {
		let st = load_state();
		let u = st.users[username] = st.users[username] ?? {};
		u.used = 0;
		u.up = 0;
		u.down = 0;
		u.time_used = 0;
		delete u.first_login;
		let sessions = load_sessions();
		for (let ip, s in sessions)
			if (s.user == username) {
				s.up_acc = 0;
				s.down_acc = 0;
			}
		save_sessions(sessions);
		save_state(st);
		log('usage reset for user=' + username);
		return true;
	});
}

function forget_user(username) {
	return with_lock(function() {
		let st = load_state();
		delete st.users[username];
		for (let mac in keys(st.cookies))
			if (st.cookies[mac].user == username)
				delete st.cookies[mac];
		save_state(st);
		return true;
	});
}

// the router's own SSH key (used for tunnels and node management)
function tunnel_pubkey() {
	ensure_dirs();
	if (!access(TUNNEL_KEY))
		run('dropbearkey -t ed25519 -f ' + TUNNEL_KEY);
	let out = run('dropbearkey -y -f ' + TUNNEL_KEY) ?? '';
	for (let line in split(out, '\n'))
		if (index(line, 'ssh-') == 0) {
			let f = split(trim(line), ' ');
			return f[0] + ' ' + f[1] + ' usermanager@router';
		}
	return null;
}

// ---------------------------------------------------------------- password management

function valid_password(cfg, pw) {
	if (type(pw) != 'string' || length(pw) < cfg.settings.pw_min_len || length(pw) > 64)
		return false;
	return !match(pw, /[\s'"\\]/);
}

// set a user's password in UCI (admin or self-service); marks when the user changed it
function set_user_password(username, pw, by_user) {
	let cfg = load_config();
	let user = cfg.users[username];
	if (!user)
		return { ok: false, error: 'nouser' };
	if (!valid_password(cfg, pw))
		return { ok: false, error: 'weak' };
	let c = cursor();
	c.set('usermanager', user.sid, 'password', pw);
	if (by_user) {
		let t = localtime();
		c.set('usermanager', user.sid, 'pw_changed', sprintf('%04d-%02d-%02d %02d:%02d', t.year, t.mon, t.mday, t.hour, t.min));
	}
	c.commit('usermanager');
	run('chmod 600 /etc/config/usermanager');
	log(sprintf('password of user=%s changed by %s', username, by_user ? 'user' : 'admin'));
	return { ok: true };
}

// portal: the client at <ip> changes the password of its own account
function change_password(ip, old_pw, new_pw, first) {
	let cfg = load_config();
	if (!cfg.settings.pw_allow_change && !first)
		return { ok: false, error: 'notallowed' };
	let sessions = load_sessions();
	let s = sessions[ip];
	if (!s)
		return { ok: false, error: 'nosession' };
	let user = cfg.users[s.user];
	if (!user)
		return { ok: false, error: 'nouser' };
	if (!first && user.password != old_pw)
		return { ok: false, error: 'badold' };
	if (new_pw == user.password)
		return { ok: false, error: 'same' };
	return set_user_password(s.user, new_pw, true);
}

// ---------------------------------------------------------------- managed nodes (xray on a remote server)

const NODE_SCRIPT = '/usr/share/usermanager/install-node.sh';

// run the node management script on the server; bootstrap with a password, afterwards with our key
function node_run(n, args, password) {
	ensure_dirs();
	tunnel_pubkey();
	let outfile = RUN_DIR + '/node_' + ident(n.sid) + '.out';
	let auth = length(password ?? '') ? sprintf('DROPBEAR_PASSWORD=%s ', shellquote(password)) : '';
	let keyopt = length(password ?? '') ? '' : ('-i ' + TUNNEL_KEY + ' ');
	let cmd = sprintf('%s/usr/bin/dbclient -y -y %s-p %d %s@%s %s < %s > %s 2>&1',
		auth, keyopt, n.ssh_port, n.ssh_user, n.host,
		shellquote('bash -s -- ' + args + ' --key ' + shellquote(tunnel_pubkey())), NODE_SCRIPT, outfile);
	let rc = system(cmd, 180000);
	let out = readfile(outfile) ?? '';
	unlink(outfile);
	let result = null;
	for (let line in split(out, '\n')) {
		let m = match(line, /^NODE_RESULT (.*)$/);
		if (m) {
			try { result = json(m[1]); } catch (e) { result = null; }
		}
	}
	return { rc: rc, output: trim(out), result: result };
}

function node_install(sid, password) {
	let cfg = load_config();
	let n = cfg.nodes[sid];
	if (!n)
		return { ok: false, error: 'no such node' };
	let args = sprintf('--install --port %d --sni %s', n.port, shellquote(n.sni));
	let r = node_run(n, args, password);
	if (!r.result || !r.result.uuid) {
		log(sprintf('node install %s (%s) failed rc=%d', n.name, n.host, r.rc));
		return { ok: false, output: r.output, rc: r.rc };
	}
	let c = cursor();
	c.set('usermanager', sid, 'uuid', r.result.uuid);
	c.set('usermanager', sid, 'public_key', r.result.public_key);
	c.set('usermanager', sid, 'short_id', r.result.short_id);
	c.set('usermanager', sid, 'installed', '1');
	c.set('usermanager', sid, 'version', r.result.version ?? '');
	c.commit('usermanager');
	log(sprintf('node %s installed on %s (xray %s)', n.name, n.host, r.result.version ?? '?'));
	return { ok: true, result: r.result, output: r.output };
}

// status | restart | update | uninstall (key based)
function node_action(sid, action, password) {
	let cfg = load_config();
	let n = cfg.nodes[sid];
	if (!n)
		return { ok: false, error: 'no such node' };
	if (index([ 'status', 'restart', 'update', 'uninstall', 'logs' ], action) < 0)
		return { ok: false, error: 'bad action' };
	let r = node_run(n, '--' + action + sprintf(' --port %d --sni %s', n.port, shellquote(n.sni)), password);
	if (action == 'uninstall' && r.result?.ok) {
		let c = cursor();
		c.set('usermanager', sid, 'installed', '0');
		c.commit('usermanager');
	}
	if (action == 'update' && r.result?.version) {
		let c = cursor();
		c.set('usermanager', sid, 'version', r.result.version);
		c.commit('usermanager');
	}
	return { ok: r.rc == 0 && (r.result?.ok ?? true), result: r.result, output: r.output, rc: r.rc };
}

function node_share_link(n) {
	if (!length(n.uuid))
		return null;
	return sprintf('vless://%s@%s:%d?encryption=none&flow=xtls-rprx-vision&security=reality&sni=%s&fp=%s&pbk=%s&sid=%s&type=tcp#%s',
		n.uuid, n.host, n.port, n.sni, n.fingerprint, n.public_key, n.short_id, replace(n.name, ' ', '_'));
}

function nodes_report() {
	let cfg = load_config();
	let res = {};
	for (let sid, n in cfg.nodes) {
		let used = length(filter(cfg.proxyclients, p => p.type == 'node' && p.node == sid));
		res[sid] = { installed: n.installed, version: n.version, has_keys: length(n.uuid) > 0, link: node_share_link(n), used_by: used };
	}
	return { nodes: res, pubkey: tunnel_pubkey() };
}

// ---------------------------------------------------------------- daemon work

let last_persist = 0;
let config_mtime = 0;
let tick_n = 0;

function config_stamp() {
	return stat(CONFIG_FILE)?.mtime ?? 0;
}

// ---------------------------------------------------------------- reverse SSH tunnels

function tunnel_target(cfg, sessions, t) {
	if (length(t.target_user)) {
		for (let ip, s in sessions)
			if (s.user == t.target_user)
				return ip;
		return null;
	}
	return is_ipv4(t.target_ip) ? t.target_ip : null;
}

function tunnel_command(t, target) {
	return sprintf('/usr/bin/dbclient -N -y -y -i %s -K %d -p %d -R %s:%d:%s:%d %s@%s',
		TUNNEL_KEY, t.keepalive > 0 ? t.keepalive : 30, t.port, t.bind, t.remote_port, target, t.target_port, t.user, t.host);
}

// "sid<TAB>command" lines for every tunnel that can run right now (used by the init script)
function tunnel_cmds(cfg, sessions) {
	cfg = cfg ?? load_config();
	sessions = sessions ?? load_sessions();
	let out = [];
	for (let t in cfg.tunnels) {
		if (!t.enabled || t.remote_port <= 0 || t.target_port <= 0)
			continue;
		let target = tunnel_target(cfg, sessions, t);
		if (!target)
			continue;
		push(out, { sid: t.sid, cmd: tunnel_command(t, target) });
	}
	return out;
}

// restart the tunnel instances through the init script when a target moved
function tunnels_check(cfg, sessions) {
	let text = join('\n', map(tunnel_cmds(cfg, sessions), x => x.sid + '\t' + x.cmd)) + '\n';
	if ((readfile(TUNNELS_FILE) ?? '') == text)
		return false;
	writefile(TUNNELS_FILE, text);
	log('tunnel targets changed, reloading tunnel instances');
	system('( /etc/init.d/usermanager reload ) >/dev/null 2>&1 &');
	return true;
}

// one-time: install our public key on the server (password login) and enable GatewayPorts
function tunnel_setup(sid, password) {
	let cfg = load_config();
	let t = filter(cfg.tunnels, x => x.sid == sid)[0];
	if (!t)
		return { ok: false, error: 'no such tunnel' };
	let pub = tunnel_pubkey();
	if (!pub)
		return { ok: false, error: 'could not create ssh key (dropbearkey missing?)' };
	let remote = "K=" + shellquote(pub) + "; " +
		"mkdir -p ~/.ssh && chmod 700 ~/.ssh && touch ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys; " +
		"grep -qF \"$K\" ~/.ssh/authorized_keys || echo \"$K\" >> ~/.ssh/authorized_keys; echo KEY_OK; " +
		"SUDO=''; if [ \"$(id -u)\" != 0 ]; then sudo -n true 2>/dev/null && SUDO='sudo -n'; fi; " +
		"if [ \"$(id -u)\" = 0 ] || [ -n \"$SUDO\" ]; then CFG=/etc/ssh/sshd_config; " +
		"$SUDO sh -c \"grep -q '^GatewayPorts' $CFG && sed -i 's/^GatewayPorts.*/GatewayPorts clientspecified/' $CFG || echo 'GatewayPorts clientspecified' >> $CFG; " +
		"grep -q '^AllowTcpForwarding' $CFG && sed -i 's/^AllowTcpForwarding.*/AllowTcpForwarding yes/' $CFG || echo 'AllowTcpForwarding yes' >> $CFG; " +
		"grep -q '^ClientAliveInterval' $CFG || echo 'ClientAliveInterval 30' >> $CFG; " +
		"systemctl reload sshd 2>/dev/null || systemctl reload ssh 2>/dev/null || service sshd reload 2>/dev/null || service ssh reload 2>/dev/null || true\"; " +
		"echo GATEWAY_OK; else echo NO_ROOT; fi";
	let outfile = RUN_DIR + '/tunnel_setup.out';
	let cmd = sprintf('DROPBEAR_PASSWORD=%s /usr/bin/dbclient -y -y -p %d %s@%s %s > %s 2>&1',
		shellquote(password ?? ''), t.port, t.user, t.host, shellquote(remote), outfile);
	let rc = system(cmd, 45000);
	let out = readfile(outfile) ?? '';
	unlink(outfile);
	let ok = (rc == 0 && index(out, 'KEY_OK') >= 0);
	log(sprintf('tunnel setup %s -> %s@%s: %s', t.name, t.user, t.host, ok ? 'ok' : 'failed'));
	if (ok)
		tunnels_check(cfg, load_sessions());
	return { ok: ok, gateway: index(out, 'GATEWAY_OK') >= 0, root: index(out, 'NO_ROOT') < 0, pubkey: pub, output: trim(out), rc: rc };
}

function tunnels_report() {
	let cfg = load_config();
	let sessions = load_sessions();
	let inst = {};
	try {
		inst = ubus().call('service', 'list', { name: 'usermanager' })?.usermanager?.instances ?? {};
	} catch (e) {}
	let res = {};
	for (let t in cfg.tunnels) {
		let target = tunnel_target(cfg, sessions, t);
		let i = inst['tunnel_' + ident(t.sid)];
		res[t.sid] = {
			target: target,
			running: !!i?.running,
			pid: i?.pid ?? null,
			public_url: sprintf('%s:%d', t.host, t.remote_port),
			reason: target ? null : (length(t.target_user) ? 'user offline' : 'no target')
		};
	}
	return { tunnels: res, pubkey: tunnel_pubkey() };
}

// one accounting step for the per-site quotas (called from tick, under the lock)
function sitequota_tick(cfg, st, sessions, t) {
	let d = today();
	let counters = {};
	for (let q in cfg.sitequotas) {
		let qid = ident(q.sid);
		counters[qid] = { up: set_counters(q.set_up), down: set_counters(q.set_down), q: q };
	}
	for (let ip, s in sessions) {
		s.sq = s.sq ?? {};
		for (let qid in (s.quotas ?? [])) {
			let c = counters[qid];
			if (!c)
				continue;
			let acc = s.sq[qid] = s.sq[qid] ?? { date: d, bytes: 0, secs: 0, u_last: 0, d_last: 0 };
			if (acc.date != d) {
				// midnight: fold yesterday, start a fresh day, lift the block
				fold_quotas(st, s);
				acc.date = d;
				acc.bytes = 0;
				acc.secs = 0;
				if (index(s.quota_blocked ?? [], qid) >= 0) {
					nft_batch(sprintf('delete element %s qb_%s { %s }\n', TABLE, qid, ip));
					s.quota_blocked = filter(s.quota_blocked, x => x != qid);
					log(sprintf('sitequota "%s" reset for user=%s (new day)', c.q.name, s.user));
				}
			}
			let up = c.up[ip] ?? acc.u_last, down = c.down[ip] ?? acc.d_last;
			let delta = ((up >= acc.u_last) ? up - acc.u_last : up) + ((down >= acc.d_last) ? down - acc.d_last : down);
			acc.u_last = up;
			acc.d_last = down;
			if (delta > 0) {
				acc.bytes += delta;
				acc.secs += 5;
			}
			if (index(s.quota_blocked ?? [], qid) < 0 && quota_exhausted(c.q, quota_used(cfg, st, sessions, s.user, qid))) {
				nft_batch(sprintf('add element %s qb_%s { %s }\n', TABLE, qid, ip));
				s.quota_blocked = [ ...(s.quota_blocked ?? []), qid ];
				log(sprintf('sitequota "%s" exhausted for user=%s ip=%s', c.q.name, s.user, ip));
			}
		}
	}
}

function rotate_dns_logs() {
	for (let f in [ DNSLOG_PROXY, DNSLOG_DIRECT ]) {
		let s = stat(f);
		if (s && s.size > DNSLOG_MAX)
			run(sprintf('tail -c %d %s > %s.tmp && cat %s.tmp > %s; rm -f %s.tmp', DNSLOG_KEEP, f, f, f, f, f));
	}
}

// re-add all sessions to a freshly created table, re-evaluating limits from the current config
function restore_rules(cfg, sessions) {
	let rules = '';
	for (let ip, s in sessions) {
		s.up_last = 0;
		s.down_last = 0;
		let user = cfg.users[s.user];
		if (user) {
			let lim = effective_limits(cfg, user);
			s.rate_up = lim.rate_up;
			s.rate_down = lim.rate_down;
			s.proxy = lim.proxy;
			s.profile = lim.profile;
			s.members = member_sets(cfg, user, lim);
			s.throttle_rate = lim.throttle_rate;
			s.tmembers = throttle_members(cfg, user, lim);
			s.cm_set = lim.conn_max_set;
			s.pc_set = proxyclient_of(cfg, lim)?.set ?? null;
			s.quotas = map(user_sitequotas(cfg, user, lim), q => ident(q.sid));
			s.sq = s.sq ?? {};
			s.quota_blocked = quota_blocked_today(cfg, load_state(), sessions, user, lim);
			s.rsets = map(user_routes(cfg, user), r => r.set_src);
		}
		rules += session_rules(ip, s.mac, { rate_up: s.rate_up, rate_down: s.rate_down }, s);
	}
	if (length(rules))
		nft_batch(rules);
	passwall_sync(sessions, cfg);
	unlink(FORWARDS_FILE);
	forwards_apply(cfg, sessions);
}

function startup() {
	return with_lock(function() {
		let cfg = load_config();
		ensure_dirs();
		run('chmod 600 /etc/config/usermanager');
		if (!cfg.settings.enabled) {
			fw_teardown();
			log('service disabled, firewall rules removed');
			return false;
		}
		fw_setup(cfg);
		config_mtime = config_stamp();
		let sessions = load_sessions();
		for (let ip, s in sessions)
			s.last_activity = now();
		restore_rules(cfg, sessions);
		save_sessions(sessions);
		log(sprintf('started, %d session(s) restored', length(sessions)));
		return true;
	});
}

function shutdown() {
	return with_lock(function() {
		fw_teardown();
		log('stopped, firewall rules removed');
		return true;
	});
}

function tick() {
	return with_lock(function() {
		let cfg = load_config();
		if (!cfg.settings.enabled)
			return 0;
		let st = load_state();
		let sessions = load_sessions();

		// config edited (LuCI apply, uci commit, vouchers): rebuild the ruleset atomically, keep sessions
		let stamp = config_stamp();
		if (stamp != config_mtime || !fw_installed()) {
			let rebuilt = (stamp != config_mtime);
			config_mtime = stamp;
			fw_setup(cfg);
			restore_rules(cfg, sessions);
			if (rebuilt)
				log('configuration changed, firewall rules rebuilt');
		}
		if (!length(sessions))
			return 0;

		let ctr = fw_counters();
		let t = now();
		let dirty = false;
		let arp = arp_table();

		for (let ip, s in sessions) {
			let up = ctr.up[ip] ?? s.up_last;
			let down = ctr.down[ip] ?? s.down_last;
			let dup = (up >= s.up_last) ? up - s.up_last : up;
			let ddown = (down >= s.down_last) ? down - s.down_last : down;
			s.up_last = up;
			s.down_last = down;
			s.rate_up_bps = int(dup / 5);
			s.rate_down_bps = int(ddown / 5);
			if (dup || ddown) {
				s.up_acc += dup;
				s.down_acc += ddown;
				s.last_activity = t;
			}
		}

		// enforce limits
		for (let ip in keys(sessions)) {
			let s = sessions[ip];
			let user = cfg.users[s.user];
			let reason = null;
			if (!user)
				reason = 'deleted';
			else {
				let lim = effective_limits(cfg, user);
				reason = check_user(cfg, st, sessions, user);
				if (!reason && lim.session_timeout > 0 && (t - s.start) >= lim.session_timeout)
					reason = 'session_timeout';
				if (!reason && lim.idle_timeout > 0 && (t - s.last_activity) >= lim.idle_timeout)
					reason = 'idle';
				if (!reason && arp[ip] && arp[ip].mac != s.mac)
					reason = 'mac_changed';
			}
			if (reason) {
				do_deauth(cfg, st, sessions, ip, reason);
				dirty = true;
			}
		}

		// per-site daily quotas: attribute counter deltas, enforce, handle the midnight rollover
		if (length(cfg.sitequotas))
			sitequota_tick(cfg, st, sessions, t);

		// passwall2 may have been restarted and lost our bypass rules / sets
		if (length(cfg.settings.direct_domains) || length(cfg.routes) || length(filter(values(sessions), s => s.proxy == 'direct')))
			passwall_sync(sessions, cfg);
		if (length(cfg.forwards))
			forwards_apply(cfg, sessions);
		tick_n++;
		if (length(cfg.routes) && (tick_n % 6) == 0)
			routes_apply(cfg);
		if (length(cfg.tunnels) && (tick_n % 3) == 0)
			tunnels_check(cfg, sessions);

		if (dirty || (t - last_persist) >= cfg.settings.save_interval) {
			for (let ip, s in sessions) {
				fold_daily(cfg, st, s);
				fold_quotas(st, s);
			}
			for (let mac in keys(st.cookies))
				if (st.cookies[mac].until < t)
					delete st.cookies[mac];
			save_state(st);
			last_persist = t;
			rotate_dns_logs();
		}
		save_sessions(sessions);
		return length(sessions);
	});
}

// ---------------------------------------------------------------- monitoring

// parse the resolver query logs: per-client domain activity and the global answer map (ip -> name)
function dns_activity(ips, limit) {
	let want = {};
	for (let ip in ips)
		want[ip] = true;
	let domains = {};   // name -> { count, last }
	let answers = {};   // ip -> name
	for (let f in [ DNSLOG_PROXY, DNSLOG_DIRECT ]) {
		let data = readfile(f);
		if (!data)
			continue;
		for (let line in split(data, '\n')) {
			// "Oct  7 10:10:00 dnsmasq[123]: query[A] www.example.com from 192.168.10.155"
			let m = match(line, /^(\w+ +\d+ \d\d:\d\d:\d\d) dnsmasq\[\d+\]: query\[(\w+)\] (\S+) from (\S+)$/);
			if (m) {
				if (!want[m[4]] || m[2] == 'PTR')
					continue;
				let name = lc(m[3]);
				if (match(name, /\.(lan|router|local|arpa)$/) || name == 'dibachain.router')
					continue;
				let e = domains[name] = domains[name] ?? { count: 0, last: '' };
				e.count++;
				e.last = m[1];
				continue;
			}
			// "... reply www.example.com is 1.2.3.4" / "cached www.example.com is 1.2.3.4"
			m = match(line, / (reply|cached) (\S+) is (\d+\.\d+\.\d+\.\d+)$/);
			if (m)
				answers[m[3]] = lc(m[2]);
		}
	}
	let list = [];
	for (let name, e in domains)
		push(list, { domain: name, count: e.count, last: e.last });
	list = sort(list, (a, b) => (b.last > a.last) ? 1 : ((b.last < a.last) ? -1 : (b.count - a.count)));
	return { domains: slice(list, 0, limit ?? 100), answers: answers };
}

// live connections of the given client addresses from the kernel conntrack table
function connections(ips, answers, limit) {
	let want = {};
	for (let ip in ips)
		want[ip] = true;
	let data = readfile('/proc/net/nf_conntrack') ?? '';
	let by_dst = {};
	let total = 0;
	for (let line in split(data, '\n')) {
		// ipv4 2 tcp 6 431999 ESTABLISHED src=A dst=B sport=.. dport=.. packets=.. bytes=.. [UNREPLIED] src=B dst=A sport=.. dport=.. packets=.. bytes=.. ...
		let m = match(line, /^ipv4 +\d+ +(\w+) +\d+ +(\d+) +([A-Z_]+ )?src=([0-9.]+) dst=([0-9.]+) (sport=(\d+) dport=(\d+) )?(packets=(\d+) bytes=(\d+) )?(\[UNREPLIED\] )?src=[0-9.]+ dst=[0-9.]+ (sport=\d+ dport=\d+ )?(packets=(\d+) bytes=(\d+))?/);
		if (!m || !want[m[4]])
			continue;
		let proto = m[1], dst = m[5], dport = m[8] ?? '';
		if (proto == 'udp' && dport == '53')
			continue;
		total++;
		let key = dst + ':' + dport + '/' + proto;
		let e = by_dst[key] = by_dst[key] ?? { dst: dst, port: int(dport) || 0, proto: proto, conns: 0, up: 0, down: 0, domain: answers?.[dst] ?? null, ttl: 0 };
		e.conns++;
		e.up += int(m[11] ?? 0);
		e.down += int(m[16] ?? 0);
		e.ttl = max(e.ttl, int(m[2]));
	}
	let list = sort(values(by_dst), (a, b) => (b.up + b.down) - (a.up + a.down));
	return { total: total, top: slice(list, 0, limit ?? 60) };
}

// everything the Monitor page needs for one user
function user_detail(username) {
	let cfg = load_config();
	let st = load_state();
	let sessions = load_sessions();
	let user = cfg.users[username];
	if (!user)
		return { error: 'no such user' };
	let lim = effective_limits(cfg, user);
	let su = st.users[username] ?? {};
	let active = [];
	let ips = [];
	let t = now();
	for (let ip, s in sessions)
		if (s.user == username) {
			push(ips, ip);
			push(active, {
				ip: ip, mac: s.mac, hostname: s.hostname ?? '', start: s.start, uptime: t - s.start, idle: t - s.last_activity,
				up: s.up_acc, down: s.down_acc, rate_up_bps: s.rate_up_bps ?? 0, rate_down_bps: s.rate_down_bps ?? 0,
				proxy: s.proxy ?? 'passwall', via: s.via ?? 'portal', rate_up: s.rate_up, rate_down: s.rate_down,
				throttle_rate: s.throttle_rate ?? 0, wifi: wifi_clients()[s.mac] ?? null
			});
		}
	let probe_ips = length(ips) ? ips : (su.last_ip ? [ su.last_ip ] : []);
	let act = dns_activity(probe_ips, 150);
	let conns = length(ips) ? connections(ips, act.answers, 60) : { total: 0, top: [] };

	// daily usage, last 14 days (fill gaps with 0)
	let daily = [];
	let running = {};
	for (let ip, s in sessions)
		if (s.user == username)
			running[today()] = (running[today()] ?? 0) + (session_bytes(cfg, s) - (s.folded ?? 0));
	for (let i = 13; i >= 0; i--) {
		let lt = localtime(t - i * 86400);
		let d = sprintf('%04d-%02d-%02d', lt.year, lt.mon, lt.mday);
		push(daily, { date: d, bytes: (su.daily?.[d] ?? 0) + (running[d] ?? 0) });
	}

	let used = user_used(cfg, st, sessions, username);
	return {
		username: username,
		profile: lim.profile,
		enabled: user.enabled,
		comment: user.comment,
		voucher: user.voucher,
		mac_bind: user.mac,
		limits: {
			quota: lim.quota_bytes, rate_up: lim.rate_up, rate_down: lim.rate_down, proxy: lim.proxy,
			validity_days: lim.validity_days, time_limit: lim.time_limit, idle_timeout: lim.idle_timeout,
			session_timeout: lim.session_timeout, shared_users: lim.shared_users,
			throttle_rate: lim.throttle_rate, block: user.block, cat_block: user.cat_block, cat_throttle: user.cat_throttle
		},
		stats: {
			used: used, quota: lim.quota_bytes, remaining: lim.quota_bytes > 0 ? max(0, lim.quota_bytes - used) : null,
			up: su.up ?? 0, down: su.down ?? 0, time_used: user_time_used(st, sessions, username),
			first_login: su.first_login ?? null, last_login: su.last_login ?? null, last_logout: su.last_logout ?? null,
			last_ip: su.last_ip ?? null, last_mac: su.last_mac ?? null, logins: su.logins ?? 0,
			expires: user_expiry(cfg, st, user), state: length(active) ? 'online' : (check_user(cfg, st, sessions, user) ?? 'offline')
		},
		active: active,
		history: reverse(su.history ?? []),
		daily: daily,
		dns: act.domains,
		connections: conns
	};
}

// ---------------------------------------------------------------- reporting

function sessions_report() {
	let cfg = load_config();
	let st = load_state();
	let sessions = load_sessions();
	let leases = dhcp_leases();
	let wifi = wifi_clients();
	let t = now();
	let res = [];
	for (let ip, s in sessions) {
		let user = cfg.users[s.user];
		let lim = user ? effective_limits(cfg, user) : null;
		let used = user ? user_used(cfg, st, sessions, s.user) : 0;
		push(res, {
			ip: ip,
			mac: s.mac,
			user: s.user,
			profile: s.profile,
			hostname: s.hostname || (leases.by_mac[s.mac]?.hostname ?? ''),
			start: s.start,
			uptime: t - s.start,
			idle: t - s.last_activity,
			up: s.up_acc,
			down: s.down_acc,
			rate_up_bps: s.rate_up_bps ?? 0,
			rate_down_bps: s.rate_down_bps ?? 0,
			session_bytes: session_bytes(cfg, s),
			used_total: used,
			quota: lim?.quota_bytes ?? 0,
			remaining: (lim && lim.quota_bytes > 0) ? max(0, lim.quota_bytes - used) : null,
			expires: user ? user_expiry(cfg, st, user) : null,
			rate_up: s.rate_up,
			rate_down: s.rate_down,
			proxy: s.proxy ?? 'passwall',
			blocked: length(s.members ?? []) > 0 || length(cfg.settings.block_global) > 0,
			via: s.via,
			wifi: wifi[s.mac] ?? null
		});
	}
	return res;
}

function users_report() {
	let cfg = load_config();
	let st = load_state();
	let sessions = load_sessions();
	let res = {};
	for (let name, user in cfg.users) {
		let lim = effective_limits(cfg, user);
		let su = st.users[name] ?? {};
		let used = user_used(cfg, st, sessions, name);
		let online = length(filter(values(sessions), s => s.user == name));
		res[name] = {
			used: used,
			up: su.up ?? 0,
			down: su.down ?? 0,
			quota: lim.quota_bytes,
			remaining: lim.quota_bytes > 0 ? max(0, lim.quota_bytes - used) : null,
			rate_up: lim.rate_up,
			rate_down: lim.rate_down,
			proxy: lim.proxy,
			time_used: user_time_used(st, sessions, name),
			time_limit: lim.time_limit,
			first_login: su.first_login ?? null,
			last_login: su.last_login ?? null,
			last_ip: su.last_ip ?? null,
			last_mac: su.last_mac ?? null,
			logins: su.logins ?? 0,
			expires: user_expiry(cfg, st, user),
			online: online,
			state: online ? 'online' : (check_user(cfg, st, sessions, user) ?? 'offline')
		};
	}
	return res;
}

function client_status(ip) {
	let cfg = load_config();
	let st = load_state();
	let sessions = load_sessions();
	let s = sessions[ip];
	if (!s)
		return null;
	let user = cfg.users[s.user];
	let lim = user ? effective_limits(cfg, user) : null;
	let used = user ? user_used(cfg, st, sessions, s.user) : 0;
	return {
		user: s.user,
		ip: ip,
		mac: s.mac,
		start: s.start,
		uptime: now() - s.start,
		up: s.up_acc,
		down: s.down_acc,
		used_total: used,
		quota: lim?.quota_bytes ?? 0,
		remaining: (lim && lim.quota_bytes > 0) ? max(0, lim.quota_bytes - used) : null,
		expires: user ? user_expiry(cfg, st, user) : null,
		session_timeout: lim?.session_timeout ?? 0,
		time_limit: lim?.time_limit ?? 0,
		time_used: user ? user_time_used(st, sessions, s.user) : 0,
		rate_up: s.rate_up,
		rate_down: s.rate_down,
		proxy: s.proxy ?? 'passwall'
	};
}

function status() {
	let cfg = load_config();
	let lan = lan_info(cfg);
	let sessions = load_sessions();
	let running = false, portal = false, resolver = false;
	try {
		let svc = ubus().call('service', 'list', { name: 'usermanager' });
		let inst = svc?.usermanager?.instances ?? {};
		running = !!inst.daemon?.running;
		portal = !!inst.portal?.running;
		resolver = !!inst.resolver_direct?.running && !!inst.resolver_proxy?.running;
	} catch (e) {}
	return {
		enabled: cfg.settings.enabled,
		running: running,
		portal_running: portal,
		resolver_running: resolver,
		firewall: fw_installed(),
		passwall: passwall_info()?.name ?? null,
		caps: capabilities(),
		lan_ip: lan.ipaddr,
		lan_dev: lan.ifname,
		portal_ip: lan.portal_ip,
		portal_host: cfg.settings.portal_host,
		portal_port: cfg.settings.portal_port,
		portal_url: portal_url(cfg, lan),
		sessions: length(sessions),
		direct_sessions: length(filter(values(sessions), s => s.proxy == 'direct')),
		users: length(cfg.users),
		profiles: length(cfg.profiles),
		bypass: length(cfg.bypass),
		count_mode: cfg.settings.count_mode
	};
}

// generate voucher codes and add them as users
function generate_vouchers(count, len, prefix, profile, comment, charset) {
	let c = cursor();
	let existing = {};
	c.foreach('usermanager', 'user', u => { existing[u.username] = true; });
	charset = (length(charset) >= 2) ? charset : 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
	let rnd = open('/dev/urandom', 'r');
	let codes = [];
	count = min(max(to_int(count, 1), 1), 500);
	len = min(max(to_int(len, 8), 4), 32);
	let lt = localtime();
	let batch = sprintf('%04d-%02d-%02d %02d:%02d', lt.year, lt.mon, lt.mday, lt.hour, lt.min);
	let guard = 0;
	while (length(codes) < count && guard++ < count * 10) {
		let code = prefix ?? '';
		let bytes = rnd.read(len);
		for (let i = 0; i < len; i++)
			code += substr(charset, ord(bytes, i) % length(charset), 1);
		if (existing[code])
			continue;
		existing[code] = true;
		let sid = c.add('usermanager', 'user');
		c.set('usermanager', sid, 'username', code);
		c.set('usermanager', sid, 'password', code);
		c.set('usermanager', sid, 'profile', profile ?? 'default');
		c.set('usermanager', sid, 'enabled', '1');
		c.set('usermanager', sid, 'voucher', '1');
		c.set('usermanager', sid, 'comment', length(comment) ? comment : ('Voucher ' + batch));
		push(codes, code);
	}
	rnd.close();
	c.commit('usermanager');
	run('chmod 600 /etc/config/usermanager');
	log(sprintf('generated %d voucher(s) profile=%s', length(codes), profile ?? 'default'));
	return { codes: codes, batch: batch, profile: profile ?? 'default' };
}

function neighbors() {
	let cfg = load_config();
	let lan = lan_info(cfg);
	let arp = arp_table();
	let leases = dhcp_leases();
	let wifi = wifi_clients();
	let sessions = load_sessions();
	let bypass = {};
	for (let m in cfg.bypass)
		bypass[m] = true;
	let res = [];
	let seen = {};
	for (let ip, a in arp) {
		if (a.dev != lan.ifname)
			continue;
		seen[a.mac] = true;
		push(res, {
			ip: ip, mac: a.mac,
			hostname: leases.by_ip[ip]?.hostname ?? leases.by_mac[a.mac]?.hostname ?? '',
			wifi: wifi[a.mac] ?? null,
			bypass: !!bypass[a.mac],
			user: sessions[ip]?.user ?? null
		});
	}
	for (let mac, w in wifi) {
		if (seen[mac])
			continue;
		let l = leases.by_mac[mac];
		push(res, { ip: l?.ip ?? '', mac: mac, hostname: l?.hostname ?? '', wifi: w, bypass: !!bypass[mac], user: null });
	}
	return res;
}

export {
	log, with_lock, load_config, effective_limits, lan_info, portal_url, arp_table, dhcp_leases, mac_of,
	wifi_clients, wifi_kick, load_state, save_state, load_sessions, save_sessions, fw_ruleset, fw_installed,
	fw_setup, fw_teardown, fw_counters, user_used, user_time_used, user_expiry, check_user, login, cookie_login,
	logout, kick_user, reset_usage, forget_user, startup, shutdown, tick, sessions_report, users_report,
	client_status, status, generate_vouchers, neighbors, prepare, passwall_sync, passwall_present, set_contents,
	forwards_report, CATEGORIES, user_detail, interfaces, routes_report, quota_block_info, quota_used,
	tunnel_cmds, tunnel_setup, tunnels_report, tunnel_pubkey,
	set_user_password, change_password, proxies_report, node_install, node_action, nodes_report, xray_available, capabilities, passwall_info
};
